export type TabType = 'home' | 'pathway' | 'assess' | 'progress' | 'profile' | 'ai-bot';

export interface TaskItem {
  id: string;
  category: 'learn' | 'practise' | 'build' | 'reassess';
  title: string;
  description: string;
  completed: boolean;
  duration?: string;
  topic?: string;
  details?: string;
}

export interface SkillItem {
  id: string;
  title: string;
  description: string;
  level?: string;
  badge?: string;
  status?: string;
  progress?: string;
  isAdditional?: boolean; // For additional skills outside main goal
  isAiVerified?: boolean; // Verified by AI Bot quiz
  verifiedAt?: string;
  score?: string;
}

export interface GoalHistoryItem {
  id: string;
  previousGoalName: string;
  newGoalName: string;
  reasonForLeaving: string;
  changedAt: string;
}

export type ThemeMode = 'light' | 'dark' | 'reading';
export type IconColorKey = 'sky' | 'emerald' | 'violet' | 'amber' | 'rose' | 'cyan' | 'crimson' | 'gold' | 'indigo';
export type BgColorKey = 'default' | 'sepia' | 'midnight' | 'ocean' | 'forest' | 'sunset';

export interface UserProfile {
  name: string;
  email: string;
  major: string;
  year: string;
  avatarUrl?: string;
  streakDays: number;
  gender?: 'male' | 'female' | 'other';
  birthDate?: string;
  age?: number;
  goalMode?: 'self' | 'ai';
  goalName?: string;
  studentId?: string;
  targetSkills?: string[];
  onboardingCompleted?: boolean;
  achievedSkills?: SkillItem[];
  missingSkills?: SkillItem[];
  reminderTime?: string; // '5:00 PM' | '6:00 PM' | '7:00 PM' | '8:00 PM' | '9:00 PM' | '10:00 PM'
  reminderEnabled?: boolean;
  notificationsAllowed?: boolean;
  goalHistory?: GoalHistoryItem[];
  themeIconColor?: IconColorKey;
  themeBgColor?: BgColorKey;
  readingMode?: boolean;
  weeklyHours?: number;
  learningLanguage?: string;
}

export interface PathwayGoal {
  id: string;
  title: string;
  category: string;
  progress: number; // 0-100
  targetDate: string;
  status: 'in-progress' | 'completed' | 'upcoming';
  description: string;
}

export interface CareerOption {
  id: string;
  title: string;
  matchPercentage: number;
  salaryRange: string;
  demand: 'High' | 'Very High' | 'Stable';
  description: string;
  keySkills: string[];
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'task' | 'milestone' | 'system';
}

export interface AssessmentQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  category: string;
}
