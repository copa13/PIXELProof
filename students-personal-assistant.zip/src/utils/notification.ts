// Utility for Device & Web Notifications for Daily Task Reminders

export type NotificationPermissionStatus = 'granted' | 'denied' | 'default' | 'unsupported';

export const getNotificationPermission = (): NotificationPermissionStatus => {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission as NotificationPermissionStatus;
};

export const requestNotificationPermission = async (): Promise<NotificationPermissionStatus> => {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  try {
    const perm = await Notification.requestPermission();
    localStorage.setItem('spa_notification_permission', perm);
    return perm as NotificationPermissionStatus;
  } catch (err) {
    console.error('Failed to request notification permission:', err);
    return Notification.permission as NotificationPermissionStatus;
  }
};

export const playGentleChime = () => {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15); // A5

    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.35);
  } catch {
    // AudioContext might be blocked until user gesture, safely ignore
  }
};

export const sendTaskReminderNotification = (options?: {
  title?: string;
  body?: string;
  timeLabel?: string;
}): { success: boolean; reason?: string } => {
  const perm = getNotificationPermission();

  const title = options?.title || '⚠️ Daily Task Incomplete Reminder!';
  const timeInfo = options?.timeLabel ? ` (Scheduled for ${options.timeLabel})` : '';
  const body =
    options?.body ||
    `Hey! Your daily learning tasks are still incomplete today${timeInfo}. Spend 15 minutes to keep your progress moving!`;

  playGentleChime();

  if (perm === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=128&q=80',
        badge: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=128&q=80',
      });
      return { success: true };
    } catch (err) {
      console.warn('Browser blocked notification creation:', err);
      return { success: false, reason: 'blocked_by_browser' };
    }
  }

  return { success: false, reason: perm };
};
