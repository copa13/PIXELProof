import React from 'react';

export type ThemeMode = 'light' | 'dark' | 'reading';

export type IconColorKey = 
  | 'sky' 
  | 'emerald' 
  | 'violet' 
  | 'amber' 
  | 'rose' 
  | 'cyan' 
  | 'crimson' 
  | 'gold'
  | 'indigo';

export type BgColorKey = 
  | 'default' 
  | 'sepia' 
  | 'midnight' 
  | 'ocean' 
  | 'forest' 
  | 'sunset';

export interface IconColorDef {
  key: IconColorKey;
  nameEn: string;
  nameMr: string;
  hex: string;
  darkHex: string;
  tailwindText: string;
  tailwindDarkText: string;
  tailwindBg: string;
  tailwindDarkBg: string;
  tailwindBorder: string;
  tailwindRing: string;
}

export interface BgColorDef {
  key: BgColorKey;
  nameEn: string;
  nameMr: string;
  isDark: boolean;
  isReading: boolean;
  bgClass: string;
  darkBgClass: string;
  cardBgClass: string;
  borderClass: string;
  textClass: string;
  accentPreview: string;
}

export const ICON_COLORS: IconColorDef[] = [
  {
    key: 'sky',
    nameEn: 'Sky Blue',
    nameMr: 'आकाशी निळा',
    hex: '#0284c7',
    darkHex: '#38bdf8',
    tailwindText: 'text-sky-600',
    tailwindDarkText: 'dark:text-sky-400',
    tailwindBg: 'bg-sky-50',
    tailwindDarkBg: 'dark:bg-sky-950/60',
    tailwindBorder: 'border-sky-300 dark:border-sky-800',
    tailwindRing: 'ring-sky-500',
  },
  {
    key: 'emerald',
    nameEn: 'Emerald Green',
    nameMr: 'ताजे पाचू हिरवा',
    hex: '#059669',
    darkHex: '#34d399',
    tailwindText: 'text-emerald-600',
    tailwindDarkText: 'dark:text-emerald-400',
    tailwindBg: 'bg-emerald-50',
    tailwindDarkBg: 'dark:bg-emerald-950/60',
    tailwindBorder: 'border-emerald-300 dark:border-emerald-800',
    tailwindRing: 'ring-emerald-500',
  },
  {
    key: 'violet',
    nameEn: 'Royal Violet',
    nameMr: 'शाही जांभळा',
    hex: '#7c3aed',
    darkHex: '#a78bfa',
    tailwindText: 'text-violet-600',
    tailwindDarkText: 'dark:text-violet-400',
    tailwindBg: 'bg-violet-50',
    tailwindDarkBg: 'dark:bg-violet-950/60',
    tailwindBorder: 'border-violet-300 dark:border-violet-800',
    tailwindRing: 'ring-violet-500',
  },
  {
    key: 'amber',
    nameEn: 'Warm Amber',
    nameMr: 'सोनेरी अंबर',
    hex: '#d97706',
    darkHex: '#fbbf24',
    tailwindText: 'text-amber-600',
    tailwindDarkText: 'dark:text-amber-400',
    tailwindBg: 'bg-amber-50',
    tailwindDarkBg: 'dark:bg-amber-950/60',
    tailwindBorder: 'border-amber-300 dark:border-amber-800',
    tailwindRing: 'ring-amber-500',
  },
  {
    key: 'rose',
    nameEn: 'Ruby Rose',
    nameMr: 'गुलाबी माणिक',
    hex: '#e11d48',
    darkHex: '#fb7185',
    tailwindText: 'text-rose-600',
    tailwindDarkText: 'dark:text-rose-400',
    tailwindBg: 'bg-rose-50',
    tailwindDarkBg: 'dark:bg-rose-950/60',
    tailwindBorder: 'border-rose-300 dark:border-rose-800',
    tailwindRing: 'ring-rose-500',
  },
  {
    key: 'cyan',
    nameEn: 'Neon Cyan',
    nameMr: 'निऑन सायना',
    hex: '#0891b2',
    darkHex: '#22d3ee',
    tailwindText: 'text-cyan-600',
    tailwindDarkText: 'dark:text-cyan-400',
    tailwindBg: 'bg-cyan-50',
    tailwindDarkBg: 'dark:bg-cyan-950/60',
    tailwindBorder: 'border-cyan-300 dark:border-cyan-800',
    tailwindRing: 'ring-cyan-500',
  },
  {
    key: 'crimson',
    nameEn: 'Flame Red',
    nameMr: 'ज्वाला लाल',
    hex: '#dc2626',
    darkHex: '#f87171',
    tailwindText: 'text-red-600',
    tailwindDarkText: 'dark:text-red-400',
    tailwindBg: 'bg-red-50',
    tailwindDarkBg: 'dark:bg-red-950/60',
    tailwindBorder: 'border-red-300 dark:border-red-800',
    tailwindRing: 'ring-red-500',
  },
  {
    key: 'gold',
    nameEn: 'Sun Gold',
    nameMr: 'सूर्य सुवर्ण',
    hex: '#ca8a04',
    darkHex: '#facc15',
    tailwindText: 'text-yellow-600',
    tailwindDarkText: 'dark:text-yellow-400',
    tailwindBg: 'bg-yellow-50',
    tailwindDarkBg: 'dark:bg-yellow-950/60',
    tailwindBorder: 'border-yellow-300 dark:border-yellow-800',
    tailwindRing: 'ring-yellow-500',
  },
  {
    key: 'indigo',
    nameEn: 'Deep Indigo',
    nameMr: 'गहिरा इंडिगो',
    hex: '#4f46e5',
    darkHex: '#818cf8',
    tailwindText: 'text-indigo-600',
    tailwindDarkText: 'dark:text-indigo-400',
    tailwindBg: 'bg-indigo-50',
    tailwindDarkBg: 'dark:bg-indigo-950/60',
    tailwindBorder: 'border-indigo-300 dark:border-indigo-800',
    tailwindRing: 'ring-indigo-500',
  },
];

export const BG_COLORS: BgColorDef[] = [
  {
    key: 'default',
    nameEn: 'Classic Modern',
    nameMr: 'क्लासिक आधुनिक (Slate)',
    isDark: false,
    isReading: false,
    bgClass: 'bg-slate-50',
    darkBgClass: 'dark:bg-slate-950',
    cardBgClass: 'bg-white dark:bg-slate-900',
    borderClass: 'border-slate-200 dark:border-slate-800',
    textClass: 'text-slate-900 dark:text-slate-100',
    accentPreview: '#0f172a',
  },
  {
    key: 'sepia',
    nameEn: 'Reading Mode (Sepia Paper)',
    nameMr: 'वाचन मोड (आरामदायी सेपिया)',
    isDark: false,
    isReading: true,
    bgClass: 'bg-[#f6f0e4]',
    darkBgClass: 'dark:bg-[#23201a]',
    cardBgClass: 'bg-[#fffdf8] dark:bg-[#2d2922]',
    borderClass: 'border-[#e8decb] dark:border-[#423c32]',
    textClass: 'text-[#3c3124] dark:text-[#f4ede0]',
    accentPreview: '#785433',
  },
  {
    key: 'midnight',
    nameEn: 'Midnight OLED Black',
    nameMr: 'मध्यरात्र काळा (OLED Black)',
    isDark: true,
    isReading: false,
    bgClass: 'bg-black',
    darkBgClass: 'dark:bg-black',
    cardBgClass: 'bg-zinc-900 dark:bg-zinc-950',
    borderClass: 'border-zinc-800 dark:border-zinc-850',
    textClass: 'text-zinc-100',
    accentPreview: '#000000',
  },
  {
    key: 'ocean',
    nameEn: 'Deep Ocean Navy',
    nameMr: 'खोल महासागर नेव्ही',
    isDark: true,
    isReading: false,
    bgClass: 'bg-[#081325]',
    darkBgClass: 'dark:bg-[#081325]',
    cardBgClass: 'bg-[#0d1f3c] dark:bg-[#0d1f3c]',
    borderClass: 'border-[#17325e] dark:border-[#17325e]',
    textClass: 'text-sky-100',
    accentPreview: '#0d254c',
  },
  {
    key: 'forest',
    nameEn: 'Forest Emerald Night',
    nameMr: 'शांत वन हिरवा (Forest)',
    isDark: true,
    isReading: false,
    bgClass: 'bg-[#051c14]',
    darkBgClass: 'dark:bg-[#051c14]',
    cardBgClass: 'bg-[#082b1f] dark:bg-[#082b1f]',
    borderClass: 'border-[#0f4432] dark:border-[#0f4432]',
    textClass: 'text-emerald-100',
    accentPreview: '#0a3526',
  },
  {
    key: 'sunset',
    nameEn: 'Twilight Dusk',
    nameMr: 'सायंकाळ जांभळसर (Dusk)',
    isDark: true,
    isReading: false,
    bgClass: 'bg-[#18091a]',
    darkBgClass: 'dark:bg-[#18091a]',
    cardBgClass: 'bg-[#27102a] dark:bg-[#27102a]',
    borderClass: 'border-[#431c48] dark:border-[#431c48]',
    textClass: 'text-fuchsia-100',
    accentPreview: '#38133d',
  },
];

export const getIconColorDef = (key: IconColorKey = 'sky'): IconColorDef => {
  return ICON_COLORS.find(c => c.key === key) || ICON_COLORS[0];
};

export const getBgColorDef = (key: BgColorKey = 'default'): BgColorDef => {
  return BG_COLORS.find(b => b.key === key) || BG_COLORS[0];
};
