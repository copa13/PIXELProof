import rawQuestionsData from '../data/ai_goals_questions.json';
import { 
  AiGoalsBank, 
  AiGoalQuestion, 
  AiGoalsQuizState, 
  QuestionOption, 
  QuizAnswerHistoryItem,
  AiGoalsCareer,
  CareerMatchResult
} from '../types/aiGoals';

/**
 * Static load and typed accessor for the question bank.
 * Ensures the app handles missing or malformed data gracefully without crashing.
 */
export const aiGoalsBank: AiGoalsBank = {
  startQuestionId: (rawQuestionsData as any).startQuestionId || 'Q1',
  scoring: (rawQuestionsData as any).scoring || { trackBonus: 10 },
  buddyMessages: (rawQuestionsData as any).buddyMessages || [
    '🦉 उत्तम निवड! तुम्ही योग्य दिशेने विचार करत आहात.',
    '🦉 छान! प्रत्येक प्रश्नासह तुमची क्षमता अधिक स्पष्ट होत आहे.',
    '🦉 मस्त! AI तुमचे विचार बारकाईने समजावून घेत आहे.',
    '🦉 अप्रतिम! ध्येय ठरवण्यासाठी तुमची ही आवड खूप महत्त्वाची आहे.',
    '🦉 छान उत्तर! तुम्ही तुमच्या स्वप्नातील करिअरच्या आणखी एक पाऊल जवळ आहात.'
  ],
  careers: (rawQuestionsData as any).careers || [],
  questions: (rawQuestionsData as any).questions || {}
};

/**
 * Helper to safely retrieve a question by its ID.
 */
export function getQuestionById(questionId: string): AiGoalQuestion | null {
  const bank = aiGoalsBank.questions;
  if (!bank) return null;

  if (Array.isArray(bank)) {
    return (bank as AiGoalQuestion[]).find(q => q.id === questionId) || null;
  }

  return (bank as Record<string, AiGoalQuestion>)[questionId] || null;
}

/**
 * Branching logic: determines which question comes next based on earlier answers.
 * Handles 4 next types:
 *  - "fixed": directly jumps to the given question id (e.g., "to": "Q2")
 *  - "byCluster": routes to a question based on cluster chosen in earlier meta (e.g. software, data_ai)
 *  - "byTrack": routes to a question based on track chosen in earlier meta (e.g. fullstack_web, ui_ux)
 *  - "result": quiz completed, navigates to the career recommendations result screen
 */
export function resolveNextQuestionId(
  question: AiGoalQuestion,
  cluster: string | null,
  track: string | null,
  currentQuestionNumber: number
): { type: 'next_question'; nextId: string } | { type: 'result' } {
  // If we already reached question 15 or the step is explicit 'result', finish the quiz
  if (!question.next || question.next.type === 'result' || currentQuestionNumber >= 15) {
    return { type: 'result' };
  }

  // 1. Fixed jump to a specific question ID
  if (question.next.type === 'fixed') {
    const target = question.next.to;
    if (target && getQuestionById(target)) {
      return { type: 'next_question', nextId: target };
    }
  }

  // 2. Branching by Cluster chosen earlier in meta.setCluster
  if (question.next.type === 'byCluster' && question.next.map) {
    const clusterKey = cluster || Object.keys(question.next.map)[0];
    const target = question.next.map[clusterKey] || Object.values(question.next.map)[0];
    if (target && getQuestionById(target)) {
      return { type: 'next_question', nextId: target };
    }
  }

  // 3. Branching by Track chosen earlier in meta.setTrack
  if (question.next.type === 'byTrack' && question.next.map) {
    const trackKey = track || Object.keys(question.next.map)[0];
    const target = question.next.map[trackKey] || Object.values(question.next.map)[0];
    if (target && getQuestionById(target)) {
      return { type: 'next_question', nextId: target };
    }
  }

  // Fallback: If no valid target is found, check if a next sequential ID exists, else finish
  const fallbackNum = currentQuestionNumber + 1;
  const fallbackId = `Q${fallbackNum}`;
  if (getQuestionById(fallbackId)) {
    return { type: 'next_question', nextId: fallbackId };
  }

  return { type: 'result' };
}

/**
 * Creates the initial clean quiz state.
 */
export function createInitialQuizState(): AiGoalsQuizState {
  return {
    currentQuestionId: aiGoalsBank.startQuestionId || 'Q1',
    questionNumber: 1, // 1..15
    history: [],
    tagScores: {},
    cluster: null,
    track: null,
    metaValues: {},
    isFinished: false
  };
}

/**
 * Executes an answer selection:
 * 1. Accumulates option tags into tagScores object.
 * 2. Saves metadata (cluster, track, experience, weeklyHours, learningLanguage, etc.).
 * 3. Records history for step-by-step undo.
 * 4. Resolves the next question via branching rules.
 */
export function answerQuestion(
  state: AiGoalsQuizState,
  selectedOptionIndex: number
): { newState: AiGoalsQuizState; buddyMessage: string } {
  const currentQ = getQuestionById(state.currentQuestionId);
  if (!currentQ || !currentQ.options || !currentQ.options[selectedOptionIndex]) {
    return {
      newState: state,
      buddyMessage: '🦉 चला पुढे सुरू ठेवूया!'
    };
  }

  const option: QuestionOption = currentQ.options[selectedOptionIndex];

  // 1. Accumulate tag scores
  const addedTags: Record<string, number> = {};
  const nextTagScores = { ...state.tagScores };
  if (option.tags) {
    for (const [tag, score] of Object.entries(option.tags)) {
      addedTags[tag] = score;
      nextTagScores[tag] = (nextTagScores[tag] || 0) + score;
    }
  }

  // 2. Extract and preserve meta values
  const prevCluster = state.cluster;
  const prevTrack = state.track;
  let nextCluster = state.cluster;
  let nextTrack = state.track;
  const nextMetaValues = { ...state.metaValues };
  const addedMeta: Record<string, any> = {};

  if (option.meta) {
    if (option.meta.setCluster) {
      nextCluster = option.meta.setCluster;
    }
    if (option.meta.setTrack) {
      nextTrack = option.meta.setTrack;
    }

    for (const [key, val] of Object.entries(option.meta)) {
      if (key !== 'setCluster' && key !== 'setTrack') {
        addedMeta[key] = val;
        nextMetaValues[key] = val;
      }
    }
  }

  // Pick a friendly buddy encouraging quote
  const buddyMessages = aiGoalsBank.buddyMessages || [];
  const buddyMessage = buddyMessages[Math.floor(Math.random() * buddyMessages.length)] || '🦉 खूप छान!';

  // 3. Record history item for undo support
  const historyItem: QuizAnswerHistoryItem = {
    questionId: state.currentQuestionId,
    questionNumber: state.questionNumber,
    selectedOptionIndex,
    option,
    addedTags,
    previousCluster: prevCluster,
    previousTrack: prevTrack,
    addedMeta,
    encouragementMessage: buddyMessage
  };

  // 4. Compute next question or result
  const nextResolution = resolveNextQuestionId(
    currentQ,
    nextCluster,
    nextTrack,
    state.questionNumber
  );

  const nextQuestionNumber = Math.min(15, state.questionNumber + 1);

  if (nextResolution.type === 'result') {
    return {
      newState: {
        ...state,
        questionNumber: 15,
        history: [...state.history, historyItem],
        tagScores: nextTagScores,
        cluster: nextCluster,
        track: nextTrack,
        metaValues: nextMetaValues,
        isFinished: true
      },
      buddyMessage
    };
  }

  return {
    newState: {
      ...state,
      currentQuestionId: nextResolution.nextId,
      questionNumber: nextQuestionNumber,
      history: [...state.history, historyItem],
      tagScores: nextTagScores,
      cluster: nextCluster,
      track: nextTrack,
      metaValues: nextMetaValues,
      isFinished: false
    },
    buddyMessage
  };
}

/**
 * Undos the most recent answer:
 * Reverts question number, rolls back tag scores, restores previous cluster & track,
 * and clears applied meta values.
 */
export function undoLastQuestion(state: AiGoalsQuizState): AiGoalsQuizState {
  if (state.history.length === 0) {
    return state;
  }

  const newHistory = [...state.history];
  const lastStep = newHistory.pop()!;

  // 1. Rollback tag scores
  const revertedTagScores = { ...state.tagScores };
  for (const [tag, score] of Object.entries(lastStep.addedTags)) {
    if (revertedTagScores[tag] !== undefined) {
      revertedTagScores[tag] -= score;
      if (revertedTagScores[tag] <= 0) {
        delete revertedTagScores[tag];
      }
    }
  }

  // 2. Rollback meta values
  const revertedMetaValues = { ...state.metaValues };
  for (const key of Object.keys(lastStep.addedMeta)) {
    delete revertedMetaValues[key];
  }

  return {
    ...state,
    currentQuestionId: lastStep.questionId,
    questionNumber: lastStep.questionNumber,
    history: newHistory,
    tagScores: revertedTagScores,
    cluster: lastStep.previousCluster,
    track: lastStep.previousTrack,
    metaValues: revertedMetaValues,
    isFinished: false
  };
}

/**
 * Friendly Marathi labels for tags used in template-based "why" explanations.
 */
export const TAG_LABELS_MR: Record<string, string> = {
  software: 'सॉफ्टवेअर विकास',
  coding: 'कोडिंग आणि अल्गोरिदम्स',
  frontend: 'फ्रंटएंड व वेब डिझाइन',
  backend: 'सर्व्हर व बॅकएंड आर्किटेक्चर',
  logic: 'तर्कशुद्ध विचार (Logic)',
  database: 'डेटाबेस आणि क्वेरी',
  problem_solving: 'समस्या निराकरण (Problem Solving)',
  ui_design: 'UI डिझाईन आणि व्हिज्युअल सेन्स',
  creativity: 'सर्जनशीलता (Creativity)',
  user_experience: 'वापरकर्ता अनुभव (UX)',
  api: 'APIs आणि सिस्टीम इंटिग्रेशन',
  architecture: 'सिस्टम आर्किटेक्चर',
  data_analysis: 'डेटा विश्लेषण (Data Analysis)',
  statistics: 'सांख्यिकी आणि डेटा मॉडेल्स',
  machine_learning: 'मशीन लर्निंग (Machine Learning)',
  ai_ml: 'कृत्रिम बुद्धिमत्ता (AI & ML)',
  python: 'पायथन प्रोग्रॅमिंग',
  mobile_app: 'मोबाइल ॲप निर्मिती',
  security: 'माहिती सुरक्षा (Cybersecurity)',
  networking: 'नेटवर्किंग आणि प्रोटोकॉल्स',
  cloud: 'क्लाउड कॉम्प्युटिंग',
  devops: 'ऑटोमेशन व डिप्लॉयमेंट'
};

/**
 * Computes cosine similarity between user tag vector and career tag weights:
 * percent = round(100 * cosine(userTagVector, career.tagWeights))
 * Add "scoring.trackBonus" (10) to the career whose id equals the chosen track,
 * cap at 100, then sort descending.
 */
export function computeCareerMatches(
  userTagScores: Record<string, number>,
  chosenTrack: string | null
): CareerMatchResult[] {
  const careers: AiGoalsCareer[] = aiGoalsBank.careers || [];
  const trackBonus = aiGoalsBank.scoring?.trackBonus ?? 10;

  // Compute user tag vector magnitude: sqrt(sum(u_i ^ 2))
  let userMagSq = 0;
  for (const score of Object.values(userTagScores)) {
    userMagSq += score * score;
  }
  const userMag = Math.sqrt(userMagSq);

  const results: CareerMatchResult[] = careers.map(career => {
    const weights = career.tagWeights || {};
    
    // Compute dot product and career magnitude
    let dotProduct = 0;
    let careerMagSq = 0;
    const contributingTagList: { tag: string; contribution: number }[] = [];

    for (const [tag, weight] of Object.entries(weights)) {
      careerMagSq += weight * weight;
      const userVal = userTagScores[tag] || 0;
      if (userVal > 0) {
        const contribution = userVal * weight;
        dotProduct += contribution;
        contributingTagList.push({ tag, contribution });
      }
    }

    const careerMag = Math.sqrt(careerMagSq);
    let cosine = 0;
    if (userMag > 0 && careerMag > 0) {
      cosine = dotProduct / (userMag * careerMag);
    }

    // percent = round(100 * cosine)
    let percent = Math.round(100 * cosine);

    // Add track bonus if chosen track matches
    if (chosenTrack && career.id === chosenTrack) {
      percent += trackBonus;
    }

    // Cap at 100
    percent = Math.min(100, Math.max(35, percent));

    // Sort contributing tags descending by impact
    contributingTagList.sort((a, b) => b.contribution - a.contribution);
    const topTags = contributingTagList.slice(0, 3).map(item => item.tag);

    // If few user tags overlapped, fill with career's key weights
    if (topTags.length < 2) {
      const fallbackTags = Object.entries(weights)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([t]) => t);
      for (const t of fallbackTags) {
        if (!topTags.includes(t) && topTags.length < 3) {
          topTags.push(t);
        }
      }
    }

    // Build Marathi "why" explanation from top contributing tags
    const marathiTagNames = topTags.map(t => TAG_LABELS_MR[t] || t);
    let whyText = '';
    if (marathiTagNames.length >= 2) {
      const head = marathiTagNames.slice(0, -1).join(', ');
      const last = marathiTagNames[marathiTagNames.length - 1];
      whyText = `तुमच्या उत्तरांनुसार ${head} आणि ${last} या विषयांमधील उत्तम कल, समस्या सोडवण्याची पद्धत आणि प्राधान्यांमुळे हे करिअर तुमच्यासाठी सर्वात योग्य (Best Fit) ठरले आहे.`;
    } else if (marathiTagNames.length === 1) {
      whyText = `तुमच्या उत्तरांनुसार ${marathiTagNames[0]} या विषयातील विशेष आवड आणि विचारसरणीमुळे हे करिअर तुमच्यासाठी आदर्श आहे.`;
    } else {
      whyText = `तुमच्या सर्वसमावेशक कौशल्यांनुसार हे करिअर तुमच्यासाठी योग्य आहे.`;
    }

    return {
      career,
      matchPercent: percent,
      whyText,
      topContributingTags: topTags
    };
  });

  // Sort descending by match percent
  results.sort((a, b) => b.matchPercent - a.matchPercent);

  return results;
}
