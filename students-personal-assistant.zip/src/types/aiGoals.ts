// Type definitions for AI Decided Goals Question Bank & Quiz State Engine

export type NextQuestionStep =
  | { type: 'fixed'; to: string }
  | { type: 'byCluster'; map: Record<string, string> }
  | { type: 'byTrack'; map: Record<string, string> }
  | { type: 'result' };

export interface QuestionOptionMeta {
  setCluster?: string;
  setTrack?: string;
  experience?: string;
  learningLanguage?: string;
  weeklyHours?: number;
  goal?: string;
  priority?: string;
  supportPreference?: string;
  coreValue?: string;
  [key: string]: any;
}

export interface QuestionOption {
  text: string;
  tags?: Record<string, number>;
  meta?: QuestionOptionMeta;
}

export interface AiGoalQuestion {
  id: string;
  text: string;
  category?: string;
  options: QuestionOption[];
  next: NextQuestionStep;
}

export interface AiGoalsCareer {
  id: string;
  title: string;
  tagWeights: Record<string, number>;
  description?: string;
  keySkills?: string[];
  category?: string;
}

export interface AiGoalsBank {
  startQuestionId: string;
  scoring?: {
    trackBonus?: number;
  };
  buddyMessages?: string[];
  careers?: AiGoalsCareer[];
  questions: Record<string, AiGoalQuestion>;
}

export interface QuizAnswerHistoryItem {
  questionId: string;
  questionNumber: number; // 1..15
  selectedOptionIndex: number;
  option: QuestionOption;
  addedTags: Record<string, number>;
  previousCluster: string | null;
  previousTrack: string | null;
  addedMeta: Partial<QuestionOptionMeta>;
  encouragementMessage: string;
}

export interface AiGoalsQuizState {
  currentQuestionId: string;
  questionNumber: number; // 1..15
  history: QuizAnswerHistoryItem[];
  tagScores: Record<string, number>;
  cluster: string | null;
  track: string | null;
  metaValues: Record<string, any>;
  isFinished: boolean;
}

export interface CareerMatchResult {
  career: AiGoalsCareer;
  matchPercent: number;
  whyText: string;
  topContributingTags: string[];
}
