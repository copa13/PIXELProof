import React, { useState, useEffect } from 'react';
import { TabType, TaskItem, UserProfile, PathwayGoal, CareerOption, NotificationItem, AssessmentQuestion, SkillItem, IconColorKey, BgColorKey } from './types';
import { getIconColorDef, getBgColorDef } from './utils/theme';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { TaskModal } from './components/TaskModal';
import { LearnModal } from './components/LearnModal';
import { TestingModal } from './components/TestingModal';
import { HomeScreen } from './screens/HomeScreen';
import { PathwayScreen } from './screens/PathwayScreen';
import { AssessScreen } from './screens/AssessScreen';
import { ProgressScreen } from './screens/ProgressScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { LoginScreen } from './screens/LoginScreen';
import { OnboardingScreen } from './screens/OnboardingScreen';
import { AIBotScreen } from './screens/AIBotScreen';
import { DemoWindow, DemoScreenKey, DEMO_SCREENS } from './components/DemoWindow';
import { AiDecidedGoalsModal } from './components/AiDecidedGoalsModal';
import { Sparkles, UserCheck, Flame, ArrowRight, X } from 'lucide-react';

const DEFAULT_PROFILE: UserProfile = {
  name: 'RIDER',
  email: 'ridergeming170@gmail.com',
  major: 'Computer Science & Engineering',
  year: 'Junior (Year 3)',
  streakDays: 14,
  reminderTime: '8:00 PM',
  reminderEnabled: true,
  notificationsAllowed: true,
};

const DEFAULT_TASKS: TaskItem[] = [
  {
    id: '1',
    category: 'learn',
    title: "Learn Today's Task",
    description: "Tap to view today's learning guide, topics, and text/video sources.",
    completed: false,
    duration: '25 mins',
    details: 'Review study materials, text documentation, and video lectures.',
  },
  {
    id: '2',
    category: 'practise',
    title: "Test Today's Task",
    description: 'Take your practice test with customizable question count (20-50).',
    completed: false,
    duration: '40 mins',
    details: 'Test your knowledge with 20 to 50 questions.',
  },
];

const DEFAULT_GOALS: PathwayGoal[] = [
  {
    id: 'g1',
    title: 'Full-Stack Web Development Mastery',
    category: 'Engineering',
    progress: 75,
    targetDate: 'End of Semester',
    status: 'in-progress',
    description: 'Build robust web apps using React, TypeScript, Node.js, and PostgreSQL.',
  },
  {
    id: 'g2',
    title: 'Algorithms & System Design Interview Prep',
    category: 'Career',
    progress: 60,
    targetDate: 'Summer 2026',
    status: 'in-progress',
    description: 'Solve 150+ LeetCode problems and master system design fundamentals.',
  },
  {
    id: 'g3',
    title: 'Cloud Architecture & DevOps Certification',
    category: 'Cloud',
    progress: 30,
    targetDate: 'Next Quarter',
    status: 'in-progress',
    description: 'Learn Docker, Kubernetes, CI/CD pipelines, and cloud deployment.',
  },
];

const CAREER_OPTIONS: CareerOption[] = [
  {
    id: 'c1',
    title: 'Full-Stack Software Engineer',
    matchPercentage: 94,
    salaryRange: '$95k - $145k',
    demand: 'Very High',
    description: 'Design and develop scalable web applications across client and server architectures.',
    keySkills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'REST APIs'],
  },
  {
    id: 'c2',
    title: 'Frontend Architect',
    matchPercentage: 91,
    salaryRange: '$110k - $160k',
    demand: 'High',
    description: 'Lead frontend design systems, performance optimization, and user experience engineering.',
    keySkills: ['React', 'Tailwind CSS', 'UI/UX Design', 'Performance', 'TypeScript'],
  },
  {
    id: 'c3',
    title: 'Software Developer & AI Integrator',
    matchPercentage: 88,
    salaryRange: '$105k - $155k',
    demand: 'Very High',
    description: 'Integrate modern LLM APIs and smart workflows into production software applications.',
    keySkills: ['Python', 'TypeScript', 'AI APIs', 'Prompt Engineering', 'Architecture'],
  },
];

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'n1',
    title: 'Daily Goal Reminder',
    message: "You have 2 pending tasks to finish today. Keep your 14-day streak alive!",
    time: '2h ago',
    read: false,
    type: 'task',
  },
  {
    id: 'n2',
    title: 'Skill Reassessment Available',
    message: 'Your monthly technical assessment is ready in the Assess tab.',
    time: '1d ago',
    read: true,
    type: 'milestone',
  },
];

const ASSESSMENT_QUESTIONS: AssessmentQuestion[] = [
  {
    id: 1,
    question: 'What is the time complexity of searching in a balanced Binary Search Tree (BST)?',
    options: ['O(N)', 'O(log N)', 'O(N log N)', 'O(1)'],
    correctIndex: 1,
    category: 'Data Structures',
  },
  {
    id: 2,
    question: 'Which hook in React is used to perform side effects in functional components?',
    options: ['useState', 'useContext', 'useEffect', 'useReducer'],
    correctIndex: 2,
    category: 'React & Frontend',
  },
  {
    id: 3,
    question: 'In TypeScript, what does the `readonly` modifier accomplish on property declarations?',
    options: [
      'Makes property private',
      'Prevents assignment after initialization',
      'Optimizes runtime memory',
      'Encrypts data in localStorage'
    ],
    correctIndex: 1,
    category: 'TypeScript',
  },
  {
    id: 4,
    question: 'What does ACID stand for in relational database transactions?',
    options: [
      'Atomicity, Consistency, Isolation, Durability',
      'Access, Control, Index, Data',
      'Asynchronous, Cached, Isolated, Distributed',
      'Automated, Compiled, Integrated, Dynamic'
    ],
    correctIndex: 0,
    category: 'Databases',
  },
  {
    id: 5,
    question: 'Which CSS layout module is best suited for two-dimensional row and column grids?',
    options: ['Flexbox', 'CSS Grid', 'Float layout', 'Inline-block'],
    correctIndex: 1,
    category: 'UI / CSS',
  },
];

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('spa_auth') !== 'false';
  });
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [pathwaySubTab, setPathwaySubTab] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('spa_dark_mode');
    return saved ? JSON.parse(saved) : false;
  });

  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('spa_profile');
    return saved ? JSON.parse(saved) : DEFAULT_PROFILE;
  });

  const [tasks, setTasks] = useState<TaskItem[]>(() => {
    return DEFAULT_TASKS;
  });

  const [pathwayGoals, setPathwayGoals] = useState<PathwayGoal[]>(() => {
    const saved = localStorage.getItem('spa_goals');
    return saved ? JSON.parse(saved) : DEFAULT_GOALS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [selectedTask, setSelectedTask] = useState<TaskItem | null>(null);
  const [showAiGoalsModal, setShowAiGoalsModal] = useState<boolean>(false);

  // Sync dark mode to DOM and localStorage
  useEffect(() => {
    localStorage.setItem('spa_dark_mode', JSON.stringify(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const [iconColor, setIconColor] = useState<IconColorKey>(() => {
    const saved = localStorage.getItem('spa_icon_color') as IconColorKey;
    return saved || profile.themeIconColor || 'sky';
  });

  const [bgColor, setBgColor] = useState<BgColorKey>(() => {
    const saved = localStorage.getItem('spa_bg_color') as BgColorKey;
    return saved || profile.themeBgColor || 'default';
  });

  const [readingMode, setReadingMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('spa_reading_mode');
    return saved !== null ? JSON.parse(saved) : (profile.readingMode || false);
  });

  // Sync Icon Color to CSS Variables & localStorage
  useEffect(() => {
    localStorage.setItem('spa_icon_color', iconColor);
    const def = getIconColorDef(iconColor);
    document.documentElement.style.setProperty('--theme-icon', def.hex);
    document.documentElement.style.setProperty('--theme-icon-dark', def.darkHex);
    document.documentElement.style.setProperty('--theme-icon-bg', def.hex + '18');
    document.documentElement.style.setProperty('--theme-icon-bg-dark', def.darkHex + '28');
  }, [iconColor]);

  // Sync Reading Mode to DOM & localStorage
  useEffect(() => {
    localStorage.setItem('spa_reading_mode', JSON.stringify(readingMode));
    if (readingMode) {
      document.documentElement.classList.add('reading-mode');
    } else {
      document.documentElement.classList.remove('reading-mode');
    }
  }, [readingMode]);

  // Sync Background Color & Theme
  useEffect(() => {
    localStorage.setItem('spa_bg_color', bgColor);
    const bgDef = getBgColorDef(bgColor);
    if (bgDef.isReading && !readingMode) {
      setReadingMode(true);
    }
  }, [bgColor, readingMode]);

  // Track daily login streak (Strict Rule: Missed day resets to 1)
  useEffect(() => {
    const todayStr = new Date().toISOString().slice(0, 10);
    const lastLogin = localStorage.getItem('spa_last_login_date');
    if (lastLogin !== todayStr) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yestStr = yesterday.toISOString().slice(0, 10);

      setProfile(prev => {
        let currentStreak = prev.streakDays || 1;
        if (lastLogin === yestStr) {
          // Consecutive login day
          currentStreak += 1;
        } else if (!lastLogin) {
          // First login
          currentStreak = Math.max(1, currentStreak);
        } else {
          // Missed one or more days! Strict reset to Day 1!
          currentStreak = 1;
        }
        return { ...prev, streakDays: currentStreak };
      });
      localStorage.setItem('spa_last_login_date', todayStr);
    }
  }, []);

  const handleUpdateStreak = (days: number) => {
    const validDays = Math.max(1, days);
    setProfile(prev => ({ ...prev, streakDays: validDays }));
    const todayStr = new Date().toISOString().slice(0, 10);
    localStorage.setItem('spa_last_login_date', todayStr);
  };

  const handleSimulateMissedDay = () => {
    // Strictly reset streak to Day 1
    setProfile(prev => ({ ...prev, streakDays: 1 }));
    const twoDaysAgo = new Date();
    twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
    localStorage.setItem('spa_last_login_date', twoDaysAgo.toISOString().slice(0, 10));
  };

  // Save state to localStorage
  useEffect(() => {
    localStorage.setItem('spa_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('spa_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('spa_goals', JSON.stringify(pathwayGoals));
  }, [pathwayGoals]);

  const handleToggleTask = (id: string) => {
    setTasks(prev =>
      prev.map(t => {
        if (t.id === id) {
          const updatedCompleted = !t.completed;
          return { ...t, completed: updatedCompleted };
        }
        return t;
      })
    );
  };

  const handleMarkNotificationRead = (id: string) => {
    setNotifications(prev =>
      prev.map(n => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const handleAddGoal = (goal: PathwayGoal) => {
    setPathwayGoals([goal, ...pathwayGoals]);
  };

  const handleCompleteAssessment = (score: number) => {
    // Add success notification
    const newNotif: NotificationItem = {
      id: Date.now().toString(),
      title: 'Assessment Completed',
      message: `You successfully completed your skill assessment with a score of ${score}/${ASSESSMENT_QUESTIONS.length}!`,
      time: 'Just now',
      read: false,
      type: 'milestone',
    };
    setNotifications([newNotif, ...notifications]);
  };

  const handleResetData = () => {
    localStorage.removeItem('spa_tasks');
    localStorage.removeItem('spa_profile');
    localStorage.removeItem('spa_goals');
    setTasks(DEFAULT_TASKS);
    setProfile(DEFAULT_PROFILE);
    setPathwayGoals(DEFAULT_GOALS);
    setNotifications(INITIAL_NOTIFICATIONS);
    setActiveTab('home');
  };

  const [language, setLanguage] = useState<'en' | 'mr' | 'hi'>(() => {
    const saved = localStorage.getItem('spa_language');
    return (saved as 'en' | 'mr' | 'hi') || 'mr';
  });

  useEffect(() => {
    localStorage.setItem('spa_language', language);
  }, [language]);

  const [fontSize, setFontSize] = useState<'small' | 'medium' | 'large'>(() => {
    return (localStorage.getItem('spa_font_size') as 'small' | 'medium' | 'large') || 'medium';
  });

  useEffect(() => {
    localStorage.setItem('spa_font_size', fontSize);
  }, [fontSize]);

  const fontClass =
    fontSize === 'small'
      ? 'text-sm'
      : fontSize === 'large'
      ? 'text-lg'
      : 'text-base';

  const [isOnboarded, setIsOnboarded] = useState<boolean>(() => {
    const isAuth = localStorage.getItem('spa_auth') === 'true';
    if (!isAuth) return false;
    const currentEmail = (localStorage.getItem('spa_current_user') || '').toLowerCase().trim();
    if (currentEmail) {
      return localStorage.getItem(`spa_onboarded_${currentEmail}`) === 'true';
    }
    return localStorage.getItem('spa_onboarded') === 'true';
  });

  // Demo Window State & Screen Teleportation
  const [demoWindowEnabled, setDemoWindowEnabled] = useState<boolean>(() => {
    return localStorage.getItem('spa_demo_window_enabled') === 'true';
  });

  useEffect(() => {
    localStorage.setItem('spa_demo_window_enabled', JSON.stringify(demoWindowEnabled));
  }, [demoWindowEnabled]);

  const [onboardingStep, setOnboardingStep] = useState<1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9>(5);
  const [forceSignUp, setForceSignUp] = useState<boolean>(false);

  const getCurrentDemoScreen = (): DemoScreenKey => {
    if (!isAuthenticated) {
      return forceSignUp ? 'signup' : 'login';
    }
    if (!isOnboarded) {
      return `onboarding_${onboardingStep}` as DemoScreenKey;
    }
    if (activeTab === 'ai-bot') {
      return 'tab_aibot';
    }
    return `tab_${activeTab}` as DemoScreenKey;
  };

  const handleDemoNavigate = (screenKey: DemoScreenKey) => {
    if (screenKey === 'login') {
      setIsAuthenticated(false);
      setForceSignUp(false);
    } else if (screenKey === 'signup') {
      setIsAuthenticated(false);
      setForceSignUp(true);
    } else if (screenKey.startsWith('onboarding_')) {
      const stepNum = parseInt(screenKey.split('_')[1], 10) as 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
      setIsAuthenticated(true);
      setIsOnboarded(false);
      setOnboardingStep(stepNum || 1);
    } else if (screenKey === 'tab_aibot') {
      setIsAuthenticated(true);
      setIsOnboarded(true);
      setActiveTab('ai-bot');
    } else if (screenKey.startsWith('tab_')) {
      const tabName = screenKey.replace('tab_', '') as TabType;
      setIsAuthenticated(true);
      setIsOnboarded(true);
      setActiveTab(tabName);
    }
  };

  const [showWelcomeBackModal, setShowWelcomeBackModal] = useState<boolean>(false);

  const handleDemoNext = () => {
    const currentKey = getCurrentDemoScreen();
    const currentIndex = DEMO_SCREENS.findIndex(s => s.key === currentKey);
    if (currentIndex >= 0 && currentIndex < DEMO_SCREENS.length - 1) {
      let nextIndex = currentIndex + 1;
      // If next is onboarding_7 (Recommended Goals) but user has a self-selected goal, skip to onboarding_8
      if (DEMO_SCREENS[nextIndex]?.key === 'onboarding_7' && (profile.goalMode === 'self' || profile.goalName)) {
        nextIndex = currentIndex + 2;
      }
      if (nextIndex < DEMO_SCREENS.length) {
        handleDemoNavigate(DEMO_SCREENS[nextIndex].key);
      }
    }
  };

  const handleDemoBack = () => {
    const currentKey = getCurrentDemoScreen();
    const currentIndex = DEMO_SCREENS.findIndex(s => s.key === currentKey);
    if (currentIndex > 0) {
      let prevIndex = currentIndex - 1;
      // If going back to onboarding_7 but user has self goal, skip back to onboarding_6
      if (DEMO_SCREENS[prevIndex]?.key === 'onboarding_7' && (profile.goalMode === 'self' || profile.goalName)) {
        prevIndex = currentIndex - 2;
      }
      if (prevIndex >= 0) {
        handleDemoNavigate(DEMO_SCREENS[prevIndex].key);
      }
    }
  };

  const handleDemoSkip = () => {
    if (!isAuthenticated || !isOnboarded) {
      setIsAuthenticated(true);
      setIsOnboarded(true);
      setActiveTab('home');
    } else {
      handleDemoNext();
    }
  };

  const handleLogin = (userCreds: Partial<UserProfile>, isNewAccount: boolean = false) => {
    const userEmail = (userCreds.email || '').toLowerCase().trim();
    setIsAuthenticated(true);
    localStorage.setItem('spa_auth', 'true');
    localStorage.setItem('spa_current_user', userEmail);

    const onboardedKey = userEmail ? `spa_onboarded_${userEmail}` : 'spa_onboarded';
    const profileKey = userEmail ? `spa_profile_${userEmail}` : 'spa_profile';
    const isAlreadyOnboarded = !isNewAccount && (localStorage.getItem(onboardedKey) === 'true');

    if (isNewAccount || !isAlreadyOnboarded) {
      // New account: Start completely fresh! No old history clutter taking space
      setIsOnboarded(false);
      setShowWelcomeBackModal(false);
      localStorage.removeItem(onboardedKey);
      if (isNewAccount && userEmail) {
        localStorage.removeItem(profileKey);
      }

      const freshProfile: UserProfile = {
        name: userCreds.name || 'New Student',
        email: userCreds.email || 'user@example.com',
        major: 'Computer Science',
        year: 'FY / Year 1',
        streakDays: 1,
        gender: userCreds.gender || 'male',
        birthDate: '',
        age: undefined,
        goalMode: undefined,
        goalName: undefined,
        onboardingCompleted: false,
        achievedSkills: [], // Fresh clean start!
        missingSkills: [],  // Fresh clean start!
        goalHistory: [],    // Empty history so it doesn't take space!
        reminderTime: '8:00 PM',
        reminderEnabled: true,
        notificationsAllowed: true,
      };
      setProfile(freshProfile);
      localStorage.setItem('spa_profile', JSON.stringify(freshProfile));
      if (userEmail) {
        localStorage.setItem(profileKey, JSON.stringify(freshProfile));
      }
    } else {
      // Existing user logging in: Retain all previous information & show Welcome Back!
      const savedUserStr = userEmail ? localStorage.getItem(profileKey) : localStorage.getItem('spa_profile');
      if (savedUserStr) {
        try {
          const parsed = JSON.parse(savedUserStr);
          if (userCreds.gender) parsed.gender = userCreds.gender;
          setProfile(parsed);
          localStorage.setItem('spa_profile', JSON.stringify(parsed));
        } catch {
          // fallback
        }
      }
      setIsOnboarded(true);
      setShowWelcomeBackModal(true); // Welcome Back pop-up!
    }
  };

  const handleCompleteOnboarding = (data: {
    name?: string;
    birthDate: string;
    age: number;
    goalMode: 'self' | 'ai';
    goalName?: string;
    studentId?: string;
    targetSkills?: string[];
    reminderTime?: string;
    notificationsAllowed?: boolean;
  }) => {
    const userEmail = (profile.email || '').toLowerCase().trim();

    // Setup initial clean skills for user's chosen goal
    const targetSkills = data.targetSkills || [];
    const initialAchieved: SkillItem[] = targetSkills.slice(0, 2).map((sk, idx) => ({
      id: `ach_${Date.now()}_${idx}`,
      title: sk,
      description: `Core verified foundation for ${data.goalName || 'Goal'}.`,
      level: idx === 0 ? '100%' : '90%',
      badge: idx === 0 ? 'Mastered' : 'Advanced',
      isAiVerified: true,
      verifiedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    }));

    const initialMissing: SkillItem[] = targetSkills.slice(2, 5).map((sk, idx) => ({
      id: `miss_${Date.now()}_${idx}`,
      title: sk,
      description: `Target capability to practice for ${data.goalName || 'Goal'}.`,
      status: idx === 0 ? 'In Progress' : 'Upcoming Target',
      progress: idx === 0 ? '25%' : '0%',
    }));

    const updatedProfile: UserProfile = {
      ...profile,
      name: data.name ? data.name.trim() : profile.name,
      birthDate: data.birthDate,
      age: data.age,
      goalMode: data.goalMode,
      goalName: data.goalName,
      studentId: data.studentId || profile.studentId,
      targetSkills: data.targetSkills || profile.targetSkills,
      achievedSkills: (profile.achievedSkills && profile.achievedSkills.length > 0) ? profile.achievedSkills : initialAchieved,
      missingSkills: (profile.missingSkills && profile.missingSkills.length > 0) ? profile.missingSkills : initialMissing,
      goalHistory: profile.goalHistory || [], // Fresh empty history - takes NO space!
      reminderTime: data.reminderTime || profile.reminderTime || '8:00 PM',
      reminderEnabled: true,
      notificationsAllowed: data.notificationsAllowed ?? profile.notificationsAllowed ?? true,
      onboardingCompleted: true,
    };
    setProfile(updatedProfile);
    localStorage.setItem('spa_profile', JSON.stringify(updatedProfile));
    if (userEmail) {
      localStorage.setItem(`spa_profile_${userEmail}`, JSON.stringify(updatedProfile));
      localStorage.setItem(`spa_onboarded_${userEmail}`, 'true');
    }
    // Also save mapping from studentId to email so student can log in with studentId
    if (updatedProfile.studentId) {
      localStorage.setItem(`spa_student_id_map_${updatedProfile.studentId.toUpperCase()}`, userEmail || updatedProfile.email);
    }
    localStorage.setItem('spa_onboarded', 'true');
    setIsOnboarded(true);

    // If user provided a custom goal or target skills, ensure it's in pathwayGoals
    if (data.goalName) {
      const newCustomGoal: PathwayGoal = {
        id: 'goal_' + Date.now(),
        title: data.goalName,
        category: data.goalMode === 'self' ? 'Personal Goal' : 'AI Career Track',
        progress: 15,
        targetDate: 'In 6 Months',
        status: 'in-progress',
        description: `Goal for ${updatedProfile.name}: ${data.goalName}. Key Skills: ${(data.targetSkills || []).join(', ') || 'Core Competencies'}`,
      };
      setPathwayGoals(prev => [newCustomGoal, ...prev]);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setIsOnboarded(false);
    localStorage.removeItem('spa_auth');
    localStorage.removeItem('spa_current_user');
  };

  const handleUpdateProfile = (updated: UserProfile) => {
    setProfile(updated);
    localStorage.setItem('spa_profile', JSON.stringify(updated));
    const userEmail = (updated.email || '').toLowerCase().trim();
    if (userEmail) {
      localStorage.setItem(`spa_profile_${userEmail}`, JSON.stringify(updated));
    }
  };

  return (
    <>
      {!isAuthenticated ? (
        <LoginScreen
          onLogin={handleLogin}
          initialEmail={profile.email}
          initialName={profile.name}
          language={language}
          setLanguage={setLanguage}
          darkMode={darkMode}
          setDarkMode={setDarkMode}
          fontSize={fontSize}
          setFontSize={setFontSize}
          demoWindowEnabled={demoWindowEnabled}
          setDemoWindowEnabled={setDemoWindowEnabled}
          forceSignUp={forceSignUp}
        />
      ) : !isOnboarded ? (
        <OnboardingScreen
          initialProfile={profile}
          language={language}
          onComplete={handleCompleteOnboarding}
          forcedStep={onboardingStep}
          onStepChange={setOnboardingStep}
        />
      ) : (
        <div className={`min-h-screen ${
          readingMode
            ? 'bg-[#f6f0e4] dark:bg-[#23201a] text-[#3c3124] dark:text-[#f4ede0]'
            : bgColor === 'midnight'
              ? 'bg-black text-zinc-100'
              : bgColor === 'ocean'
                ? 'bg-[#081325] text-sky-100'
                : bgColor === 'forest'
                  ? 'bg-[#051c14] text-emerald-100'
                  : bgColor === 'sunset'
                    ? 'bg-[#18091a] text-fuchsia-100'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100'
        } font-sans transition-colors selection:bg-sky-500 selection:text-white ${fontClass}`}>
          {/* Header */}
          <Header
            profile={profile}
            notifications={notifications}
            onMarkNotificationRead={handleMarkNotificationRead}
            onUpdateProfile={handleUpdateProfile}
            darkMode={darkMode}
            setDarkMode={setDarkMode}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            language={language}
            setLanguage={setLanguage}
            fontSize={fontSize}
            setFontSize={setFontSize}
            demoWindowEnabled={demoWindowEnabled}
            setDemoWindowEnabled={setDemoWindowEnabled}
            iconColor={iconColor}
            setIconColor={setIconColor}
            bgColor={bgColor}
            setBgColor={setBgColor}
            readingMode={readingMode}
            setReadingMode={setReadingMode}
          />

          {/* Main Content Area */}
          <main className="max-w-4xl mx-auto px-4 py-6">
            {activeTab === 'home' && (
              <HomeScreen
                profile={profile}
                tasks={tasks}
                onToggleTask={handleToggleTask}
                onOpenTaskModal={task => {
                  if (task.id === '1') {
                    setPathwaySubTab('daily');
                    setActiveTab('pathway');
                  } else {
                    setSelectedTask(task);
                  }
                }}
                setActiveTab={setActiveTab}
                language={language}
                onUpdateStreak={handleUpdateStreak}
                onSimulateMissedDay={handleSimulateMissedDay}
              />
            )}
            {activeTab === 'ai-bot' && (
              <AIBotScreen
                profile={profile}
                streakDays={profile.streakDays || 1}
                onUpdateStreak={handleUpdateStreak}
                setActiveTab={setActiveTab}
                language={language}
              />
            )}
            {activeTab === 'pathway' && (
              <PathwayScreen
                initialTab={pathwaySubTab}
                onTabChange={setPathwaySubTab}
                language={language}
              />
            )}
            {activeTab === 'assess' && (
              <AssessScreen
                questions={ASSESSMENT_QUESTIONS}
                onCompleteAssessment={handleCompleteAssessment}
                language={language}
              />
            )}
            {activeTab === 'progress' && (
              <ProgressScreen
                profile={profile}
                tasks={tasks}
                language={language}
              />
            )}
            {activeTab === 'profile' && (
              <ProfileScreen
                profile={profile}
                darkMode={darkMode}
                setDarkMode={setDarkMode}
                onUpdateProfile={handleUpdateProfile}
                onResetData={handleResetData}
                onLogout={handleLogout}
                language={language}
                setLanguage={setLanguage}
                iconColor={iconColor}
                setIconColor={setIconColor}
                bgColor={bgColor}
                setBgColor={setBgColor}
                readingMode={readingMode}
                setReadingMode={setReadingMode}
                onOpenAiGoalsQuiz={() => setShowAiGoalsModal(true)}
              />
            )}
          </main>

          {/* Task Details / Learn / Testing Modals */}
          {selectedTask?.id === '1' ? (
            <LearnModal
              task={selectedTask}
              onClose={() => setSelectedTask(null)}
              language={language}
            />
          ) : selectedTask?.id === '2' ? (
            <TestingModal
              task={selectedTask}
              onClose={() => setSelectedTask(null)}
              language={language}
            />
          ) : (
            <TaskModal
              task={selectedTask}
              onClose={() => setSelectedTask(null)}
              onToggleComplete={handleToggleTask}
            />
          )}

          {/* Bottom Navigation */}
          <BottomNav
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            language={language}
            iconColor={iconColor}
          />
        </div>
      )}

      {/* Floating Bubble & Demo Window Overlay */}
      {demoWindowEnabled && (
        <DemoWindow
          currentScreen={getCurrentDemoScreen()}
          onNavigate={handleDemoNavigate}
          onNext={handleDemoNext}
          onBack={handleDemoBack}
          onSkip={handleDemoSkip}
          onClose={() => setDemoWindowEnabled(false)}
          language={language}
        />
      )}
      {/* Welcome Back Modal for Existing Logged-in Users */}
      {showWelcomeBackModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm sm:max-w-md w-full p-6 text-center space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800 relative animate-in zoom-in-95">
            <button
              onClick={() => setShowWelcomeBackModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full cursor-pointer"
            >
              <X size={18} />
            </button>
            
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-sky-500 via-indigo-500 to-cyan-400 text-white flex items-center justify-center mx-auto shadow-lg shadow-sky-500/30">
              <Sparkles size={32} />
            </div>

            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/70 text-emerald-600 dark:text-emerald-400 text-xs font-bold border border-emerald-200 dark:border-emerald-800">
                <UserCheck size={13} />
                <span>लॉगिन यशस्वी (Login Successful)</span>
              </div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">
                Welcome Back, {profile.name || 'Student'}! 👋
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                तुमची आधीची सर्व माहिती, कौशल्ये आणि करिअर ध्येय सुरक्षितपणे लोड झाली आहे.
              </p>
            </div>

            {/* Restored Data Highlights */}
            <div className="grid grid-cols-2 gap-2 text-left pt-1">
              <div className="p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800/60 space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-indigo-500 dark:text-indigo-400">Active Goal</span>
                <p className="text-xs font-black text-indigo-950 dark:text-indigo-200 truncate">
                  {profile.goalName || 'Software Engineering'}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800/60 space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-emerald-600 dark:text-emerald-400">Student ID</span>
                <p className="text-xs font-mono font-black text-emerald-950 dark:text-emerald-200 truncate">
                  {profile.studentId || 'SPA-STU-2004'}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-sky-50 dark:bg-sky-950/50 border border-sky-200 dark:border-sky-800/60 space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-sky-600 dark:text-sky-400">Completed Skills</span>
                <p className="text-xs font-black text-sky-950 dark:text-sky-200">
                  {profile.achievedSkills?.length ?? 4} कौशल्ये
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800/60 space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-amber-600 dark:text-amber-400">Daily Streak</span>
                <p className="text-xs font-black text-amber-950 dark:text-amber-200 flex items-center gap-1">
                  <Flame size={13} className="text-amber-500 fill-amber-500" />
                  <span>{profile.streakDays || 1} Days</span>
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowWelcomeBackModal(false)}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-black text-sm shadow-lg shadow-sky-600/30 transition-all flex items-center justify-center gap-2 active:scale-98 cursor-pointer"
            >
              <span>डॅशबोर्ड सुरू करा (Continue to Dashboard)</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* AI Decided Goals Modal (Question Screen, Quiz Engine, and Result Screen) */}
      <AiDecidedGoalsModal
        isOpen={showAiGoalsModal}
        onClose={() => setShowAiGoalsModal(false)}
        language={language}
        onSelectCareer={(careerTitle, meta) => {
          setProfile(prev => ({
            ...prev,
            goalName: careerTitle,
            weeklyHours: meta.weeklyHours || prev.weeklyHours,
            learningLanguage: meta.learningLanguage || prev.learningLanguage,
          }));
          setShowAiGoalsModal(false);
        }}
      />
    </>
  );
}
