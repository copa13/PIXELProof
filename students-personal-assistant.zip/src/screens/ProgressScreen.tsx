import React, { useState } from 'react';
import { UserProfile, TaskItem } from '../types';
import { Flame, CheckCircle2, Clock, TrendingUp, Sparkles, Award, X, Video, Play, Volume2, FileText, HelpCircle, ChevronRight, Headphones } from 'lucide-react';

interface CompletedDayDetail {
  dayNum: number;
  dayName: string;
  title: string;
  topic: string;
  completedDate: string;
  questionsSolved: number;
  totalQuestions: number;
  scorePercentage: number;
  summary: string;
  textNotes: string;
  audioDetails: {
    title: string;
    duration: string;
    description: string;
  };
  videoDetails: {
    title: string;
    duration: string;
    description: string;
    source: string;
  };
  tasksCompleted: string[];
}

interface Props {
  profile: UserProfile;
  tasks: TaskItem[];
  language?: 'en' | 'mr' | 'hi';
}

export const ProgressScreen: React.FC<Props> = ({ profile, tasks, language = 'en' }) => {
  const isMr = language === 'mr';
  const [selectedDayDetail, setSelectedDayDetail] = useState<CompletedDayDetail | null>(null);

  const completedCount = tasks.filter(t => t.completed).length;
  const totalCount = tasks.length;
  const completionRate = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  // Study hours & tasks according to Pathway
  const totalStudyHours = 18.5;
  const monthlyStudyHours = 52.5;
  const totalCompletedTasksAcrossPathways = completedCount + 12; // including pathway milestones

  // Pathway Weekly stats (Skill 3 roadmap: 2/6 days completed, Day 3 active)
  const weeklyPathwayDaysCompleted = 2;
  const weeklyPathwayTotalDays = 6;
  const weeklyPathwayPercent = Math.round((weeklyPathwayDaysCompleted / weeklyPathwayTotalDays) * 100);

  // Pathway Monthly stats (6 skills roadmap: Python Basic & Computer Shortcuts completed = 2/6)
  const monthlyPathwaySkillsCompleted = 2;
  const monthlyPathwayTotalSkills = 6;
  const monthlyPathwayPercent = Math.round((monthlyPathwaySkillsCompleted / monthlyPathwayTotalSkills) * 100);

  // Day-by-day Questions Solved Activity
  const weeklyQuestionsActivity = [
    { day: 'Monday', shortDay: 'Mon', questionsSolved: 35, totalQuestions: 40 },
    { day: 'Tuesday', shortDay: 'Tue', questionsSolved: 40, totalQuestions: 40 },
    { day: 'Wednesday', shortDay: 'Wed', questionsSolved: 28, totalQuestions: 30 },
    { day: 'Thursday', shortDay: 'Thu', questionsSolved: 38, totalQuestions: 40 },
    { day: 'Friday', shortDay: 'Fri', questionsSolved: 35, totalQuestions: 35 },
    { day: 'Saturday', shortDay: 'Sat', questionsSolved: 22, totalQuestions: 25 },
    { day: 'Sunday (Today)', shortDay: 'Sun', questionsSolved: completedCount > 0 ? 25 : 20, totalQuestions: 25 },
  ];

  const progressDayDetails: Record<string, CompletedDayDetail> = {
    'Monday': {
      dayNum: 1,
      dayName: 'Monday',
      title: 'Monday: Vacuum Tubes & ENIAC Masterclass',
      topic: 'Introduction to Vacuum Tubes, Early Electrical Circuits & ENIAC Structure',
      completedDate: 'This Week • Monday',
      questionsSolved: 35,
      totalQuestions: 40,
      scorePercentage: 88,
      summary: 'या दिवशी 40 पैकी 35 प्रश्न यशस्वीरीत्या सोडवले. ENIAC कॉम्प्युटरची रचना आणि व्हॅक्यूम ट्यूबचे कार्य सखोल अभ्यासले.',
      textNotes: 'व्हॅक्यूम ट्यूब (Thermionic Valves) हे पहिल्या पिढीच्या कॉम्प्युटरमध्ये विद्युत सिग्नल नियंत्रित करण्यासाठी वापरले गेले. ENIAC (1945) मध्ये १८,००० हून अधिक व्हॅक्यूम ट्यूब वापरण्यात आल्या होत्या.',
      audioDetails: {
        title: 'Monday Audio Breakdown: Vacuum Tube Electronics',
        duration: '12 mins audio lesson',
        description: 'तज्ज्ञ ऑडिओ पॉडकास्ट ज्यामध्ये व्हॅक्यूम ट्यूबचे कार्य आणि ENIAC चा इतिहास मराठी/इंग्रजीमध्ये समजावला आहे.',
      },
      videoDetails: {
        title: 'Monday Video Lecture: First Gen Architecture in Action',
        duration: '22 mins • 1080p HD',
        description: 'अॅनिमेटेड व्हिडिओ ज्यामध्ये ENIAC चे हार्डवेअर व व्हॅक्यूम ट्यूबचे सर्किट दाखवले आहे.',
        source: 'AI Academy Series',
      },
      tasksCompleted: [
        'अभ्यास: व्हॅक्यूम ट्यूब नोट्स वाचन (Text Guide)',
        'ऑडिओ व्याख्यान: ENIAC ची पार्श्वभूमी आणि मर्यादा',
        'व्हिडिओ लेक्चर: First Gen Architecture Walkthrough',
        'सराव चाचणी: 40 पैकी 35 प्रश्न सोडवले (88% स्कोअर)',
      ],
    },
    'Tuesday': {
      dayNum: 2,
      dayName: 'Tuesday',
      title: 'Tuesday: Magnetic Drums & Punch Card Storage',
      topic: 'Magnetic Drum Memory, Punch Cards, Paper Tape, and Primary Storage',
      completedDate: 'This Week • Tuesday',
      questionsSolved: 40,
      totalQuestions: 40,
      scorePercentage: 100,
      summary: 'सर्व 40 पैकी 40 प्रश्न अचूक सोडवले (100% स्कोअर). मॅग्नेटिक ड्रम मेमरी आणि पंच कार्ड्सवरील सर्व संकल्पना स्पष्ट झाल्या.',
      textNotes: 'मॅग्नेटिक ड्रम हे पहिल्या पिढीच्या संगणकांमधील मुख्य मेमरी तंत्रज्ञान होते. यामध्ये फिरणाऱ्या धातूच्या ड्रमवर चुंबकीय कोटिंगद्वारे डेटा साठवला जात असे.',
      audioDetails: {
        title: 'Tuesday Audio Session: Memory & Storage Fundamentals',
        duration: '10 mins audio lesson',
        description: 'पंच कार्ड्स आणि ड्रम मेमरीच्या कार्यपद्धतीवरील सुस्पष्ट ऑडिओ विश्लेषण.',
      },
      videoDetails: {
        title: 'Tuesday Video Demonstration: Magnetic Drum Technology',
        duration: '18 mins • 1080p HD',
        description: 'पंच कार्ड रीडर आणि ड्रम स्टोरेजचे प्रात्यक्षिक दाखवणारा सविस्तर व्हिडिओ ट्यूटोरियल.',
        source: 'Computer History Archives',
      },
      tasksCompleted: [
        'अभ्यास: पंच कार्ड आणि मॅग्नेटिक ड्रम नोट्स वाचन',
        'ऑडिओ व्याख्यान: डेटा स्टोरेज आणि सायकल टाइम',
        'व्हिडिओ व्याख्यान: प्रात्यक्षिक व हार्डवेअर संरचना',
        'सराव चाचणी: 40 पैकी 40 प्रश्न पूर्ण (100% अचूकता)',
      ],
    },
    'Wednesday': {
      dayNum: 3,
      dayName: 'Wednesday',
      title: 'Wednesday: Machine Language & Binary Instruction Sets',
      topic: 'Direct Machine Code, Instruction Registers, and Opcode Formats',
      completedDate: 'This Week • Wednesday',
      questionsSolved: 28,
      totalQuestions: 30,
      scorePercentage: 93,
      summary: '30 पैकी 28 प्रश्न सोडवले (93%). मशीन लँग्वेज आणि 0-1 च्या बायनरी कोड्सचे प्रात्यक्षिक पूर्ण केले.',
      textNotes: 'पहिल्या पिढीच्या संगणकांमध्ये थेट मशीन कोड (0 आणि 1) वापरून प्रोग्रामिंग केले जात असे. कोणतीही उच्च पातळीची भाषा किंवा असेंबलर उपलब्ध नव्हता.',
      audioDetails: {
        title: 'Wednesday Audio: Binary Logic & Machine Code',
        duration: '15 mins audio session',
        description: 'बायनरी सूचना संच आणि रजिस्टर ऑपरेशनची ऑडिओ चर्चा.',
      },
      videoDetails: {
        title: 'Wednesday Video: Writing First-Gen Machine Code',
        duration: '20 mins • 1080p HD',
        description: 'बायनरी कोडिंग व इन्स्ट्रक्शन सायकल समजावणारा व्हिडिओ.',
        source: 'CodeCraft Lessons',
      },
      tasksCompleted: [
        'अभ्यास: बायनरी व मशीन कोड नोट्स',
        'ऑडिओ: इन्स्ट्रक्शन सेट ऑडिओ',
        'व्हिडिओ: मशीन लँग्वेज ट्युटोरिअल',
        'सराव चाचणी: 30 पैकी 28 प्रश्न सोडवले (93%)',
      ],
    },
    'Thursday': {
      dayNum: 4,
      dayName: 'Thursday',
      title: 'Thursday: Power Consumption & Vacuum Tube Cooling',
      topic: 'Heat Dissipation, Power Requirements & Maintenance of Early Mainframes',
      completedDate: 'This Week • Thursday',
      questionsSolved: 38,
      totalQuestions: 40,
      scorePercentage: 95,
      summary: '40 पैकी 38 प्रश्न सोडवले (95%). व्हॅक्यूम ट्यूबच्या उष्णतेची समस्या व एअर कंडिशनिंगची गरज यावरील प्रश्न सोडवले.',
      textNotes: 'हजारो व्हॅक्यूम ट्यूब्स प्रचंड उष्णता निर्माण करत होत्या, ज्यामुळे ते वारंवार जळायचे आणि सतत बदलण्याची गरज भासायची.',
      audioDetails: {
        title: 'Thursday Audio: Engineering Challenges of 1950s Computing',
        duration: '11 mins audio session',
        description: 'हार्डवेअर मेन्टेनन्स आणि कूलिंग सिस्टम्सचे ऑडिओ विश्लेषण.',
      },
      videoDetails: {
        title: 'Thursday Video: Inside an ENIAC Room & Tube Replacement',
        duration: '16 mins • 1080p HD',
        description: 'ऐतिहासिक फुटेज आणि ट्यूब रिप्लेसमेंटची प्रक्रिया.',
        source: 'Tech Museum Archives',
      },
      tasksCompleted: [
        'अभ्यास: कूलिंग आणि पॉवर गरज नोट्स',
        'ऑडिओ: इंजिनिअरिंग चॅलेंजेस पॉडकास्ट',
        'व्हिडिओ: ट्यूब मेंटेनन्स व्हिडिओ',
        'सराव चाचणी: 40 पैकी 38 प्रश्न सोडवले (95%)',
      ],
    },
    'Friday': {
      dayNum: 5,
      dayName: 'Friday',
      title: 'Friday: EDVAC, UNIVAC & Stored-Program Concept',
      topic: 'John von Neumann Architecture, EDVAC, UNIVAC-I commercial usage',
      completedDate: 'This Week • Friday',
      questionsSolved: 35,
      totalQuestions: 35,
      scorePercentage: 100,
      summary: '35 पैकी 35 प्रश्न पूर्ण (100% स्कोअर). वॉन न्यूमन आर्किटेक्चर आणि UNIVAC वरील सर्व मुद्दे स्पष्ट केले.',
      textNotes: 'EDVAC ने स्टोर्ड-प्रोग्रॅम संकल्पना मांडली, जिथे डेटा आणि प्रोग्रॅम दोन्ही एकाच मेमरीमध्ये साठवले जात होते.',
      audioDetails: {
        title: 'Friday Audio: John von Neumann Architecture',
        duration: '14 mins audio lesson',
        description: 'स्टोर्ड-प्रोग्रॅम संकल्पनेची ऑडिओ पार्श्वभूमी.',
      },
      videoDetails: {
        title: 'Friday Video: The Commercial Debut of UNIVAC',
        duration: '24 mins • 1080p HD',
        description: 'UNIVAC चे व्यावसायिक यश आणि 1952 च्या अध्यक्षीय निवडणुकीचे भाकीत.',
        source: 'PBS History Series',
      },
      tasksCompleted: [
        'अभ्यास: स्टोर्ड-प्रोग्रॅम संकल्पना नोट्स',
        'ऑडिओ: वॉन न्यूमन आर्किटेक्चर पॉडकास्ट',
        'व्हिडिओ: UNIVAC कमर्शियल व्हिडिओ',
        'सराव चाचणी: 35 पैकी 35 प्रश्न पूर्ण (100%)',
      ],
    },
    'Saturday': {
      dayNum: 6,
      dayName: 'Saturday',
      title: 'Saturday: Weekly Review & First Generation Problem Solving',
      topic: 'Comprehensive First Gen Revision, Mock Questions & Diagnostic Analysis',
      completedDate: 'This Week • Saturday',
      questionsSolved: 22,
      totalQuestions: 25,
      scorePercentage: 88,
      summary: '25 पैकी 22 प्रश्न बरोबर आले (88%). पहिल्या पिढीच्या कॉम्प्युटर्सचे सर्व महत्त्वाचे घटक रिव्हाईज केले.',
      textNotes: 'पहिल्या पिढीची वैशिष्ट्ये: व्हॅक्यूम ट्यूब, मॅग्नेटिक ड्रम, बॅच प्रोसेसिंग, मशीन लँग्वेज, अवजड आकार, आणि अधिक ऊर्जा वापर.',
      audioDetails: {
        title: 'Saturday Audio: Rapid Fire Revision Podcast',
        duration: '15 mins audio session',
        description: 'जलद रिव्हिजन ऑडिओ सत्र - महत्त्वाच्या परीक्षा प्रश्नांची उत्तरे.',
      },
      videoDetails: {
        title: 'Saturday Video: Complete First Generation Summary in 20 Mins',
        duration: '20 mins • 1080p HD',
        description: 'सर्व कॉम्प्युटर मॉडेल्स आणि संशोधकांचे द्रुत व्हिडिओ पुनरावलोकन.',
        source: 'Exam Prep Central',
      },
      tasksCompleted: [
        'अभ्यास: क्विक रिव्हिजन नोट्स',
        'ऑडिओ: रॅपिड रिव्हिजन ऑडिओ',
        'व्हिडिओ: समरी व्हिडिओ लेक्चर',
        'सराव चाचणी: 25 पैकी 22 प्रश्न सोडवले (88%)',
      ],
    },
    'Sunday (Today)': {
      dayNum: 7,
      dayName: 'Sunday (Today)',
      title: "Sunday: Today's Active Practice & Assessment",
      topic: 'Live First Generation Computer Quiz & Real-time Progress Tracking',
      completedDate: 'Today (Live Session)',
      questionsSolved: completedCount > 0 ? 25 : 20,
      totalQuestions: 25,
      scorePercentage: completedCount > 0 ? 100 : 80,
      summary: 'आजचे अध्ययन: आजच्या टास्कमधील प्रश्न सोडवले जात आहेत आणि प्रगती अपडेट होत आहे.',
      textNotes: 'आजचे टॉपिक: First Generation Architecture & Limitations. आजच्या नोट्स आणि प्रॅक्टिस टेस्ट चालू आहेत.',
      audioDetails: {
        title: "Sunday Audio: Today's Key Topic Walkthrough",
        duration: '10 mins audio breakdown',
        description: 'आजच्या अभ्यासक्रमावर आधारित विशेष ऑडिओ मार्गदर्शन.',
      },
      videoDetails: {
        title: "Sunday Video: Today's Daily Practice Guide",
        duration: '15 mins • 1080p HD',
        description: 'आजचे प्रश्न आणि सोल्यूशन्स दाखवणारा सविस्तर व्हिडिओ.',
        source: 'Daily Learning Series',
      },
      tasksCompleted: [
        "अभ्यास: Learn Today's Task मार्गदर्शक",
        'सराव: Test चाचणी प्रश्न',
        'रिव्हिजन: दैनिक संकल्पना पडताळणी',
      ],
    },
  };

  const totalQuestionsSolved = weeklyQuestionsActivity.reduce((acc, curr) => acc + curr.questionsSolved, 0);
  const totalQuestionsTarget = weeklyQuestionsActivity.reduce((acc, curr) => acc + curr.totalQuestions, 0);
  const weeklyQuestionsPercentage = Math.round((totalQuestionsSolved / totalQuestionsTarget) * 100);

  return (
    <div className="space-y-6 pb-24 animate-in fade-in">
      {/* Side-by-Side: Weekly & Monthly Pathway Progress */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Weekly Progress Card (Compact & Synchronized with Pathway) */}
        <section className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                <Clock size={18} />
              </div>
              <div>
                <h2 className="font-bold text-slate-900 dark:text-white text-sm">
                  {isMr ? 'साप्ताहिक प्रगती' : 'Weekly Progress'}
                </h2>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  {isMr ? 'कौशल्य 3 रोडमॅप • दिवस 3 चालू' : 'Skill 3 Roadmap • Day 3 Active'}
                </p>
              </div>
            </div>
            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
              {isMr ? 'हा आठवडा' : 'This Week'}
            </span>
          </div>

          <div className="space-y-1.5 bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-slate-700 dark:text-slate-300">
                {isMr ? 'पाथवे रोडमॅप:' : 'Pathway Roadmap:'}
              </span>
              <span className="text-indigo-600 dark:text-indigo-400 font-extrabold">
                {weeklyPathwayDaysCompleted} / {weeklyPathwayTotalDays} {isMr ? 'दिवस' : 'Days'} ({weeklyPathwayPercent}%)
              </span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-sky-500 to-indigo-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${weeklyPathwayPercent}%` }}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-sky-50/70 dark:bg-sky-950/30 border border-sky-100 dark:border-sky-900/40">
              <span className="text-[10px] text-sky-700 dark:text-sky-300 font-bold uppercase block">
                {isMr ? 'अभ्यास तास' : 'Study Hours'}
              </span>
              <span className="text-base font-extrabold text-slate-900 dark:text-white">{totalStudyHours} {isMr ? 'तास' : 'hrs'}</span>
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/40">
              <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-bold uppercase block">
                {isMr ? 'पूर्ण टास्क' : 'Completed Tasks'}
              </span>
              <span className="text-base font-extrabold text-slate-900 dark:text-white">{totalCompletedTasksAcrossPathways} {isMr ? 'टास्क' : 'tasks'}</span>
            </div>
          </div>
        </section>

        {/* Monthly Progress Card (Synchronized with Pathway) */}
        <section className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400">
                <Sparkles size={18} />
              </div>
              <div>
                <h2 className="font-bold text-slate-900 dark:text-white text-sm">
                  {isMr ? 'मासिक प्रगती' : 'Monthly Progress'}
                </h2>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  {isMr ? 'मासिक कौशल्य रोडमॅप' : 'Monthly Skills Roadmap'}
                </p>
              </div>
            </div>
            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400">
              {isMr ? 'हा महिना' : 'This Month'}
            </span>
          </div>

          <div className="space-y-1.5 bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-slate-700 dark:text-slate-300">
                {isMr ? 'कौशल्ये पूर्ण:' : 'Skills Mastered:'}
              </span>
              <span className="text-amber-600 dark:text-amber-400 font-extrabold">
                {monthlyPathwaySkillsCompleted} / {monthlyPathwayTotalSkills} {isMr ? 'कौशल्ये' : 'Skills'} ({monthlyPathwayPercent}%)
              </span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-amber-500 to-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${monthlyPathwayPercent}%` }}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-100 dark:border-amber-900/40">
              <span className="text-[10px] text-amber-700 dark:text-amber-300 font-bold uppercase block">
                {isMr ? 'मासिक वेळ' : 'Monthly Time'}
              </span>
              <span className="text-base font-extrabold text-slate-900 dark:text-white">{monthlyStudyHours} {isMr ? 'तास' : 'hrs'}</span>
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/40">
              <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-bold uppercase block">
                {isMr ? 'पूर्ण कौशल्ये' : 'Completed Skills'}
              </span>
              <span className="text-base font-extrabold text-slate-900 dark:text-white">
                {isMr ? '2 पूर्ण' : '2 Mastered'}
              </span>
            </div>
          </div>
        </section>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-sky-600 dark:text-sky-400">
            <Flame size={20} />
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-50 dark:bg-sky-950">
              {isMr ? 'सातत्य (Streak)' : 'Streak'}
            </span>
          </div>
          <p className="text-2xl font-extrabold text-slate-900 dark:text-white">
            {profile.streakDays} {isMr ? 'दिवस' : 'Days'}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isMr ? 'नियमित अभ्यास सातत्य' : 'Active learning streak'}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 size={20} />
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950">
              {isMr ? 'पूर्णता' : 'Completion'}
            </span>
          </div>
          <p className="text-2xl font-extrabold text-slate-900 dark:text-white">{completionRate}%</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isMr ? 'आज पूर्ण केलेले टास्क' : 'Tasks finished today'}
          </p>
        </div>
      </div>

      {/* Weekly Activity (Vertical Column Layout with Questions Solved) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400">
              <TrendingUp size={20} />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 dark:text-white text-base">
                {isMr ? 'साप्ताहिक क्रियाकलाप आणि प्रश्न' : 'Weekly Activity & Questions'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isMr ? 'दिवसानुसार सोडवलेले प्रश्न (सोमवार - रविवार)' : 'Day-by-day questions solved progress (Mon - Sun)'}
              </p>
            </div>
          </div>
          <span className="text-xs font-bold px-3 py-1 rounded-full bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400">
            {weeklyQuestionsPercentage}% {isMr ? 'पूर्ण' : 'Completed'}
          </span>
        </div>

        {/* Overall Weekly Progress Bar on Top */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="text-slate-700 dark:text-slate-300">
              {isMr ? 'या आठवड्यात सोडवलेले एकूण प्रश्न:' : 'Total Questions Solved This Week:'}
            </span>
            <span className="font-extrabold text-sky-600 dark:text-sky-400">
              {totalQuestionsSolved} / {totalQuestionsTarget} {isMr ? 'प्रश्न' : 'Questions'}
            </span>
          </div>
          <div className="w-full bg-slate-200 dark:bg-slate-700 h-2.5 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-sky-600 to-indigo-600 h-full rounded-full transition-all duration-500"
              style={{ width: `${weeklyQuestionsPercentage}%` }}
            />
          </div>
        </div>

        {/* Vertical Column (Ubha) Day-by-Day List */}
        <div className="space-y-2.5 pt-1">
          {weeklyQuestionsActivity.map((item, index) => {
            const percent = Math.round((item.questionsSolved / item.totalQuestions) * 100);
            const dayDetails = progressDayDetails[item.day];

            return (
              <div
                key={index}
                onClick={() => {
                  if (dayDetails) {
                    setSelectedDayDetail(dayDetails);
                  }
                }}
                role="button"
                tabIndex={0}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 space-y-2 shadow-sm hover:border-sky-300 dark:hover:border-sky-700 hover:bg-sky-50/30 dark:hover:bg-slate-800 transition-all cursor-pointer active:scale-[0.99]"
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 dark:text-white">
                      {isMr
                        ? item.day === 'Monday' ? 'सोमवार'
                          : item.day === 'Tuesday' ? 'मंगळवार'
                          : item.day === 'Wednesday' ? 'बुधवार'
                          : item.day === 'Thursday' ? 'गुरुवार'
                          : item.day === 'Friday' ? 'शुक्रवार'
                          : item.day === 'Saturday' ? 'शनिवार'
                          : 'रविवार (आज)'
                        : item.day}
                    </span>
                    <span className="text-[9px] font-bold bg-sky-100 dark:bg-sky-950/80 text-sky-700 dark:text-sky-300 px-2 py-0.5 rounded-full flex items-center gap-1">
                      {isMr ? 'टास्क इतिहास' : 'Tap for Daily Task'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sky-600 dark:text-sky-400">
                      {item.questionsSolved} / {item.totalQuestions} {isMr ? 'प्रश्न' : 'Questions'}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300">
                      {percent}%
                    </span>
                    <ChevronRight size={14} className="text-slate-400 shrink-0" />
                  </div>
                </div>

                {/* Day's Progress Bar */}
                <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-sky-500 to-indigo-500 h-full rounded-full transition-all duration-500"
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Completed Day Task Details Modal in Progress Screen */}
      {selectedDayDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 relative animate-in zoom-in-95 space-y-5 my-8">
            {/* Top Close Button */}
            <button
              onClick={() => setSelectedDayDetail(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Close details"
            >
              <X size={20} />
            </button>

            {/* Header info */}
            <div className="flex items-start gap-3 pr-8">
              <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 shrink-0">
                <CheckCircle2 size={24} />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-full">
                    {selectedDayDetail.dayName} Task History
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium">
                    {selectedDayDetail.completedDate}
                  </span>
                </div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white mt-1 leading-snug">
                  {selectedDayDetail.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {selectedDayDetail.topic}
                </p>
              </div>
            </div>

            {/* Questions Solved Card */}
            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/30 p-4 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                    <HelpCircle size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-emerald-950 dark:text-emerald-200">
                      Questions Solved on {selectedDayDetail.dayName}
                    </h4>
                    <p className="text-[11px] text-emerald-800/80 dark:text-emerald-400">
                      या दिवशी सोडवलेले प्रश्न आणि अचूकता
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-base font-extrabold text-emerald-700 dark:text-emerald-300">
                    {selectedDayDetail.questionsSolved} / {selectedDayDetail.totalQuestions}
                  </span>
                  <span className="text-[10px] font-bold block text-emerald-600 dark:text-emerald-400">
                    ({selectedDayDetail.scorePercentage}% Score)
                  </span>
                </div>
              </div>

              {/* Progress Bar for Questions */}
              <div className="w-full bg-emerald-200/60 dark:bg-emerald-900/50 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                  style={{ width: `${selectedDayDetail.scorePercentage}%` }}
                />
              </div>

              <p className="text-xs text-emerald-900 dark:text-emerald-200 leading-relaxed pt-1">
                {selectedDayDetail.summary}
              </p>
            </div>

            {/* Short Study Details & Text Notes */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-sky-600 dark:text-sky-400">
                <FileText size={16} />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
                  Study Material & Text Notes Summary
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {selectedDayDetail.textNotes}
              </p>
            </div>

            {/* Video Details */}
            <div className="bg-amber-50/60 dark:bg-amber-950/30 p-4 rounded-2xl border border-amber-200 dark:border-amber-900/50 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400">
                  <Video size={16} />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900 dark:text-amber-200">
                    Video Lecture Watched
                  </h4>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300">
                  {selectedDayDetail.videoDetails.duration}
                </span>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-amber-100 dark:border-amber-900/60 flex items-center justify-between gap-3 shadow-sm">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0">
                    <Play size={16} fill="currentColor" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-xs text-slate-900 dark:text-white truncate">
                      {selectedDayDetail.videoDetails.title}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {selectedDayDetail.videoDetails.source}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-1 rounded-md shrink-0">
                  Watched
                </span>
              </div>
              <p className="text-[11px] text-amber-900/90 dark:text-amber-300/80 leading-normal">
                {selectedDayDetail.videoDetails.description}
              </p>
            </div>

            {/* Audio Details */}
            <div className="bg-indigo-50/60 dark:bg-indigo-950/30 p-4 rounded-2xl border border-indigo-200 dark:border-indigo-900/50 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-indigo-700 dark:text-indigo-400">
                  <Headphones size={16} />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-900 dark:text-indigo-200">
                    Audio Podcast & Lecture Listened
                  </h4>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-900/60 text-indigo-800 dark:text-indigo-300">
                  {selectedDayDetail.audioDetails.duration}
                </span>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-100 dark:border-indigo-900/60 flex items-center justify-between gap-3 shadow-sm">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
                    <Volume2 size={16} />
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-xs text-slate-900 dark:text-white truncate">
                      {selectedDayDetail.audioDetails.title}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      Completed Audio Lesson
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-1 rounded-md shrink-0">
                  Listened
                </span>
              </div>
              <p className="text-[11px] text-indigo-900/90 dark:text-indigo-300/80 leading-normal">
                {selectedDayDetail.audioDetails.description}
              </p>
            </div>

            {/* Completed Tasks Checklist */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                All Steps Finished on This Day:
              </h4>
              <div className="space-y-1.5">
                {selectedDayDetail.tasksCompleted.map((tText, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
                    <CheckCircle2 size={14} className="text-emerald-500 shrink-0" />
                    <span>{tText}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Close Button */}
            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedDayDetail(null)}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold hover:opacity-90 transition-opacity shadow"
              >
                Close Day Task History
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
