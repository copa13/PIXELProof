import React, { useState, useMemo, useEffect } from 'react';
import { 
  Calendar, User, ArrowRight, ArrowLeft, Target, Bot, CheckCircle2, 
  Award, Sparkles, Cpu, Check, Activity, AlertCircle, HelpCircle, Info, X, ChevronRight, Eye,
  Bell, Clock, Smartphone, Volume2, Compass, RotateCcw, Tag
} from 'lucide-react';
import { UserProfile } from '../types';
import { translations } from '../translations';
import { 
  sendTaskReminderNotification, 
  requestNotificationPermission, 
  getNotificationPermission, 
  NotificationPermissionStatus 
} from '../utils/notification';
import { 
  aiGoalsBank, 
  getQuestionById, 
  createInitialQuizState, 
  answerQuestion, 
  undoLastQuestion,
  computeCareerMatches,
  TAG_LABELS_MR 
} from '../utils/aiGoalsEngine';
import { AiGoalsQuizState, CareerMatchResult } from '../types/aiGoals';

interface OnboardingScreenProps {
  initialProfile: UserProfile;
  language?: 'en' | 'mr' | 'hi';
  onComplete: (updatedData: {
    name?: string;
    birthDate: string;
    age: number;
    goalMode: 'self' | 'ai';
    goalName?: string;
    studentId?: string;
    targetSkills?: string[];
    reminderTime?: string;
    notificationsAllowed?: boolean;
  }) => void;
  forcedStep?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
  onStepChange?: (step: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9) => void;
}

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ 
  initialProfile, 
  language = 'en', 
  onComplete,
  forcedStep,
  onStepChange,
}) => {
  const t = translations[language];

  // Step 1: Name, Birthday & Auto Age calculation
  // Step 2: Goal Decision (Clean & Minimal)
  // Step 3: AI Bot analyzing your information / verifying goal screen
  // Step 4: Questions selection & Goal launch screen
  // Step 5: Question Gameplay Screen (Question Challenges)
  // Step 6: Calculation & Results Screen (Score, Perfect vs Incorrect Answers)
  // Step 7: AI 10 Goals Recommendation (Select 3 goals)
  // Step 8: Essential Skills for the 3 selected goals
  // Step 9: Generated Student ID & App Access card
  const [step, setStep] = useState<1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9>(forcedStep || 1);

  // Sync forcedStep from parent (DemoWindow)
  useEffect(() => {
    if (forcedStep && forcedStep >= 1 && forcedStep <= 9) {
      setStep(forcedStep);
    }
  }, [forcedStep]);

  // Report step changes to parent
  useEffect(() => {
    if (onStepChange) {
      onStepChange(step);
    }
  }, [step, onStepChange]);

  // Name State
  const [userName, setUserName] = useState<string>(initialProfile.name || '');

  // Step 1 State: Birthday
  const [birthDate, setBirthDate] = useState<string>(initialProfile.birthDate || '');

  // Auto calculate age from birthday
  const calculatedAge = useMemo(() => {
    if (!birthDate) return null;
    const birth = new Date(birthDate);
    if (isNaN(birth.getTime())) return null;

    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age >= 0 ? age : null;
  }, [birthDate]);

  // Step 2 State: What is your goal?
  const [goalMode, setGoalMode] = useState<'self' | 'ai'>(() => {
    if (initialProfile.goalMode === 'self') return 'self';
    return 'ai';
  });
  const [customGoalName, setCustomGoalName] = useState<string>(initialProfile.goalName || '');
  const [error, setError] = useState<string>('');

  // If user selected their own goal (goalMode === 'self' or custom goal provided), Step 7 (Recommended Goals) must NEVER appear
  useEffect(() => {
    const isSelfGoal = goalMode === 'self' || !!customGoalName.trim();
    if (isSelfGoal && step === 7) {
      setStep(8);
    }
  }, [goalMode, customGoalName, step]);

  // Step 3: Analysis Progress
  const [analysisProgress, setAnalysisProgress] = useState<number>(0);
  const [activeAnalysisPhase, setActiveAnalysisPhase] = useState<number>(1);
  const isScanComplete = analysisProgress >= 100;

  // Analysis simulation effect when step 3 is active
  useEffect(() => {
    if (step !== 3) return;

    setAnalysisProgress(0);
    setActiveAnalysisPhase(1);

    const interval = setInterval(() => {
      setAnalysisProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        const nextVal = Math.min(100, prev + 2);
        if (nextVal >= 80) setActiveAnalysisPhase(4);
        else if (nextVal >= 55) setActiveAnalysisPhase(3);
        else if (nextVal >= 25) setActiveAnalysisPhase(2);
        return nextVal;
      });
    }, 45);

    return () => clearInterval(interval);
  }, [step]);

  // Step 4: Question count selector (min 20, max 50)
  const [questionCount, setQuestionCount] = useState<number>(20);

  // Step 5: Question Gameplay State
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [qIndex: number]: number }>({});
  const [isCalculating, setIsCalculating] = useState<boolean>(false);

  // AI Decided Goals Quiz State (Loaded from ai_goals_questions.json)
  const [aiQuizState, setAiQuizState] = useState<AiGoalsQuizState>(() => createInitialQuizState());
  const [aiQuizSelectedOption, setAiQuizSelectedOption] = useState<number | null>(null);
  const [aiQuizBuddyNotice, setAiQuizBuddyNotice] = useState<string | null>(null);
  const [aiQuizAnimating, setAiQuizAnimating] = useState<boolean>(false);

  // Step 7 & 8: 10 Goals recommendations - Single Goal Selection, Details Modal, and Confirmation
  const [selectedGoalId, setSelectedGoalId] = useState<string>('g1');
  const [viewingGoalModal, setViewingGoalModal] = useState<any | null>(null);
  const [showConfirmGoalModal, setShowConfirmGoalModal] = useState<boolean>(false);
  const [generatedStudentId, setGeneratedStudentId] = useState<string>('');

  // Step 9: Daily Task Incomplete Reminder States
  const [selectedReminderTime, setSelectedReminderTime] = useState<string>('8:00 PM');
  const [notifPermission, setNotifPermission] = useState<NotificationPermissionStatus>(() => getNotificationPermission());
  const [testNotifToast, setTestNotifToast] = useState<string | null>(null);

  const handleRequestNotifPermission = async () => {
    const perm = await requestNotificationPermission();
    setNotifPermission(perm);
    if (perm === 'granted') {
      setTestNotifToast(language === 'mr' ? '✅ फोनवर नोटिफिकेशन्स सुरू केले!' : '✅ Phone notifications enabled!');
      setTimeout(() => setTestNotifToast(null), 3000);
    } else if (perm === 'denied') {
      setTestNotifToast(language === 'mr' ? '⚠️ ब्राऊझर सेटिंग्जमध्ये नोटिफिकेशन्स ब्लॉक आहेत.' : '⚠️ Notifications blocked in browser settings.');
      setTimeout(() => setTestNotifToast(null), 3000);
    }
  };

  const handleTestReminderNotification = async () => {
    let currentPerm = notifPermission;
    if (currentPerm === 'default') {
      currentPerm = await requestNotificationPermission();
      setNotifPermission(currentPerm);
    }
    const res = sendTaskReminderNotification({
      timeLabel: selectedReminderTime,
      body: language === 'mr'
        ? `⚠️ तुमचे आजचे टास्क पूर्ण झाले नाही! दररोज संध्याकाळी ${selectedReminderTime} वाजता असे रिमाइंडर येईल.`
        : `⚠️ Today's task is incomplete! You will receive daily alerts like this at ${selectedReminderTime}.`,
    });
    if (res.success) {
      setTestNotifToast(language === 'mr' ? `🔔 टेस्ट रिमाइंडर नोटिफिकेशन पाठवले! (${selectedReminderTime})` : `🔔 Test notification sent! (${selectedReminderTime})`);
    } else {
      setTestNotifToast(language === 'mr' ? `🔔 टेस्ट रिमाइंडर चाचणी सक्रिय (${selectedReminderTime})` : `🔔 Test reminder preview active (${selectedReminderTime})`);
    }
    setTimeout(() => setTestNotifToast(null), 3500);
  };

  // 10 Real Industry Tech Career Tracks with accurate salary and demand insights
  const REAL_CAREER_TRACKS = useMemo(() => [
    {
      id: "g1",
      title: "Full-Stack Software Engineer",
      category: "Software Development",
      baseMatch: 95,
      description: "Design end-to-end web apps, reactive user interfaces, REST & GraphQL APIs, and scalable PostgreSQL database schemas.",
      salaryRange: "₹8 - 22 LPA ($85k - $145k)",
      demand: "Very High Demand",
      skills: ["React & TypeScript", "Node.js & Express", "PostgreSQL & Prisma", "System Design & REST APIs", "Git & CI/CD Pipelines"],
      primaryDomains: ["Frontend", "Databases", "APIs", "Data Structures", "Architecture"]
    },
    {
      id: "g2",
      title: "AI & Machine Learning Engineer",
      category: "Artificial Intelligence",
      baseMatch: 93,
      description: "Train predictive ML models, fine-tune neural networks, evaluate loss functions, and deploy production LLM inference pipelines.",
      salaryRange: "₹10 - 28 LPA ($95k - $160k)",
      demand: "Exponential Growth",
      skills: ["Python & PyTorch", "Neural Networks & Loss Functions", "Feature Scaling & Data Preprocessing", "LLM APIs & Prompting", "FastAPI & Vector DBs"],
      primaryDomains: ["AI & Machine Learning", "Data Science", "Algorithms"]
    },
    {
      id: "g3",
      title: "Cloud & DevOps Solutions Architect",
      category: "Cloud & Infrastructure",
      baseMatch: 91,
      description: "Deploy and manage resilient cloud infrastructure, Docker containerization, Kubernetes clusters, and automated CI/CD pipelines.",
      salaryRange: "₹9 - 25 LPA ($90k - $150k)",
      demand: "Very High Demand",
      skills: ["Docker & Kubernetes", "Terraform & IaC", "AWS / Google Cloud", "CI/CD Pipelines", "Linux Administration"],
      primaryDomains: ["Cloud & DevOps", "CI/CD", "Infrastructure"]
    },
    {
      id: "g4",
      title: "Cybersecurity Analyst & Ethical Hacker",
      category: "Information Security",
      baseMatch: 89,
      description: "Protect systems from cyber vulnerabilities, mitigate SQL Injection & XSS threats, audit networks, and enforce TLS encryption.",
      salaryRange: "₹8 - 24 LPA ($85k - $140k)",
      demand: "Critical High Demand",
      skills: ["Network Security & Firewalls", "Penetration Testing & Audits", "SQL Injection & XSS Defense", "TLS/HTTPS Cryptography", "Linux Incident Response"],
      primaryDomains: ["Cybersecurity", "Network Security", "Encryption"]
    },
    {
      id: "g5",
      title: "Frontend Architect & UI/UX Engineer",
      category: "Frontend & UI Design",
      baseMatch: 92,
      description: "Craft modern, accessible, pixel-perfect user experiences, optimistic UI state management, and high-performance web applications.",
      salaryRange: "₹7 - 20 LPA ($80k - $135k)",
      demand: "Very High Demand",
      skills: ["React & Next.js", "Tailwind CSS & Design Systems", "Optimistic UI & Web Performance", "Accessible UI Patterns", "TypeScript State Management"],
      primaryDomains: ["Frontend", "UI/UX", "Web Performance"]
    },
    {
      id: "g6",
      title: "Data Scientist & Analytics Specialist",
      category: "Data & Business Intelligence",
      baseMatch: 88,
      description: "Analyze enterprise datasets, perform exploratory data analysis (EDA), engineer statistical features, and build BI dashboards.",
      salaryRange: "₹8 - 22 LPA ($82k - $140k)",
      demand: "High Demand",
      skills: ["Advanced SQL & Window Queries", "Python (Pandas, NumPy, Scikit-Learn)", "Feature Engineering & Scaling", "Tableau & PowerBI Dashboards", "Statistical Modeling"],
      primaryDomains: ["Data Science", "Databases", "AI & Machine Learning"]
    },
    {
      id: "g7",
      title: "Mobile App Developer (Flutter / React Native)",
      category: "Mobile Engineering",
      baseMatch: 87,
      description: "Build fluid, native-feel iOS and Android applications with offline-first local storage, lazy feed lists, and device hardware APIs.",
      salaryRange: "₹7 - 19 LPA ($78k - $130k)",
      demand: "High Demand",
      skills: ["Flutter (Dart) / React Native", "Offline-First SQLite Storage", "Mobile UI Patterns & Lazy Feeds", "Push Notifications & Device APIs", "App Store & Play Store Release"],
      primaryDomains: ["Mobile Engineering", "Frontend", "APIs"]
    },
    {
      id: "g8",
      title: "Backend & Distributed Systems Engineer",
      category: "Backend Architecture",
      baseMatch: 90,
      description: "Architect high-throughput microservices, Redis in-memory caching tiers, Kafka message queues, and low-latency databases.",
      salaryRange: "₹9 - 26 LPA ($90k - $155k)",
      demand: "Very High Demand",
      skills: ["Node.js / Go / Java", "Redis In-Memory Caching", "Apache Kafka & Message Queues", "PostgreSQL B-Tree Indexing", "Distributed Systems Reliability"],
      primaryDomains: ["Databases", "Distributed Systems", "Architecture", "Systems"]
    },
    {
      id: "g9",
      title: "Game Developer & Interactive 3D Engineer",
      category: "Gaming & Graphics",
      baseMatch: 85,
      description: "Program interactive game physics, real-time 60 FPS render loops, custom GPU shaders, and immersive spatial 3D web experiences.",
      salaryRange: "₹6 - 18 LPA ($75k - $125k)",
      demand: "Growing Niche",
      skills: ["Unity (C#) / Three.js (WebGL)", "GPU Shaders & Graphics Pipelines", "Real-Time 60 FPS Render Loops", "Physics Engines & Game Math", "3D Spatial Optimization"],
      primaryDomains: ["Gaming & Graphics", "Architecture"]
    },
    {
      id: "g10",
      title: "Product Tech Lead & Systems Architect",
      category: "Product & Architecture",
      baseMatch: 86,
      description: "Lead engineering roadmaps, enforce SOLID clean code standards, analyze production root causes, and guide technology choices.",
      salaryRange: "₹12 - 32 LPA ($110k - $175k)",
      demand: "High Senior Demand",
      skills: ["System Design & SOLID Principles", "Agile Roadmap Delivery", "Technical Mentorship & Code Reviews", "Production SRE Root Cause Analysis", "Stakeholder Communication"],
      primaryDomains: ["Architecture", "Software Engineering", "Systems"]
    }
  ], []);

  // Dynamically calculate and match 10 Real Goals based on answers to the AI Goals questions
  const aiRecommendedGoals = useMemo(() => {
    const computed = computeCareerMatches(aiQuizState.tagScores, aiQuizState.track);
    return REAL_CAREER_TRACKS.map((goal, idx) => {
      const matchItem = computed[idx];
      return {
        ...goal,
        match: matchItem ? matchItem.matchPercent : goal.baseMatch,
        matchReason: matchItem ? matchItem.whyText : `Foundational alignment with ${goal.title}.`
      };
    }).sort((a, b) => b.match - a.match);
  }, [REAL_CAREER_TRACKS, aiQuizState]);

  // Backward-compatible alias
  const AI_RECOMMENDED_10_GOALS = aiRecommendedGoals;

  // Helper to generate a unique Student ID (e.g. SPA-RID-2004)
  const generateStudentId = (nameStr: string, bDate: string) => {
    const cleanName = (nameStr || "STUDENT").trim().replace(/[^a-zA-Z]/g, "").toUpperCase();
    const namePart = (cleanName.length >= 3 ? cleanName.substring(0, 3) : (cleanName + "ABC").substring(0, 3));
    let birthYear = "2004";
    if (bDate) {
      const parts = bDate.split("-");
      if (parts[0] && parts[0].length === 4) {
        birthYear = parts[0];
      }
    }
    return `SPA-${namePart}-${birthYear}`;
  };

  // Score Calculation
  const calculationResult = useMemo(() => {
    const totalQ = Math.max(1, aiQuizState.questionNumber - 1 || 15);
    const perfectCount = Math.round(totalQ * 0.9);
    const incorrectCount = totalQ - perfectCount;
    const percent = Math.min(100, Math.round((perfectCount / totalQ) * 100));
    return { perfectCount, incorrectCount, totalQ, percent };
  }, [aiQuizState]);

  useEffect(() => {
    if (step >= 7 && !selectedGoalId) {
      setSelectedGoalId("g1");
    }
  }, [step, selectedGoalId]);

  // Active Goal for Step 8 Skills breakdown
  const activeGoal = useMemo(() => {
    if (goalMode === 'self') {
      const match = AI_RECOMMENDED_10_GOALS.find(g => g.title.toLowerCase() === customGoalName.toLowerCase());
      if (match) return match;
      return {
        id: 'custom',
        title: customGoalName.trim() || 'Custom Career Goal',
        category: 'Personal Goal',
        match: 92,
        description: `Customized career track for ${userName || 'Student'}: ${customGoalName.trim() || 'Custom Career Goal'}.`,
        skills: ['Core Fundamentals', 'Technical Problem Solving', 'Database Design', 'System Architecture', 'Production Deployment'],
      };
    }
    return AI_RECOMMENDED_10_GOALS.find(g => g.id === selectedGoalId) || AI_RECOMMENDED_10_GOALS[0];
  }, [goalMode, customGoalName, selectedGoalId, userName]);

  // Derived Achieved Skills & Missing Skills based on questions performance
  const skillsEvaluation = useMemo(() => {
    const allGoalSkills = activeGoal.skills;
    const accuracy = calculationResult.percent;
    // Calculate achieved count based on quiz accuracy (min 2, max skills.length - 1 so at least 1 missing skill is present)
    let achievedCount = Math.max(1, Math.min(allGoalSkills.length - 1, Math.round((accuracy / 100) * allGoalSkills.length)));
    if (achievedCount >= allGoalSkills.length) {
      achievedCount = allGoalSkills.length - 1;
    }
    if (achievedCount < 2 && allGoalSkills.length >= 3) {
      achievedCount = 2;
    }

    const achieved = allGoalSkills.slice(0, achievedCount).map((skill, i) => ({
      name: skill,
      level: `${Math.min(98, 75 + i * 7)}% Verified`,
      status: 'Mastered',
      reason: 'Strong concept retention demonstrated during challenge questions',
    }));

    const missing = allGoalSkills.slice(achievedCount).map((skill) => ({
      name: skill,
      level: 'Roadmap Target',
      status: 'To Learn',
      reason: `Essential capability needed to achieve ${activeGoal.title}`,
    }));

    return { achieved, missing };
  }, [activeGoal, calculationResult.percent]);

  // Handlers for steps
  const handleProceedToStep4 = () => {
    setStep(4);
  };

  const handleStartQuestions = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswers({});
    if (goalMode === 'ai') {
      setAiQuizState(createInitialQuizState());
      setAiQuizSelectedOption(null);
      setAiQuizBuddyNotice(null);
      setAiQuizAnimating(false);
    }
    setStep(5);
  };

  const handleAiQuizOptionClick = (index: number) => {
    if (aiQuizAnimating) return;
    setAiQuizSelectedOption(index);
    setAiQuizAnimating(true);

    const { newState, buddyMessage } = answerQuestion(aiQuizState, index);
    setAiQuizBuddyNotice(buddyMessage);

    setTimeout(() => {
      setAiQuizState(newState);
      setAiQuizSelectedOption(null);
      setAiQuizAnimating(false);
      if (newState.isFinished) {
        setStep(6);
      }
    }, 450);
  };

  const handleAiQuizBack = () => {
    if (aiQuizState.history.length === 0) {
      setStep(4);
      return;
    }
    const rolledBack = undoLastQuestion(aiQuizState);
    setAiQuizState(rolledBack);
    setAiQuizSelectedOption(null);
    setAiQuizBuddyNotice(null);
  };

  const handleProceedFromResults = () => {
    if (goalMode === 'self' || !!customGoalName.trim()) {
      // User selected their own goal, skip Recommended Goals completely!
      setStep(8);
    } else {
      setStep(7); // Show 10 goals only for AI exploration mode
    }
  };

  const handleSelectGoal = (id: string) => {
    setSelectedGoalId(id);
    const chosenGoal = AI_RECOMMENDED_10_GOALS.find(g => g.id === id);
    if (chosenGoal) {
      setCustomGoalName(chosenGoal.title);
    }
  };

  const handlePromptConfirmGoal = () => {
    if (!selectedGoalId) {
      setError('Please select a goal.');
      return;
    }
    setError('');
    setShowConfirmGoalModal(true);
  };

  const handleConfirmAndProceedToSkills = () => {
    const chosenGoal = AI_RECOMMENDED_10_GOALS.find(g => g.id === selectedGoalId);
    if (chosenGoal) {
      setCustomGoalName(chosenGoal.title);
    }
    setShowConfirmGoalModal(false);
    setStep(8);
  };

  const handleProceedToStudentId = () => {
    const sId = generateStudentId(userName, birthDate);
    setGeneratedStudentId(sId);
    setStep(9);
  };

  const handleFinalAppEntry = () => {
    const chosenGoalObj = AI_RECOMMENDED_10_GOALS.find(g => g.id === selectedGoalId) || AI_RECOMMENDED_10_GOALS[0];
    const finalGoalName = goalMode === 'self'
      ? (customGoalName.trim() || 'Custom Goal')
      : chosenGoalObj.title;

    const gatheredSkills = goalMode === 'ai'
      ? chosenGoalObj.skills
      : activeGoal.skills;

    onComplete({
      name: userName.trim() || initialProfile.name,
      birthDate,
      age: calculatedAge || 0,
      goalMode,
      goalName: finalGoalName,
      studentId: generatedStudentId || generateStudentId(userName, birthDate),
      targetSkills: gatheredSkills,
      reminderTime: selectedReminderTime,
      notificationsAllowed: notifPermission === 'granted',
    });
  };

  const handleNextToStep2 = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim()) {
      setError('Please enter your Name.');
      return;
    }
    if (!birthDate) {
      setError('Please select your Birth Date.');
      return;
    }
    if (calculatedAge === null || calculatedAge < 5 || calculatedAge > 120) {
      setError('Please enter a valid birth date.');
      return;
    }
    setError('');
    setStep(2);
  };

  const handleStartAnalysis = (e: React.FormEvent) => {
    e.preventDefault();
    if (goalMode === 'self') {
      if (!customGoalName.trim()) {
        setError(language === 'mr' ? 'कृपया ध्येयाचे नाव प्रविष्ट करा.' : 'Please enter your goal name.');
        return;
      }
    }

    setError('');
    setStep(3);
  };

  const displayedGoalTitle = goalMode === 'self'
    ? (customGoalName.trim() || (language === 'mr' ? 'तुमचे निवडलेले ध्येय' : 'Your Goal'))
    : (language === 'mr' ? 'AI करिअर पाथवे' : 'AI Career Pathway');

  return (
    <div className="min-h-screen w-full bg-slate-900 flex flex-col justify-center px-4 sm:px-6 py-8 relative overflow-hidden text-slate-100">
      {/* Background Glowing Ambient Orbs */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-sky-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

      {/* App Icon Zooming into Background Animation */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden z-0 select-none">
        <div className="relative w-72 h-72 sm:w-96 sm:h-96 md:w-[460px] md:h-[460px] animate-icon-zoom-bg">
          <img
            src="/pwa-192x192.png"
            alt="App Background Watermark"
            className="w-full h-full object-contain rounded-3xl"
          />
        </div>
      </div>

      <div className="w-full max-w-lg mx-auto relative z-10 space-y-4 animate-content-delayed">
        {/* Subtle top progress bar */}
        <div className="flex items-center justify-center gap-2 pb-1">
          <div className={`h-1.5 rounded-full transition-all duration-300 ${step === 1 ? 'w-10 bg-sky-500 shadow-sm shadow-sky-500/50' : 'w-4 bg-emerald-500'}`} />
          <div className={`h-1.5 rounded-full transition-all duration-300 ${step === 2 ? 'w-10 bg-sky-500 shadow-sm shadow-sky-500/50' : step > 2 ? 'w-4 bg-emerald-500' : 'w-4 bg-slate-700/80'}`} />
          <div className={`h-1.5 rounded-full transition-all duration-300 ${step === 3 ? 'w-10 bg-gradient-to-r from-sky-400 to-indigo-400 shadow-sm shadow-sky-500/50' : step > 3 ? 'w-4 bg-emerald-500' : 'w-4 bg-slate-700/80'}`} />
          <div className={`h-1.5 rounded-full transition-all duration-300 ${step === 4 ? 'w-10 bg-gradient-to-r from-indigo-400 to-cyan-400 shadow-sm shadow-indigo-500/50' : 'w-4 bg-slate-700/80'}`} />
        </div>

        {error && (
          <div className="p-3.5 rounded-2xl bg-rose-950/70 border border-rose-800 text-rose-300 text-xs text-center font-semibold animate-in shake">
            {error}
          </div>
        )}

        {/* STEP 1: Name, Birthday & Auto Age calculation (in English as requested) */}
        {step === 1 && (
          <div className="bg-slate-800/80 backdrop-blur-md rounded-3xl p-6 sm:p-7 border border-slate-700/80 shadow-2xl space-y-5 animate-in fade-in">
            <div>
              <h2 className="text-xl font-extrabold text-white">What is your Name & Age?</h2>
            </div>

            <form onSubmit={handleNextToStep2} className="space-y-4">
              {/* Name field in English */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <User size={15} className="text-sky-400" />
                  <span>What is your Name?</span>
                </label>
                <input
                  type="text"
                  value={userName}
                  onChange={e => setUserName(e.target.value)}
                  placeholder="Enter your name"
                  required
                  className="w-full px-4 py-3 rounded-2xl bg-slate-900/90 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all"
                />
              </div>

              {/* Birth date field in English */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Calendar size={15} className="text-sky-400" />
                  <span>Birth Date</span>
                </label>
                <div className="relative">
                  <input
                    type="date"
                    value={birthDate}
                    max={new Date().toISOString().split('T')[0]}
                    onChange={e => setBirthDate(e.target.value)}
                    required
                    className="w-full px-4 py-3 rounded-2xl bg-slate-900/90 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all [color-scheme:dark]"
                  />
                </div>
              </div>

              {/* Auto calculated Age Box in English */}
              <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-700/80 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center font-bold text-base border border-sky-500/20">
                    <User size={18} />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Auto Calculated</span>
                    <h3 className="font-bold text-sm text-white">Your Age</h3>
                  </div>
                </div>

                <div className="text-right">
                  {calculatedAge !== null ? (
                    <div className="inline-flex items-baseline gap-1 bg-sky-500/20 text-sky-300 px-3 py-1.5 rounded-xl border border-sky-500/30">
                      <span className="text-xl font-black">{calculatedAge}</span>
                      <span className="text-xs font-semibold text-sky-400">Years</span>
                    </div>
                  ) : (
                    <span className="text-xs text-slate-500 italic">Select date above</span>
                  )}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-extrabold text-sm shadow-xl shadow-sky-600/30 transition-all flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer"
              >
                <span>Continue</span>
                <ArrowRight size={18} />
              </button>
            </form>
          </div>
        )}

        {/* STEP 2: What is your goal? (Clean & Minimal, no verbose text) */}
        {step === 2 && (
          <div className="bg-slate-800/80 backdrop-blur-md rounded-3xl p-6 sm:p-7 border border-slate-700/80 shadow-2xl space-y-5 animate-in fade-in">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
              >
                <ArrowLeft size={14} /> {t.back}
              </button>
              {calculatedAge !== null && (
                <span className="text-[11px] font-semibold text-sky-400 bg-sky-950/80 px-2.5 py-0.5 rounded-full border border-sky-800/50">
                  {t.ageBadge}: {calculatedAge} {t.years}
                </span>
              )}
            </div>

            <div>
              <h2 className="text-xl font-extrabold text-white">{t.whatIsYourGoal}</h2>
            </div>

            <form onSubmit={handleStartAnalysis} className="space-y-4">
              {/* The 2 Goal Options (Minimal, no big descriptions) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Option 1: AI Decides */}
                <div
                  onClick={() => {
                    setGoalMode('ai');
                    setError('');
                  }}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    goalMode === 'ai'
                      ? 'bg-sky-500/15 border-sky-500 shadow-md shadow-sky-500/10'
                      : 'bg-slate-900/60 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl shrink-0 ${
                      goalMode === 'ai' ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-400'
                    }`}>
                      <Bot size={18} />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-white">{t.aiDecide}</h3>
                      <span className="text-[11px] text-sky-400 font-medium">{t.aiDecideDesc}</span>
                    </div>
                  </div>
                  {goalMode === 'ai' && (
                    <CheckCircle2 size={18} className="text-sky-400 shrink-0" />
                  )}
                </div>

                {/* Option 2: Decide Yourself */}
                <div
                  onClick={() => {
                    setGoalMode('self');
                    setError('');
                  }}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    goalMode === 'self'
                      ? 'bg-indigo-500/15 border-indigo-500 shadow-md shadow-indigo-500/10'
                      : 'bg-slate-900/60 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl shrink-0 ${
                      goalMode === 'self' ? 'bg-indigo-500 text-white' : 'bg-slate-800 text-slate-400'
                    }`}>
                      <Target size={18} />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-white">{t.decideYourself}</h3>
                      <span className="text-[11px] text-indigo-400 font-medium">{t.decideYourselfDesc}</span>
                    </div>
                  </div>
                  {goalMode === 'self' && (
                    <CheckCircle2 size={18} className="text-indigo-400 shrink-0" />
                  )}
                </div>
              </div>

              {/* Input: Goal Name ONLY if Self option is selected */}
              {goalMode === 'self' && (
                <div className="space-y-1.5 pt-1 animate-in fade-in slide-in-from-top-2">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Award size={14} className="text-indigo-400" />
                    <span>{t.goalNameLabel}</span>
                  </label>
                  <input
                    type="text"
                    value={customGoalName}
                    onChange={e => setCustomGoalName(e.target.value)}
                    placeholder={t.goalNamePlaceholder}
                    required
                    className="w-full px-4 py-3 rounded-2xl bg-slate-900/90 border border-indigo-500/50 text-white placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  />
                </div>
              )}

              {/* Start Button */}
              <button
                type="submit"
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-sky-600 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-white font-black text-sm sm:text-base shadow-xl shadow-sky-600/30 transition-all flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer mt-2"
              >
                <span>{t.startApp}</span>
                <ArrowRight size={18} />
              </button>
            </form>
          </div>
        )}

        {/* STEP 3: AI Bot Analyzing Your Information Screen */}
        {step === 3 && (
          <div className="bg-slate-800/90 backdrop-blur-xl rounded-3xl p-6 sm:p-8 border border-sky-500/30 shadow-2xl space-y-6 animate-in fade-in zoom-in-95 text-center relative overflow-hidden">
            {/* Ambient Cybernetic Radial Glow */}
            <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-80 h-80 bg-sky-500/20 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-24 right-1/2 translate-x-1/2 w-80 h-80 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

            {/* Redesigned Futuristic AI Bot & Holographic Scanning Chamber */}
            <div className="flex flex-col items-center justify-center pt-2">
              <div className="relative flex items-center justify-center w-48 h-48 sm:w-52 sm:h-52">
                {/* Outer Radar Ring with sweep beam */}
                <div className="absolute inset-0 rounded-full border border-sky-500/20" />
                <div className="absolute inset-0 rounded-full border-2 border-t-sky-400 border-r-transparent border-b-indigo-500 border-l-transparent animate-radar-sweep opacity-75" />
                
                {/* Concentric Pulse Waves */}
                <div className="absolute inset-4 rounded-full border border-cyan-400/30 animate-ripple" />
                <div className="absolute inset-8 rounded-full border border-indigo-400/40 animate-[spin_8s_linear_infinite]" style={{ borderStyle: 'dotted' }} />

                {/* AI Core Holographic Orb */}
                <div className={`relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl p-1 transition-all duration-500 ${
                  isScanComplete
                    ? 'bg-gradient-to-tr from-sky-400 via-indigo-500 to-cyan-400 shadow-[0_0_35px_rgba(56,189,248,0.45)]'
                    : 'bg-gradient-to-tr from-cyan-400 via-sky-500 to-indigo-600 shadow-[0_0_35px_rgba(56,189,248,0.4)] animate-hologram'
                }`}>
                  <div className="w-full h-full bg-slate-950/95 rounded-[22px] flex flex-col items-center justify-center relative overflow-hidden">
                    {/* Futuristic Grid Backdrop */}
                    <div className="absolute inset-0 bg-[radial-gradient(#38bdf8_1.5px,transparent_1.5px)] [background-size:12px_12px] opacity-20" />

                    {/* Cybernetic High-Tech Scanning Laser (active while scanning) */}
                    {!isScanComplete && (
                      <>
                        <div className="absolute left-1 right-1 h-1 bg-gradient-to-r from-transparent via-cyan-300 to-transparent shadow-[0_0_15px_#22d3ee] animate-cyber-scan z-20 pointer-events-none" />
                        <div className="absolute inset-x-0 h-10 bg-gradient-to-b from-cyan-500/20 to-transparent animate-cyber-scan z-10 pointer-events-none" />
                      </>
                    )}

                    {/* Center Bot & Neural AI Icon */}
                    <div className="relative z-10 flex flex-col items-center justify-center">
                      {isScanComplete ? (
                        <div className="relative">
                          <CheckCircle2 size={54} className="text-sky-300 stroke-[2] drop-shadow-[0_0_20px_rgba(56,189,248,0.8)] animate-in zoom-in-75 duration-300" />
                          <Sparkles size={20} className="absolute -top-2 -right-2 text-cyan-300 animate-bounce" />
                        </div>
                      ) : (
                        <div className="relative">
                          {/* Modern Robotic / Target Core */}
                          <div className="relative p-2 rounded-2xl bg-sky-950/40 border border-sky-400/30">
                            {goalMode === 'self' ? (
                              <Target size={46} className="text-indigo-300 stroke-[1.8] drop-shadow-[0_0_16px_rgba(99,102,241,0.8)]" />
                            ) : (
                              <Bot size={46} className="text-cyan-300 stroke-[1.8] drop-shadow-[0_0_16px_rgba(34,211,238,0.8)]" />
                            )}
                            {/* Glowing pulses */}
                            <span className="absolute top-5 left-5 w-1.5 h-1.5 bg-white rounded-full shadow-[0_0_6px_#ffffff] animate-ping" />
                            <span className="absolute top-5 right-5 w-1.5 h-1.5 bg-white rounded-full shadow-[0_0_6px_#ffffff] animate-ping" />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Status Capsule Indicator */}
                <div className={`absolute -bottom-3 px-3.5 py-1 rounded-full border shadow-lg flex items-center gap-1.5 z-20 transition-all ${
                  isScanComplete
                    ? 'bg-slate-900/90 border-sky-400/60 text-sky-300'
                    : 'bg-slate-900/90 border-cyan-400/50 text-cyan-300'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${isScanComplete ? 'bg-sky-400' : 'bg-cyan-400 animate-ping'}`} />
                  <span className="text-[10px] font-black uppercase tracking-wider">
                    {isScanComplete
                      ? (goalMode === 'self' ? 'GOAL VERIFIED' : 'ANALYSIS COMPLETE')
                      : (goalMode === 'self' ? 'VERIFYING GOAL' : 'AI SCANNING')}
                  </span>
                </div>
              </div>
            </div>

            {/* Header: Displays selected goal name and scanning / verification state */}
            <div className="space-y-1.5 pt-1">
              {goalMode === 'self' ? (
                <>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/15 border border-indigo-400/30 text-indigo-300 text-xs font-semibold">
                    <Target size={13} />
                    <span>{displayedGoalTitle}</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-sky-200 via-indigo-300 to-cyan-200 tracking-wide">
                    {isScanComplete
                      ? (language === 'mr' ? 'ध्येयाचे तपशील पडताळले (Goal Details Verified)' : 'Goal Details Verified')
                      : (language === 'mr' ? `'${displayedGoalTitle}' स्कॅन होत आहे आणि तपशील पडताळले जात आहेत...` : `Scanning '${displayedGoalTitle}' & Verifying Details...`)}
                  </h2>
                </>
              ) : (
                <h2 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-sky-200 via-cyan-300 to-indigo-200 tracking-wide">
                  {isScanComplete ? (language === 'mr' ? 'माहितीचे विश्लेषण पूर्ण झाले' : 'Analysis Complete') : 'Analyzing your information'}
                </h2>
              )}
            </div>

            {/* Clean, Non-Green Progress Card */}
            <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-700/80 text-left space-y-2.5">
              <div className="flex items-center justify-between text-xs px-0.5">
                <span className="text-slate-400 font-medium flex items-center gap-1.5">
                  <Activity size={14} className={isScanComplete ? 'text-sky-400' : 'text-cyan-400 animate-spin'} />
                  <span>
                    {isScanComplete
                      ? (goalMode === 'self'
                          ? (language === 'mr' ? 'ध्येय पडताळणी पूर्ण!' : 'Goal Verified!')
                          : (language === 'mr' ? 'तयार आहे!' : 'Ready!'))
                      : (goalMode === 'self'
                          ? (language === 'mr' ? 'ध्येय स्कॅनिंग आणि तपशील पडताळणी...' : 'Scanning goal & verifying details...')
                          : (language === 'mr' ? 'स्कॅनिंग चालू आहे...' : 'Scanning in progress...'))}
                  </span>
                </span>
                <span className="font-black tabular-nums text-sky-400">
                  {analysisProgress}%
                </span>
              </div>

              {/* Progress Bar in Sleek Sky & Indigo */}
              <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700">
                <div
                  className="h-full rounded-full transition-all duration-150 bg-gradient-to-r from-cyan-400 via-sky-500 to-indigo-500 shadow-[0_0_12px_rgba(56,189,248,0.5)]"
                  style={{ width: `${analysisProgress}%` }}
                />
              </div>

              {/* Minimal Step Checkers */}
              <div className="grid grid-cols-3 gap-1.5 pt-1 text-[10px]">
                <div className={`flex items-center gap-1 px-2 py-1 rounded-lg border transition-colors ${analysisProgress >= 30 ? 'bg-sky-950/40 border-sky-800/60 text-sky-300' : 'bg-slate-950/40 border-slate-800 text-slate-500'}`}>
                  <Check size={11} className={analysisProgress >= 30 ? 'text-sky-400' : 'text-slate-600'} />
                  <span className="truncate">{goalMode === 'self' ? 'Goal Selected' : 'Profile'}</span>
                </div>
                <div className={`flex items-center gap-1 px-2 py-1 rounded-lg border transition-colors ${analysisProgress >= 70 ? 'bg-sky-950/40 border-sky-800/60 text-sky-300' : 'bg-slate-950/40 border-slate-800 text-slate-500'}`}>
                  <Check size={11} className={analysisProgress >= 70 ? 'text-sky-400' : 'text-slate-600'} />
                  <span className="truncate">{goalMode === 'self' ? 'Verify Details' : 'Goals'}</span>
                </div>
                <div className={`flex items-center gap-1 px-2 py-1 rounded-lg border transition-colors ${analysisProgress >= 100 ? 'bg-indigo-950/40 border-indigo-800/60 text-indigo-300' : 'bg-slate-950/40 border-slate-800 text-slate-500'}`}>
                  <Check size={11} className={analysisProgress >= 100 ? 'text-indigo-400' : 'text-slate-600'} />
                  <span className="truncate">{goalMode === 'self' ? 'Ready' : 'Pathway'}</span>
                </div>
              </div>
            </div>

            {/* Action Button: When complete, Continue proceeds to Step 4 (Let's start question games / Let's check your goal progress) */}
            <div className="pt-2">
              {isScanComplete ? (
                <button
                  type="button"
                  onClick={handleProceedToStep4}
                  className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-sky-500 via-indigo-600 to-cyan-500 hover:from-sky-400 hover:to-indigo-500 text-white font-black text-sm sm:text-base shadow-xl shadow-sky-600/30 transition-all flex items-center justify-center gap-2.5 active:scale-[0.99] cursor-pointer animate-in zoom-in-95"
                >
                  <span>{language === 'mr' ? 'पुढे जा (Continue)' : 'Continue'}</span>
                  <ArrowRight size={20} className="stroke-[2.5]" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleProceedToStep4}
                  className="w-full py-3 px-4 rounded-2xl bg-slate-900/80 hover:bg-slate-700/80 border border-slate-700 text-slate-400 hover:text-white font-medium text-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>{language === 'mr' ? 'प्रतीक्षा करा किंवा पुढे जा' : 'Skip & Continue'}</span>
                  <ArrowRight size={14} />
                </button>
              )}
            </div>
          </div>
        )}

        {/* STEP 4: Next Screen Based on Goal Mode (Questions Selection & Active AI Chat Bot) */}
        {step === 4 && (
          <div className="bg-slate-800/90 backdrop-blur-xl rounded-3xl p-6 sm:p-8 border border-sky-500/30 shadow-2xl space-y-6 animate-in fade-in zoom-in-95 text-center relative overflow-hidden">
            {/* Active AI Chat Bot with continuous eye movements and reactions */}
            <div className="flex flex-col items-center justify-center pt-1 space-y-3">
              <div className="relative animate-bot-float">
                {/* Active Outer Aura */}
                <div className="absolute -inset-2 rounded-3xl bg-gradient-to-r from-sky-500/30 via-cyan-400/30 to-indigo-500/30 blur-md pointer-events-none" />

                {/* AI Chat Bot Pod */}
                <div className="relative w-24 h-24 rounded-3xl p-1 bg-gradient-to-tr from-cyan-400 via-sky-500 to-indigo-500 shadow-[0_0_25px_rgba(56,189,248,0.45)]">
                  <div className="w-full h-full bg-slate-950 rounded-[20px] flex flex-col items-center justify-center relative overflow-hidden p-2">
                    {/* Bot Head Antenna / Status Light */}
                    <div className="absolute top-1.5 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      <span className="text-[8px] font-black tracking-wider text-emerald-400 uppercase">ONLINE</span>
                    </div>

                    {/* Cute Futuristic Face Screen with Active Moving Eyes */}
                    <div className="w-16 h-10 bg-slate-900/90 rounded-2xl border border-cyan-400/40 flex items-center justify-center gap-2.5 px-2 shadow-inner relative mt-2">
                      {/* Left Eye with Blink and Pupil Motion */}
                      <div className="relative w-3.5 h-4 bg-cyan-400 rounded-full flex items-center justify-center animate-bot-eye shadow-[0_0_8px_#22d3ee]">
                        <div className="w-1.5 h-1.5 bg-white rounded-full animate-bot-pupil" />
                      </div>

                      {/* Right Eye with Blink and Pupil Motion */}
                      <div className="relative w-3.5 h-4 bg-cyan-400 rounded-full flex items-center justify-center animate-bot-eye shadow-[0_0_8px_#22d3ee]">
                        <div className="w-1.5 h-1.5 bg-white rounded-full animate-bot-pupil" />
                      </div>

                      {/* Happy curved mouth line */}
                      <div className="absolute bottom-1 w-3 h-1 border-b-2 border-cyan-300 rounded-full" />
                    </div>

                    {/* Subtle micro wave pulses */}
                    <div className="absolute bottom-1 flex items-center gap-1">
                      <span className="w-1 h-1 rounded-full bg-sky-400 animate-pulse" />
                      <span className="w-1 h-1 rounded-full bg-indigo-400 animate-pulse delay-75" />
                      <span className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse delay-150" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Exact Screen Titles requested by User (Without the subtitle) */}
              {goalMode === 'ai' ? (
                <div className="space-y-1">
                  <h2 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-sky-200 via-cyan-300 to-indigo-200">
                    lets start qution gems aand diside your gole
                  </h2>
                </div>
              ) : (
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/40 text-indigo-300 text-xs font-semibold mb-1">
                    <Target size={13} />
                    <span>{displayedGoalTitle}</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 via-sky-300 to-cyan-200">
                    lets chack your gole progress
                  </h2>
                </div>
              )}
            </div>

            {/* 15 Career Questions Assessment Card (No min/max slider needed as requested) */}
            <div className="bg-slate-900/80 border border-slate-700/80 rounded-2xl p-4 sm:p-5 text-left space-y-3.5">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-400 to-indigo-500 p-0.5 flex items-center justify-center">
                    <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center text-sky-400">
                      <Sparkles size={16} />
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-white">
                      {language === 'mr' ? '१५ करिअर प्रश्न चाचणी' : '15 Career Assessment Questions'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {language === 'mr' ? 'तुमचे खरे कौशल्य व करिअर ध्येय ठरवण्यासाठी' : 'To determine your best-fit career goal'}
                    </p>
                  </div>
                </div>
                <div className="px-3 py-1 rounded-xl bg-sky-500/20 border border-sky-400/40 text-sky-300 font-black text-sm tabular-nums">
                  15 Qs
                </div>
              </div>

              {/* Assessment Breakdown Chips */}
              <div className="space-y-1.5 pt-1">
                <p className="text-xs text-slate-300 leading-relaxed">
                  {language === 'mr' 
                    ? 'या १५ रिअल प्रश्नांच्या उत्तरांवरून AI तुमची आवड, टेक्निकल समज आणि कौशल्ये तपासून सर्वात योग्य करिअर ध्येय (Goal) ठरवेल.' 
                    : 'AI will analyze your problem solving, technical concepts, and domain affinity across 10 engineering tracks to match your goal.'}
                </p>
                <div className="flex flex-wrap gap-1.5 pt-1.5">
                  {['Frontend', 'AI & ML', 'Databases', 'DevOps', 'Cybersecurity', 'Backend', 'Mobile', 'Data Science'].map((domain) => (
                    <span 
                      key={domain} 
                      className="px-2.5 py-1 rounded-lg bg-slate-800/80 text-[10px] font-semibold text-slate-300 border border-slate-700/80"
                    >
                      {domain}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Buttons: Launch Questions Challenge */}
            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={handleStartQuestions}
                className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-sky-500 via-indigo-600 to-cyan-500 hover:from-sky-400 hover:to-indigo-500 text-white font-black text-sm sm:text-base shadow-xl shadow-sky-600/30 transition-all flex items-center justify-center gap-2.5 active:scale-[0.99] cursor-pointer"
              >
                <span>{language === 'mr' ? 'प्रश्नांची उत्तरे सुरू करा (Start Questions)' : 'Start Question Challenge'}</span>
                <ArrowRight size={20} className="stroke-[2.5]" />
              </button>

              <button
                type="button"
                onClick={() => setStep(3)}
                className="text-xs font-semibold text-slate-400 hover:text-white flex items-center justify-center gap-1 transition-colors cursor-pointer mx-auto pt-1"
              >
                <ArrowLeft size={13} /> {language === 'mr' ? 'मागे जा' : 'Back to Scan'}
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: Questions Gameplay Screen */}
        {step === 5 && (
          /* Question Screen (Strictly loaded from ai_goals_questions.json with branching & undo) */
          (() => {
            const currentQ = getQuestionById(aiQuizState.currentQuestionId);
            const progressPercent = Math.min(100, Math.round(((aiQuizState.questionNumber - 1) / 15) * 100));

            return (
              <div className="bg-slate-800/95 backdrop-blur-xl rounded-3xl p-5 sm:p-7 border border-sky-500/30 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 text-left relative overflow-hidden">
                {/* Top Bar: Back, प्रश्न X / 15, and Category */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-700/80 gap-3">
                  <button
                    type="button"
                    onClick={handleAiQuizBack}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-750 transition active:scale-95 cursor-pointer"
                  >
                    <ArrowLeft size={15} />
                    <span>{aiQuizState.questionNumber > 1 ? "मागे जा" : "मागे"}</span>
                  </button>

                  {/* Central Progress Title: प्रश्न X / 15 format */}
                  <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-sky-500/20 border border-sky-400/40 text-sky-300 text-xs font-black tracking-wide">
                    <Compass size={13} />
                    <span>{`प्रश्न ${aiQuizState.questionNumber} / 15`}</span>
                  </div>

                  {currentQ?.category && (
                    <span className="text-[11px] font-bold text-indigo-300 bg-indigo-500/20 border border-indigo-400/30 px-2.5 py-0.5 rounded-lg">
                      {currentQ.category}
                    </span>
                  )}
                </div>

                {/* Progress Bar (1..15) */}
                <div className="space-y-1">
                  <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-700">
                    <div
                      className="h-full bg-gradient-to-r from-sky-400 via-indigo-500 to-emerald-400 rounded-full transition-all duration-300 ease-out shadow-xs"
                      style={{ width: `${Math.max(6, progressPercent)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-400 px-0.5">
                    <span>सुरुवात (Q1)</span>
                    <span className="font-semibold text-sky-400">{aiQuizState.questionNumber}/15 पूर्ण</span>
                    <span>ध्येय (Result)</span>
                  </div>
                </div>

                {/* Friendly Buddy (🦉) encouraging banner shown after answers */}
                {aiQuizBuddyNotice && (
                  <div className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-400/40 text-amber-200 text-xs font-medium flex items-center gap-2.5 animate-in slide-in-from-top-2 duration-300 shadow-xs">
                    <span className="text-xl">🦉</span>
                    <p className="flex-1 leading-snug">{aiQuizBuddyNotice}</p>
                  </div>
                )}

                {/* Question Text */}
                <div className="bg-slate-900/80 rounded-2xl p-4 sm:p-5 border border-slate-700/80 space-y-1">
                  <h3 className="text-base sm:text-lg font-bold text-white leading-relaxed">
                    {currentQ?.text || "प्रश्न लोड होत आहे..."}
                  </h3>
                </div>

                {/* Large Rounded Option Cards */}
                <div className="space-y-3 pt-1">
                  {currentQ?.options?.map((opt, idx) => {
                    const isSelected = aiQuizSelectedOption === idx;
                    const optionLetters = ["A", "B", "C", "D", "E"];
                    const letterBadge = optionLetters[idx] || `${idx + 1}`;

                    return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => handleAiQuizOptionClick(idx)}
                        disabled={aiQuizAnimating}
                        className={`w-full text-left p-4 sm:p-4.5 rounded-2xl border transition-all duration-200 flex items-center justify-between gap-3.5 cursor-pointer select-none group active:scale-[0.99] ${
                          isSelected
                            ? "border-sky-400 bg-sky-500/25 text-white ring-2 ring-sky-400/30 shadow-md scale-[1.01]"
                            : "border-slate-700 bg-slate-900/70 hover:border-sky-500 hover:bg-slate-850 text-slate-200 shadow-xs"
                        }`}
                      >
                        <div className="flex items-center gap-3.5 flex-1">
                          <span className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 transition-colors ${
                            isSelected
                              ? "bg-sky-500 text-white shadow-xs"
                              : "bg-slate-800 text-slate-300 group-hover:bg-sky-500/30 group-hover:text-sky-300"
                          }`}>
                            {letterBadge}
                          </span>
                          <span className="text-xs sm:text-sm font-semibold leading-normal flex-1">
                            {opt.text}
                          </span>
                        </div>

                        <div className={`w-6 h-6 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                          isSelected ? "border-sky-400 bg-sky-500 text-white" : "border-slate-600 text-transparent"
                        }`}>
                          <CheckCircle2 size={15} />
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Bottom Navigation Info */}
                <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-700/60">
                  <span>पर्याय निवडून पुढे चला</span>
                  {aiQuizState.history.length > 0 && (
                    <button
                      type="button"
                      onClick={handleAiQuizBack}
                      className="text-sky-400 hover:underline font-semibold cursor-pointer"
                    >
                      मागील प्रश्न दुरुस्त करा
                    </button>
                  )}
                </div>
              </div>
            );
          })()
        )}

        {/* STEP 6: Result Screen */}
        {step === 6 && (
          goalMode === 'ai' ? (
            /* AI Decided Goals Result Screen (Top Career as 'तुमचं ध्येय', Circular Match %, next 2-4 cards, Marathi why text, 'हे करिअर निवडा' button) */
            (() => {
              const matches = computeCareerMatches(aiQuizState.tagScores, aiQuizState.track);
              const topCareerMatch = matches[0];
              const otherMatches = matches.slice(1, 4);

              return (
                <div className="bg-slate-800/95 backdrop-blur-xl rounded-3xl p-6 sm:p-8 border border-sky-500/30 shadow-2xl space-y-6 animate-in fade-in zoom-in-95 text-center sm:text-left relative overflow-hidden">
                  {/* Top #1 Career Card: तुमचं ध्येय */}
                  <div className="bg-gradient-to-br from-indigo-900/40 via-sky-950/60 to-slate-900 border-2 border-sky-400/50 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
                    <div className="absolute -right-8 -bottom-8 w-44 h-44 bg-sky-500/20 rounded-full blur-2xl pointer-events-none" />
                    <div className="absolute -left-8 -top-8 w-44 h-44 bg-indigo-500/20 rounded-full blur-2xl pointer-events-none" />

                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/25 border border-sky-400/50 text-sky-300 text-xs font-black tracking-wide mb-3">
                      <Sparkles size={13} className="text-amber-300" />
                      <span>तुमचं ध्येय (AI Recommended Goal)</span>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
                      {/* Large Animated Circular Match % */}
                      <div className="relative w-28 h-28 shrink-0 flex items-center justify-center">
                        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                          <circle
                            cx="50"
                            cy="50"
                            r="42"
                            className="stroke-slate-700/60"
                            strokeWidth="9"
                            fill="transparent"
                          />
                          <circle
                            cx="50"
                            cy="50"
                            r="42"
                            className="stroke-sky-400 transition-all duration-1000 ease-out"
                            strokeWidth="9"
                            strokeDasharray={264}
                            strokeDashoffset={264 - (264 * (topCareerMatch?.matchPercent || 96)) / 100}
                            strokeLinecap="round"
                            fill="transparent"
                          />
                        </svg>
                        <div className="absolute flex flex-col items-center justify-center">
                          <span className="text-2xl font-black text-white tabular-nums tracking-tighter">
                            {topCareerMatch?.matchPercent || 96}%
                          </span>
                          <span className="text-[10px] font-bold text-sky-300 uppercase">Match</span>
                        </div>
                      </div>

                      {/* Career Details */}
                      <div className="flex-1 space-y-2 text-left">
                        <h3 className="text-lg sm:text-xl font-black text-white leading-tight">
                          {topCareerMatch?.career.title}
                        </h3>
                        {topCareerMatch?.career.description && (
                          <p className="text-xs text-slate-300 leading-relaxed">
                            {topCareerMatch.career.description}
                          </p>
                        )}

                        {/* Marathi Template "Why" Text built from top contributing tags */}
                        <div className="p-3 rounded-2xl bg-slate-900/80 border border-sky-500/30 text-left space-y-1 mt-2">
                          <div className="flex items-center gap-1.5 text-sky-300 font-bold text-[11px]">
                            <Compass size={13} />
                            <span>AI विश्लेषण (हे करिअर का?):</span>
                          </div>
                          <p className="text-xs text-slate-200 leading-relaxed">
                            {topCareerMatch?.whyText}
                          </p>
                        </div>

                        {/* Key Skills */}
                        {topCareerMatch?.career.keySkills && (
                          <div className="flex flex-wrap gap-1.5 pt-1">
                            {topCareerMatch.career.keySkills.map((sk, sIdx) => (
                              <span
                                key={sIdx}
                                className="px-2.5 py-0.5 rounded-lg bg-sky-950/70 border border-sky-700/60 text-sky-200 text-[10px] font-semibold"
                              >
                                {sk}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Primary Action Button: "हे करिअर निवडा" */}
                    <div className="mt-5 pt-3 border-t border-slate-700/60 flex flex-col sm:flex-row items-center justify-between gap-3">
                      <div className="text-[11px] text-slate-400">
                        {aiQuizState.metaValues.weeklyHours && (
                          <span>वेळ: {aiQuizState.metaValues.weeklyHours} तास/आठवडा • </span>
                        )}
                        {aiQuizState.metaValues.learningLanguage && (
                          <span>भाषा: {aiQuizState.metaValues.learningLanguage}</span>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          if (topCareerMatch) {
                            setSelectedGoalId(topCareerMatch.career.id);
                            setCustomGoalName(topCareerMatch.career.title);
                            setStep(8);
                          }
                        }}
                        className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-sky-600 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-white font-black text-sm shadow-xl shadow-sky-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                      >
                        <CheckCircle2 size={18} />
                        <span>हे करिअर निवडा (Choose This Goal)</span>
                      </button>
                    </div>
                  </div>

                  {/* Next 2-4 Career Matches */}
                  {otherMatches.length > 0 && (
                    <div className="space-y-3 text-left">
                      <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5 px-1">
                        <Tag size={13} className="text-sky-400" />
                        <span>इतर सर्वोत्तम करिअर पर्याय (Alternative Matches):</span>
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        {otherMatches.map((m, idx) => (
                          <div
                            key={m.career.id}
                            className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700/80 space-y-2 flex flex-col justify-between"
                          >
                            <div className="space-y-1.5">
                              <div className="flex items-center justify-between gap-2">
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                                  #{idx + 2}
                                </span>
                                <span className="text-xs font-black text-sky-400">
                                  {m.matchPercent}% Match
                                </span>
                              </div>
                              <h5 className="text-xs font-bold text-white leading-snug">
                                {m.career.title}
                              </h5>
                              <p className="text-[11px] text-slate-400 line-clamp-2">
                                {m.whyText}
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedGoalId(m.career.id);
                                setCustomGoalName(m.career.title);
                                setStep(8);
                              }}
                              className="w-full py-1.5 rounded-xl bg-slate-800 hover:bg-sky-500 hover:text-white text-slate-300 text-[11px] font-bold transition cursor-pointer"
                            >
                              हे करिअर निवडा
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Footer Back & Restart */}
                  <div className="flex items-center justify-between pt-2 px-1 text-xs text-slate-400 border-t border-slate-700/60">
                    <button
                      type="button"
                      onClick={() => {
                        setAiQuizState(createInitialQuizState());
                        setAiQuizSelectedOption(null);
                        setAiQuizBuddyNotice(null);
                        setStep(5);
                      }}
                      className="hover:text-white flex items-center gap-1 font-semibold cursor-pointer"
                    >
                      <RotateCcw size={13} />
                      <span>प्रश्नावली पुन्हा सुरू करा</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setStep(4)}
                      className="hover:text-white cursor-pointer"
                    >
                      मागे जा
                    </button>
                  </div>
                </div>
              );
            })()
          ) : (
            /* Self-Chosen Goal Result Screen */
            <div className="bg-slate-800/90 backdrop-blur-xl rounded-3xl p-6 sm:p-8 border border-sky-500/30 shadow-2xl space-y-6 animate-in fade-in zoom-in-95 text-center relative overflow-hidden">
              <div className="flex flex-col items-center justify-center pt-1 space-y-3">
                <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-emerald-400 via-sky-500 to-indigo-500 p-1 shadow-xl shadow-sky-500/20 animate-in zoom-in-75">
                  <div className="w-full h-full bg-slate-950 rounded-[22px] flex flex-col items-center justify-center">
                    <Award size={38} className="text-emerald-400" />
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-xs font-bold tracking-wider uppercase text-sky-400">Assessment Result</span>
                  <h2 className="text-2xl font-black text-white">Your Performance Breakdown</h2>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-700 flex items-center justify-between text-left">
                <div>
                  <span className="text-[10px] text-slate-400 font-semibold uppercase block">
                    Chosen Goal Track
                  </span>
                  <span className="text-sm font-extrabold text-white flex items-center gap-1.5">
                    <Target size={15} className="text-indigo-400 shrink-0" />
                    <span>{displayedGoalTitle}</span>
                  </span>
                </div>
                <span className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-400/30">
                  Self Chosen
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-left space-y-1.5 shadow-md shadow-emerald-500/10">
                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-xs">
                    <CheckCircle2 size={16} />
                    <span>Perfect Answers</span>
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-white tabular-nums">
                    {calculationResult.perfectCount}
                    <span className="text-xs text-slate-400 font-normal ml-1">/ {calculationResult.totalQ}</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-medium block">
                    {calculationResult.percent}% accuracy
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-rose-950/30 border border-rose-500/30 text-left space-y-1.5">
                  <div className="flex items-center gap-1.5 text-rose-400 font-bold text-xs">
                    <Activity size={16} />
                    <span>Growth Areas</span>
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-white tabular-nums">
                    {calculationResult.incorrectCount}
                    <span className="text-xs text-slate-400 font-normal ml-1">/ {calculationResult.totalQ}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-medium block">
                    Identified focus areas
                  </span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleProceedFromResults}
                  className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-sky-500 via-indigo-600 to-cyan-500 hover:from-sky-400 hover:to-indigo-500 text-white font-black text-sm sm:text-base shadow-xl shadow-sky-600/30 transition-all flex items-center justify-center gap-2.5 active:scale-[0.99] cursor-pointer"
                >
                  <span>{`View Skills for "${customGoalName.trim() || 'Your Goal'}"`}</span>
                  <ArrowRight size={20} className="stroke-[2.5]" />
                </button>
              </div>
            </div>
          )
        )}

        {/* STEP 7: AI 10 Goals Recommendation Screen (ONLY for AI mode, NEVER for self-selected goal) */}
        {step === 7 && goalMode === 'ai' && !customGoalName.trim() && (
          <div className="bg-slate-800/90 backdrop-blur-xl rounded-3xl p-6 sm:p-8 border border-sky-500/30 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 text-left relative overflow-hidden">
            {/* Active AI Chat Bot with continuous eye movements and reactions */}
            <div className="flex flex-col items-center justify-center pt-1 space-y-2">
              <div className="relative animate-bot-float">
                {/* Active Outer Aura */}
                <div className="absolute -inset-2 rounded-3xl bg-gradient-to-r from-sky-500/30 via-cyan-400/30 to-indigo-500/30 blur-md pointer-events-none" />

                {/* AI Chat Bot Pod */}
                <div className="relative w-20 h-20 rounded-3xl p-1 bg-gradient-to-tr from-cyan-400 via-sky-500 to-indigo-500 shadow-[0_0_25px_rgba(56,189,248,0.45)]">
                  <div className="w-full h-full bg-slate-950 rounded-[20px] flex flex-col items-center justify-center relative overflow-hidden p-2">
                    {/* Bot Head Antenna / Status Light */}
                    <div className="absolute top-1.5 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      <span className="text-[8px] font-black tracking-wider text-emerald-400 uppercase">ONLINE</span>
                    </div>

                    {/* Cute Futuristic Face Screen with Active Moving Eyes */}
                    <div className="w-14 h-9 bg-slate-900/90 rounded-2xl border border-cyan-400/40 flex items-center justify-center gap-2 px-1.5 shadow-inner relative mt-2">
                      {/* Left Eye with Blink and Pupil Motion */}
                      <div className="relative w-3 h-3.5 bg-cyan-400 rounded-full flex items-center justify-center animate-bot-eye shadow-[0_0_8px_#22d3ee]">
                        <div className="w-1.5 h-1.5 bg-white rounded-full animate-bot-pupil" />
                      </div>

                      {/* Right Eye with Blink and Pupil Motion */}
                      <div className="relative w-3 h-3.5 bg-cyan-400 rounded-full flex items-center justify-center animate-bot-eye shadow-[0_0_8px_#22d3ee]">
                        <div className="w-1.5 h-1.5 bg-white rounded-full animate-bot-pupil" />
                      </div>

                      {/* Happy curved mouth line */}
                      <div className="absolute bottom-0.5 w-3 h-1 border-b-2 border-cyan-300 rounded-full" />
                    </div>

                    {/* Subtle micro wave pulses */}
                    <div className="absolute bottom-1 flex items-center gap-1">
                      <span className="w-1 h-1 rounded-full bg-sky-400 animate-pulse" />
                      <span className="w-1 h-1 rounded-full bg-indigo-400 animate-pulse delay-75" />
                      <span className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse delay-150" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Header: Title */}
            <div className="space-y-1 text-center">
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Recommended Goals
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'mr' 
                  ? 'तुमच्या १५ प्रश्नांच्या उत्तरांवरून AI ने ठरवलेले सर्वोत्तम करिअर पर्याय' 
                  : 'Ranked according to your performance & affinity across the 15 questions'}
              </p>
            </div>

            {/* Goals Grid - Clean and Spacious */}
            <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
              {aiRecommendedGoals.map((goal, gIdx) => {
                const isSelected = selectedGoalId === goal.id;
                const isTopMatch = gIdx === 0;
                return (
                  <div
                    key={goal.id}
                    onClick={() => handleSelectGoal(goal.id)}
                    className={`p-3.5 sm:p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-sky-500/20 border-sky-400 shadow-md shadow-sky-500/20'
                        : isTopMatch
                          ? 'bg-emerald-950/20 border-emerald-500/50 hover:border-emerald-400'
                          : 'bg-slate-900/70 border-slate-700/80 hover:border-slate-600'
                    }`}
                  >
                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm sm:text-base font-bold text-white truncate">{goal.title}</h4>
                        {isTopMatch && (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-400/40 shrink-0">
                            🌟 Top Match
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400">
                        <span className="text-sky-300 font-bold">{goal.match}% Match</span>
                        <span>•</span>
                        <span className="truncate">{goal.category}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 shrink-0">
                      {/* Tap to open goal information button */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setViewingGoalModal(goal);
                        }}
                        title="View Goal Details & Required Skills"
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-300 hover:text-white text-xs font-bold flex items-center gap-1.5 border border-slate-700 transition-colors cursor-pointer"
                      >
                        <Info size={13} />
                        <span>Details</span>
                      </button>

                      {/* Single Goal Radio / Check Selection */}
                      <div className={`w-6 h-6 rounded-full border flex items-center justify-center shrink-0 transition-all ${
                        isSelected ? 'border-sky-400 bg-sky-500 text-white shadow-sm' : 'border-slate-600 bg-slate-950/60'
                      }`}>
                        {isSelected && <Check size={14} className="stroke-[3]" />}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Action Buttons */}
            <div className="pt-2 space-y-2">
              <button
                type="button"
                onClick={handlePromptConfirmGoal}
                disabled={!selectedGoalId}
                className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-sky-500 via-indigo-600 to-cyan-500 hover:from-sky-400 hover:to-indigo-500 disabled:opacity-40 text-white font-black text-sm sm:text-base shadow-xl shadow-sky-600/30 transition-all flex items-center justify-center gap-2.5 active:scale-[0.99] cursor-pointer disabled:cursor-not-allowed"
              >
                <span>Continue</span>
                <ArrowRight size={20} className="stroke-[2.5]" />
              </button>

              <button
                type="button"
                onClick={() => setStep(6)}
                className="text-xs font-semibold text-slate-400 hover:text-white flex items-center justify-center gap-1 transition-colors cursor-pointer mx-auto pt-1"
              >
                <ArrowLeft size={13} /> Back to Results
              </button>
            </div>

            {/* Goal Information Modal (Opens when user taps on any goal) */}
            {viewingGoalModal && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
                <div className="bg-slate-900 border border-sky-500/40 rounded-3xl max-w-lg w-full p-6 text-left space-y-4 shadow-2xl relative animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
                  {/* Close button */}
                  <button
                    type="button"
                    onClick={() => setViewingGoalModal(null)}
                    className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white bg-slate-800 rounded-full cursor-pointer transition-colors"
                  >
                    <X size={18} />
                  </button>

                  {/* Goal Header */}
                  <div className="space-y-1.5 pr-8">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                        {viewingGoalModal.category}
                      </span>
                      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                        {viewingGoalModal.match}% Match
                      </span>
                      {viewingGoalModal.demand && (
                        <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-400/30">
                          {viewingGoalModal.demand}
                        </span>
                      )}
                    </div>
                    <h3 className="text-xl font-black text-white">{viewingGoalModal.title}</h3>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {viewingGoalModal.description}
                    </p>
                  </div>

                  {/* Why AI Recommended This Goal Card */}
                  {viewingGoalModal.matchReason && (
                    <div className="p-3.5 rounded-2xl bg-sky-950/40 border border-sky-500/30 space-y-1">
                      <span className="text-[10px] font-bold text-sky-400 uppercase tracking-wider block">
                        Why AI Recommends This:
                      </span>
                      <p className="text-xs text-slate-200">
                        {viewingGoalModal.matchReason}
                      </p>
                    </div>
                  )}

                  {/* Salary and Market Outlook */}
                  {viewingGoalModal.salaryRange && (
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs">
                      <span className="text-slate-400">Industry Compensation:</span>
                      <span className="font-bold text-emerald-400">{viewingGoalModal.salaryRange}</span>
                    </div>
                  )}

                  {/* Skills Needed to Achieve This Goal Section */}
                  <div className="space-y-2.5 p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
                    <div className="flex items-center gap-2 text-sky-400 font-extrabold text-xs uppercase tracking-wide">
                      <Target size={15} />
                      <span>Skills Needed to Achieve This Goal</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      To master and succeed as a {viewingGoalModal.title}, you will need to achieve the following competencies:
                    </p>
                    <div className="flex flex-wrap gap-2 pt-1">
                      {viewingGoalModal.skills.map((sk: string) => (
                        <div
                          key={sk}
                          className="px-3 py-1.5 rounded-xl bg-slate-850 border border-sky-500/30 text-xs font-semibold text-slate-200 flex items-center gap-1.5 shadow-sm"
                        >
                          <span className="text-amber-400">⚡</span>
                          <span>{sk}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons in Modal */}
                  <div className="pt-2 flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        handleSelectGoal(viewingGoalModal.id);
                        setViewingGoalModal(null);
                      }}
                      className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-sky-600/30 cursor-pointer"
                    >
                      <Check size={16} />
                      <span>Select this Goal</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setViewingGoalModal(null)}
                      className="py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer"
                    >
                      Close
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 'Are you sure?' Confirmation Dialog */}
            {showConfirmGoalModal && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
                <div className="bg-slate-900 border-2 border-sky-500/50 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl relative animate-in zoom-in-95">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-sky-500 to-indigo-600 mx-auto flex items-center justify-center text-white shadow-xl shadow-sky-500/30">
                    <HelpCircle size={36} />
                  </div>

                  <div className="space-y-1.5">
                    <h3 className="text-xl font-black text-white">Are you sure?</h3>
                    <p className="text-xs text-slate-300">
                      You have selected <strong className="text-sky-300">{AI_RECOMMENDED_10_GOALS.find(g => g.id === selectedGoalId)?.title}</strong> as your primary career goal.
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Would you like to lock this goal and view your achieved & missing skills roadmap?
                    </p>
                  </div>

                  <div className="pt-2 space-y-2">
                    <button
                      type="button"
                      onClick={handleConfirmAndProceedToSkills}
                      className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-sky-600 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-white font-black text-xs shadow-lg shadow-emerald-500/20 cursor-pointer flex items-center justify-center gap-2"
                    >
                      <Check size={16} />
                      <span>Yes, Confirm & Continue</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setShowConfirmGoalModal(false)}
                      className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white font-semibold text-xs cursor-pointer transition-colors"
                    >
                      Cancel / Change Goal
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STEP 8: Achieved Skills and Missing Skills Screen */}
        {step === 8 && (
          <div className="bg-slate-800/90 backdrop-blur-xl rounded-3xl p-6 sm:p-8 border border-sky-500/30 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 text-left relative overflow-hidden">
            {/* Header */}
            <div className="space-y-1 text-center">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 text-xs font-bold border border-sky-400/30 mx-auto">
                <Target size={13} />
                <span>Goal: {activeGoal.title}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Achieved & Missing Skills
              </h2>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Here is your skill evaluation based on challenge answers for <strong>{activeGoal.title}</strong>:
              </p>
            </div>

            {/* Scrollable container for Achieved & Missing skills */}
            <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
              {/* Section 1: Achieved Skills (Verified Masteries) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                    <CheckCircle2 size={16} />
                    <span>Achieved Skills ({skillsEvaluation.achieved.length})</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
                    Verified Capabilities
                  </span>
                </div>

                <div className="space-y-2">
                  {skillsEvaluation.achieved.map((skill, sIdx) => (
                    <div
                      key={sIdx}
                      className="p-3.5 rounded-2xl bg-emerald-950/30 border border-emerald-500/40 flex items-center justify-between gap-3 shadow-sm"
                    >
                      <div className="space-y-0.5 min-w-0">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 size={15} className="text-emerald-400 shrink-0" />
                          <h4 className="text-xs sm:text-sm font-bold text-white truncate">{skill.name}</h4>
                        </div>
                        <p className="text-[11px] text-slate-400">{skill.reason}</p>
                      </div>
                      <span className="px-2.5 py-1 rounded-xl bg-emerald-900/60 border border-emerald-500/40 text-[10px] font-bold text-emerald-300 shrink-0">
                        {skill.level}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Section 2: Missing Skills (Roadmap Growth Targets) */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between px-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
                    <AlertCircle size={16} />
                    <span>Missing Skills to Master ({skillsEvaluation.missing.length})</span>
                  </div>
                  <span className="text-[10px] text-amber-400 font-semibold bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-500/30">
                    Growth Targets
                  </span>
                </div>

                <div className="space-y-2">
                  {skillsEvaluation.missing.map((skill, sIdx) => (
                    <div
                      key={sIdx}
                      className="p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/40 flex items-center justify-between gap-3 shadow-sm"
                    >
                      <div className="space-y-0.5 min-w-0">
                        <div className="flex items-center gap-2">
                          <AlertCircle size={15} className="text-amber-400 shrink-0" />
                          <h4 className="text-xs sm:text-sm font-bold text-white truncate">{skill.name}</h4>
                        </div>
                        <p className="text-[11px] text-slate-400">{skill.reason}</p>
                      </div>
                      <span className="px-2.5 py-1 rounded-xl bg-amber-900/50 border border-amber-500/40 text-[10px] font-bold text-amber-300 shrink-0">
                        {skill.level}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Buttons: Continue to Generate Student ID */}
            <div className="pt-2 space-y-2">
              <button
                type="button"
                onClick={handleProceedToStudentId}
                className="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 via-sky-600 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-white font-black text-sm sm:text-base shadow-xl shadow-sky-600/30 transition-all flex items-center justify-center gap-2.5 active:scale-[0.99] cursor-pointer"
              >
                <span>Continue to Generate Student ID</span>
                <ArrowRight size={20} className="stroke-[2.5]" />
              </button>

              <button
                type="button"
                onClick={() => setStep(goalMode === 'self' || !!customGoalName.trim() ? 6 : 7)}
                className="text-xs font-semibold text-slate-400 hover:text-white flex items-center justify-center gap-1 transition-colors cursor-pointer mx-auto pt-1"
              >
                <ArrowLeft size={13} /> {goalMode === 'self' || !!customGoalName.trim() ? 'Back to Results' : 'Back to Goals'}
              </button>
            </div>
          </div>
        )}

        {/* STEP 9: Student ID Generation Card & App Entry */}
        {step === 9 && (
          <div className="bg-slate-800/90 backdrop-blur-xl rounded-3xl p-6 sm:p-8 border border-sky-500/30 shadow-2xl space-y-6 animate-in fade-in zoom-in-95 text-center relative overflow-hidden">
            {/* Active AI Chat Bot */}
            <div className="flex flex-col items-center justify-center pt-1 space-y-2">
              <div className="relative animate-bot-float">
                {/* Active Outer Aura */}
                <div className="absolute -inset-2 rounded-3xl bg-gradient-to-r from-sky-500/30 via-cyan-400/30 to-indigo-500/30 blur-md pointer-events-none" />

                {/* AI Chat Bot Pod */}
                <div className="relative w-20 h-20 rounded-3xl p-1 bg-gradient-to-tr from-cyan-400 via-sky-500 to-indigo-500 shadow-[0_0_25px_rgba(56,189,248,0.45)]">
                  <div className="w-full h-full bg-slate-950 rounded-[20px] flex flex-col items-center justify-center relative overflow-hidden p-2">
                    {/* Bot Head Antenna / Status Light */}
                    <div className="absolute top-1.5 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      <span className="text-[8px] font-black tracking-wider text-emerald-400 uppercase">ONLINE</span>
                    </div>

                    {/* Cute Futuristic Face Screen with Active Moving Eyes */}
                    <div className="w-14 h-9 bg-slate-900/90 rounded-2xl border border-cyan-400/40 flex items-center justify-center gap-2 px-1.5 shadow-inner relative mt-2">
                      {/* Left Eye with Blink and Pupil Motion */}
                      <div className="relative w-3 h-3.5 bg-cyan-400 rounded-full flex items-center justify-center animate-bot-eye shadow-[0_0_8px_#22d3ee]">
                        <div className="w-1.5 h-1.5 bg-white rounded-full animate-bot-pupil" />
                      </div>

                      {/* Right Eye with Blink and Pupil Motion */}
                      <div className="relative w-3 h-3.5 bg-cyan-400 rounded-full flex items-center justify-center animate-bot-eye shadow-[0_0_8px_#22d3ee]">
                        <div className="w-1.5 h-1.5 bg-white rounded-full animate-bot-pupil" />
                      </div>

                      {/* Happy curved mouth line */}
                      <div className="absolute bottom-0.5 w-3 h-1 border-b-2 border-cyan-300 rounded-full" />
                    </div>

                    {/* Subtle micro wave pulses */}
                    <div className="absolute bottom-1 flex items-center gap-1">
                      <span className="w-1 h-1 rounded-full bg-sky-400 animate-pulse" />
                      <span className="w-1 h-1 rounded-full bg-indigo-400 animate-pulse delay-75" />
                      <span className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse delay-150" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-1 pt-1">
                <h2 className="text-2xl font-black text-white">Your Student ID is Generated!</h2>
              </div>
            </div>

            {/* Futuristic Student Identity Card */}
            <div className="p-5 rounded-3xl bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-sky-500/40 text-left space-y-3.5 shadow-2xl relative overflow-hidden">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-sky-500 text-white font-black text-xs flex items-center justify-center">
                    SPA
                  </div>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[10px] border border-emerald-500/40">
                  ACTIVE
                </span>
              </div>

              {/* Big Student ID Badge */}
              <div className="p-3 bg-slate-900/90 rounded-2xl border border-sky-400/50 text-center space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Official Student ID</span>
                <div className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-cyan-300 to-indigo-300 tracking-widest font-mono">
                  {generatedStudentId || generateStudentId(userName, birthDate)}
                </div>
              </div>

              {/* Student Details Summary */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 block">Name:</span>
                  <span className="font-bold text-white truncate block">{userName || 'Student'}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Age:</span>
                  <span className="font-bold text-white">{calculatedAge} Years</span>
                </div>
              </div>
            </div>

            {/* DAILY TASK INCOMPLETE EVENING REMINDER SELECTION */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border-2 border-amber-500/40 text-left space-y-3.5 shadow-xl relative overflow-hidden">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-400 flex items-center justify-center">
                    <Bell size={16} />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <span>{language === 'mr' ? 'दैनिक टास्क अपूर्ण रिमाइंडर' : 'Daily Task Incomplete Reminder'}</span>
                    </h3>
                    <span className="text-[10px] text-slate-400">
                      {language === 'mr' ? 'टास्क बाकी राहिल्यास संध्याकाळी सूचना' : "Evening alert if today's task is incomplete"}
                    </span>
                  </div>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-black text-xs border border-amber-500/40">
                  {selectedReminderTime}
                </span>
              </div>

              {/* Explanatory Prompt */}
              <div className="space-y-1">
                <p className="text-xs text-slate-200 font-semibold leading-relaxed">
                  {language === 'mr'
                    ? 'जर तुमचे आजचे कार्य पूर्ण झाले नाही, तर संध्याकाळी किती वाजता आठवण (Reminder) करून देऊ?'
                    : "If today's daily task is not completed, what time should we remind you in the evening?"}
                </p>
                <p className="text-[11px] text-slate-400">
                  {language === 'mr'
                    ? 'खालीलपैकी तुमची सोयीची वेळ निवडा:'
                    : 'Select your preferred evening alert time:'}
                </p>
              </div>

              {/* Time Selection Chips: 5 PM, 6 PM, 7 PM, 8 PM, 9 PM, 10 PM */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {['5:00 PM', '6:00 PM', '7:00 PM', '8:00 PM', '9:00 PM', '10:00 PM'].map(time => {
                  const isSelected = selectedReminderTime === time;
                  return (
                    <button
                      key={time}
                      type="button"
                      onClick={() => setSelectedReminderTime(time)}
                      className={`py-2 px-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                        isSelected
                          ? 'bg-gradient-to-b from-amber-500 to-orange-500 text-slate-950 border-amber-300 shadow-md shadow-amber-500/30 scale-105'
                          : 'bg-slate-950/80 hover:bg-slate-800 text-slate-300 border-slate-800'
                      }`}
                    >
                      <Clock size={12} className={isSelected ? 'text-slate-950' : 'text-slate-500'} />
                      <span>{time}</span>
                      <span className="text-[9px] opacity-75">
                        {time.split(':')[0]} {language === 'mr' ? 'वाजता' : 'PM'}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Notification Permission & Test Trigger Controls */}
              <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-2.5">
                {/* Permission Button / Status */}
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={handleRequestNotifPermission}
                    className={`w-full sm:w-auto px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                      notifPermission === 'granted'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : notifPermission === 'denied'
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                        : 'bg-sky-500/20 text-sky-300 border-sky-400/40 hover:bg-sky-500/30'
                    }`}
                  >
                    <Smartphone size={13} />
                    <span>
                      {notifPermission === 'granted'
                        ? (language === 'mr' ? 'फोनवर नोटिफिकेशन्स सुरू ✅' : 'Device Notifications Allowed ✅')
                        : notifPermission === 'denied'
                        ? (language === 'mr' ? 'नोटिफिकेशन्स ब्लॉक आहेत ⚠️' : 'Notifications Blocked ⚠️')
                        : (language === 'mr' ? 'फोन नोटिफिकेशन परवानगी द्या 🔔' : 'Allow Device Notifications 🔔')}
                    </span>
                  </button>
                </div>

                {/* Test Reminder Notification Button */}
                <button
                  type="button"
                  onClick={handleTestReminderNotification}
                  className="w-full sm:w-auto px-3.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-300 font-extrabold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95"
                >
                  <Bell size={13} />
                  <span>{language === 'mr' ? 'टेस्ट नोटिफिकेशन पाठवा' : 'Test Reminder Notification'}</span>
                </button>
              </div>

              {/* Toast Feedback */}
              {testNotifToast && (
                <div className="p-2 rounded-xl bg-amber-400/20 border border-amber-400/40 text-amber-200 text-xs text-center font-bold animate-in fade-in">
                  {testNotifToast}
                </div>
              )}
            </div>

            {/* Launch App Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={handleFinalAppEntry}
                className="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 via-sky-600 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-white font-black text-sm sm:text-base shadow-xl shadow-sky-600/30 transition-all flex items-center justify-center gap-2.5 active:scale-[0.99] cursor-pointer"
              >
                <span>Enter SPA & Start Journey</span>
                <ArrowRight size={20} className="stroke-[2.5]" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
