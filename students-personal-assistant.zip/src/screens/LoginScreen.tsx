import React, { useState, useEffect } from 'react';
import { Mail, Lock, Eye, EyeOff, User, ArrowRight, Sparkles, Settings, X, Globe, Sun, Moon, Type, Sliders } from 'lucide-react';
import { UserProfile } from '../types';
import { translations } from '../translations';

interface Props {
  onLogin: (profile: Partial<UserProfile>, isNewAccount?: boolean) => void;
  initialEmail?: string;
  initialName?: string;
  language?: 'en' | 'mr' | 'hi';
  setLanguage?: (lang: 'en' | 'mr' | 'hi') => void;
  darkMode?: boolean;
  setDarkMode?: (val: boolean) => void;
  fontSize?: 'small' | 'medium' | 'large';
  setFontSize?: (size: 'small' | 'medium' | 'large') => void;
  demoWindowEnabled?: boolean;
  setDemoWindowEnabled?: (val: boolean) => void;
  forceSignUp?: boolean;
}

export const LoginScreen: React.FC<Props> = ({
  onLogin,
  initialEmail = 'ridergeming170@gmail.com',
  initialName = 'RIDER',
  language = 'en',
  setLanguage,
  darkMode = false,
  setDarkMode,
  fontSize = 'medium',
  setFontSize,
  demoWindowEnabled = false,
  setDemoWindowEnabled,
  forceSignUp,
}) => {
  const t = translations[language];

  const [isSignUp, setIsSignUp] = useState(false);

  useEffect(() => {
    if (forceSignUp !== undefined) {
      setIsSignUp(forceSignUp);
    }
  }, [forceSignUp]);
  const [email, setEmail] = useState(initialEmail);
  const [password, setPassword] = useState('password123');
  const [name, setName] = useState(initialName);
  const [gender, setGender] = useState<'male' | 'female' | 'other'>('male');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState('');
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError(language === 'mr' ? 'कृपया ईमेल/विद्यार्थी आयडी आणि पासवर्ड दोन्ही प्रविष्ट करा.' : 'Please enter Email / Student ID and password.');
      return;
    }
    if (isSignUp && !name.trim()) {
      setError(language === 'mr' ? 'कृपया तुमचे पूर्ण नाव प्रविष्ट करा.' : 'Please enter your full name.');
      return;
    }

    const inputVal = email.trim();
    let loginEmail = inputVal;
    let loginStudentId: string | undefined = undefined;

    // Check if user entered a student ID (e.g. starts with SPA or doesn't have @)
    if (!inputVal.includes('@')) {
      loginStudentId = inputVal.toUpperCase();
      // Search localStorage for existing student with this ID
      const savedEmail = localStorage.getItem(`spa_student_id_map_${inputVal.toUpperCase()}`);
      if (savedEmail) {
        loginEmail = savedEmail;
      } else {
        loginEmail = `${inputVal.toLowerCase()}@spa.edu`;
      }
    }

    onLogin(
      {
        email: loginEmail,
        studentId: loginStudentId,
        name: isSignUp ? name.trim() : (name.trim() || 'RIDER'),
        gender,
      },
      isSignUp
    );
  };

  const handleQuickLogin = () => {
    onLogin(
      {
        email: initialEmail || 'ridergeming170@gmail.com',
        name: initialName || 'RIDER',
        gender,
      },
      false
    );
  };

  return (
    <div className="min-h-screen w-full bg-slate-900 flex flex-col justify-center px-6 py-10 relative overflow-hidden text-slate-100">
      {/* Background Glowing Ambient Orbs */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-sky-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

      {/* Settings Icon on Login Screen (Top Right) */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
        {setLanguage && (
          <button
            onClick={() => setShowSettingsModal(true)}
            aria-label="Settings"
            className="p-2.5 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white border border-slate-700/60 shadow-lg backdrop-blur-md transition-all active:scale-95 flex items-center gap-1.5 text-xs font-semibold"
          >
            <Settings size={18} />
            <span className="uppercase text-[11px] font-bold tracking-wider">{language}</span>
          </button>
        )}
      </div>

      <div className="w-full max-w-md mx-auto relative z-10 space-y-6">
        {/* App Logo & Branding */}
        <div className="text-center space-y-3">
          <div className="w-24 h-24 mx-auto rounded-3xl overflow-hidden shadow-2xl border-2 border-sky-500/30 bg-slate-950 p-1">
            <img src="/pwa-192x192.png" alt="SPA Logo" className="w-full h-full object-cover rounded-2xl" />
          </div>

          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-950/70 text-sky-400 border border-sky-800/60 text-[11px] font-bold uppercase tracking-wider mb-2">
              <Sparkles size={12} />
              <span>Student Personal Assistant</span>
            </div>
            <h1 className="text-2xl font-black text-white tracking-tight">
              {isSignUp ? t.createYourAccount : t.welcomeToSpa}
            </h1>
          </div>
        </div>

        {error && (
          <div className="p-3 rounded-2xl bg-rose-950/60 border border-rose-800 text-rose-300 text-xs text-center font-medium">
            {error}
          </div>
        )}

        {/* Login / Sign Up Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
            <>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">{t.fullName}</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none">
                    <User size={16} />
                  </span>
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder={language === 'mr' ? 'तुमचे नाव प्रविष्ट करा' : 'Enter your name'}
                    className="w-full pl-10 pr-3.5 py-3 rounded-2xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all"
                    required
                  />
                </div>
              </div>

              {/* Gender Selection: directly below Name input, ONLY in Create Account, NO emojis */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>{t.gender}</span>
                  <span className="text-[11px] text-sky-400 font-bold capitalize">
                    {gender === 'male' ? t.male : gender === 'female' ? t.female : t.other}
                  </span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setGender('male')}
                    className={`py-2 px-2 rounded-xl border text-xs font-bold transition-all text-center cursor-pointer ${
                      gender === 'male'
                        ? 'bg-sky-500/25 border-sky-400 text-sky-300 shadow-md shadow-sky-500/20'
                        : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white hover:border-slate-600'
                    }`}
                  >
                    {t.male}
                  </button>
                  <button
                    type="button"
                    onClick={() => setGender('female')}
                    className={`py-2 px-2 rounded-xl border text-xs font-bold transition-all text-center cursor-pointer ${
                      gender === 'female'
                        ? 'bg-pink-500/25 border-pink-400 text-pink-300 shadow-md shadow-pink-500/20'
                        : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white hover:border-slate-600'
                    }`}
                  >
                    {t.female}
                  </button>
                  <button
                    type="button"
                    onClick={() => setGender('other')}
                    className={`py-2 px-2 rounded-xl border text-xs font-bold transition-all text-center cursor-pointer ${
                      gender === 'other'
                        ? 'bg-indigo-500/25 border-indigo-400 text-indigo-300 shadow-md shadow-indigo-500/20'
                        : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white hover:border-slate-600'
                    }`}
                  >
                    {t.other}
                  </button>
                </div>
              </div>
            </>
          )}

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">
              {isSignUp ? t.emailAddress : (language === 'mr' ? 'ईमेल पत्ता / विद्यार्थी आयडी (Student ID)' : 'Email Address / Student ID')}
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none">
                <Mail size={16} />
              </span>
              <input
                type={isSignUp ? "email" : "text"}
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder={isSignUp ? "ridergeming170@gmail.com" : (language === 'mr' ? "उदा. rider@gmail.com किंवा SPA-RID-2004" : "e.g. rider@gmail.com or SPA-RID-2004")}
                className="w-full pl-10 pr-3.5 py-3 rounded-2xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all"
                required
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">{t.password}</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none">
                <Lock size={16} />
              </span>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-10 py-3 rounded-2xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-white transition-colors"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={e => setRememberMe(e.target.checked)}
                className="rounded border-slate-700 bg-slate-800 text-sky-600 focus:ring-sky-500"
              />
              <span>{t.rememberMe}</span>
            </label>
            <button
              type="button"
              onClick={handleQuickLogin}
              className="text-sky-400 hover:text-sky-300 font-semibold"
            >
              {t.quickDemoLogin}
            </button>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-extrabold text-sm shadow-xl shadow-sky-600/30 transition-all flex items-center justify-center gap-2 active:scale-98 cursor-pointer"
          >
            <span>{isSignUp ? `${t.signUp} & Continue` : t.signIn}</span>
            <ArrowRight size={18} />
          </button>
        </form>

        {/* Toggle Sign In / Sign Up */}
        <div className="text-center pt-2 border-t border-slate-800">
          <p className="text-xs text-slate-400">
            {isSignUp ? t.alreadyHaveAccount : t.dontHaveAccount}{' '}
            <button
              type="button"
              onClick={() => {
                const nextMode = !isSignUp;
                setIsSignUp(nextMode);
                setError('');
                if (nextMode) {
                  // Switching to Sign Up (New Account) -> clear fields
                  setEmail('');
                  setName('');
                  setPassword('');
                } else {
                  // Switching back to Sign In
                  setEmail(initialEmail || 'ridergeming170@gmail.com');
                  setName(initialName || 'RIDER');
                  setPassword('password123');
                }
              }}
              className="text-sky-400 hover:text-sky-300 font-bold ml-1 transition-colors underline cursor-pointer"
            >
              {isSignUp ? t.signIn : t.signUpNewAccount}
            </button>
          </p>
        </div>
      </div>

      {/* Settings Modal on Login Screen */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-sm w-full space-y-6 shadow-2xl animate-in zoom-in-95 text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-extrabold text-base flex items-center gap-2 text-white">
                <Settings size={18} /> {t.settingsAndPreferences}
              </h3>
              <button
                onClick={() => setShowSettingsModal(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-full cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Language Selection */}
            {setLanguage && (
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Globe size={14} className="text-sky-400" />
                  <span>Language / भाषा (Default: English)</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setLanguage('en')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold transition-all ${
                      language === 'en'
                        ? 'bg-sky-600 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    English
                  </button>
                  <button
                    onClick={() => setLanguage('mr')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold transition-all ${
                      language === 'mr'
                        ? 'bg-sky-600 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    मराठी
                  </button>
                  <button
                    onClick={() => setLanguage('hi')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold transition-all ${
                      language === 'hi'
                        ? 'bg-sky-600 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    हिंदी
                  </button>
                </div>
              </div>
            )}

            {/* Theme (Day / Night) */}
            {setDarkMode && (
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Sun size={14} className="text-sky-400" />
                  <span>{t.theme}</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setDarkMode(false)}
                    className={`py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                      !darkMode
                        ? 'bg-sky-600 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Sun size={14} /> {t.dayMode}
                  </button>
                  <button
                    onClick={() => setDarkMode(true)}
                    className={`py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                      darkMode
                        ? 'bg-sky-600 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Moon size={14} /> {t.nightMode}
                  </button>
                </div>
              </div>
            )}

            {/* Font Size Selection */}
            {setFontSize && (
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Type size={14} className="text-sky-400" />
                  <span>{t.fontSize}</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setFontSize('small')}
                    className={`py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      fontSize === 'small'
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {t.small}
                  </button>
                  <button
                    onClick={() => setFontSize('medium')}
                    className={`py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      fontSize === 'medium'
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {t.medium}
                  </button>
                  <button
                    onClick={() => setFontSize('large')}
                    className={`py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      fontSize === 'large'
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {t.large}
                  </button>
                </div>
              </div>
            )}

              {/* Demo Window Switch */}
              {setDemoWindowEnabled && (
                <div className="space-y-2 pt-2 border-t border-slate-800">
                  <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 text-white flex items-center justify-center font-bold shadow-sm">
                        <Sliders size={16} />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white block">
                          {language === 'mr' ? 'डेमो विंडो (Demo Window)' : 'Demo Window'}
                        </span>
                        <span className="text-[10px] text-slate-400 block">
                          {language === 'mr' ? 'स्क्रीन नेव्हिगेटर बबल' : 'Screen navigator bubble'}
                        </span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setDemoWindowEnabled(!demoWindowEnabled)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                        demoWindowEnabled ? 'bg-sky-600' : 'bg-slate-700'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          demoWindowEnabled ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              )}

            <button
              onClick={() => setShowSettingsModal(false)}
              className="w-full py-3 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs transition-colors cursor-pointer"
            >
              Done / जतन करा
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
