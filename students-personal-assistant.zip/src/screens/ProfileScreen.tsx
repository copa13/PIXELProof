import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, SkillItem, GoalHistoryItem } from '../types';
import { 
  User, 
  Mail, 
  BookOpen, 
  Calendar, 
  Sun, 
  Moon, 
  CheckCircle, 
  Save, 
  Camera, 
  Trash2, 
  X, 
  Pencil, 
  CheckCircle2, 
  AlertCircle, 
  Award, 
  Target, 
  LogOut, 
  Globe,
  Plus,
  Sparkles,
  HelpCircle,
  ShieldCheck,
  Bot,
  Star,
  History,
  Check,
  ChevronRight,
  Flag,
  Palette
} from 'lucide-react';
import { translations } from '../translations';
import { SkillAddModal } from '../components/SkillAddModal';
import { IconColorKey, BgColorKey } from '../types';
import { ICON_COLORS, BG_COLORS, getIconColorDef, getBgColorDef } from '../utils/theme';

const POPULAR_GOALS = [
  'Software Engineering',
  'Full-Stack Web Developer',
  'AI & Machine Learning Engineer',
  'Data Scientist',
  'Cybersecurity Specialist',
  'Cloud & DevOps Engineer',
  'Mobile App Developer (Flutter/Android)',
  'UI/UX & Product Designer',
];

const GOAL_LEAVING_REASONS = [
  'नवीन आवड आणि करियरचे ध्येय सापडले (Found new passion & career interest)',
  'आधीच्या ध्येयाचे मुख्य टप्पे पूर्ण केले (Mastered current goal milestones)',
  'आधीचे ध्येय खूप कठीण वाटले (Goal was too difficult / needed a shift)',
  'कॉलेज किंवा अभ्यासक्रमाची गरज बदलली (Curriculum / College requirements changed)',
  'नवीन नोकरीच्या संधी शोधत आहे (Targeting different job market opportunities)',
  'कौशल्य अधिक व्यापक करायचे आहे (Want to broaden tech skillset)',
];

const PREDEFINED_COMPLAINTS = [
  { id: 'c1', title: 'ॲप हळू चालत आहे / लोडिंग समस्या', desc: 'App is running slow or takes too long to load' },
  { id: 'c2', title: 'चाचणीतील प्रश्न खूप कठीण किंवा अस्पष्ट वाटतात', desc: 'Quiz questions are confusing or too difficult' },
  { id: 'c3', title: 'दैनिक टास्क पूर्ण केल्यावर प्रगती सेव्ह होत नाही', desc: 'Daily task progress is not saving properly' },
  { id: 'c4', title: 'संध्याकाळचे रिमाइंडर नोटिफिकेशन वेळेवर येत नाही', desc: 'Reminder notification is not received on time' },
  { id: 'c5', title: 'डार्क मोड किंवा स्क्रीन डिस्प्लेमध्ये त्रुटी आहे', desc: 'Display or dark mode visual styling glitch' },
  { id: 'c6', title: 'बटन किंवा स्क्रीन नेव्हिगेशन अडकते', desc: 'Buttons or screen navigation not responding' },
  { id: 'c7', title: 'अधिक प्रोजेक्ट्स आणि नवीन प्रॅक्टिस विषय हवे आहेत', desc: 'Need more coding practice topics and projects' },
  { id: 'c8', title: 'स्टुडन्ट आयडी किंवा प्रोफाइल डेटा संबंधित समस्या', desc: 'Student ID or profile sync issue' },
];

interface Props {
  profile: UserProfile;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onUpdateProfile: (profile: UserProfile) => void;
  onResetData?: () => void;
  onLogout?: () => void;
  language?: 'en' | 'mr' | 'hi';
  setLanguage?: (lang: 'en' | 'mr' | 'hi') => void;
  iconColor?: IconColorKey;
  setIconColor?: (val: IconColorKey) => void;
  bgColor?: BgColorKey;
  setBgColor?: (val: BgColorKey) => void;
  readingMode?: boolean;
  setReadingMode?: (val: boolean) => void;
  onOpenAiGoalsQuiz?: () => void;
}

const DEFAULT_ACHIEVED_SKILLS: SkillItem[] = [
  { id: 'a1', title: 'Python Basics', description: 'Variables, loops, functions and fundamental syntax.', level: '100%', badge: 'Mastered' },
  { id: 'a2', title: 'Computer Shortcut Keys', description: 'Essential keyboard shortcuts for fast productivity.', level: '100%', badge: 'Mastered' },
  { id: 'a3', title: 'HTML5 & CSS3 Layouts', description: 'Semantic structure, flexbox and responsive design.', level: '95%', badge: 'Advanced' },
  { id: 'a4', title: 'Git & Version Control', description: 'Repository management, commits and GitHub branches.', level: '90%', badge: 'Proficient' },
];

const DEFAULT_MISSING_SKILLS: SkillItem[] = [
  { id: 'm1', title: 'First Generation Architecture', description: 'Vacuum tubes, ENIAC and early machine language.', status: 'In Progress (Day 3)', progress: '50%' },
  { id: 'm2', title: 'Second Generation Computing', description: 'Transistors, core memory and assembly language.', status: 'Pending Milestone', progress: '0%' },
  { id: 'm3', title: 'Third & Fourth Gen Systems', description: 'Integrated circuits, microprocessors and VLSI chips.', status: 'Upcoming Target', progress: '0%' },
  { id: 'm4', title: 'Algorithms & Problem Solving', description: 'Data structures, pattern matching and complexity.', status: 'Planned Topic', progress: '15%' },
];

export const ProfileScreen: React.FC<Props> = ({ 
  profile, 
  darkMode, 
  setDarkMode, 
  onUpdateProfile, 
  onLogout, 
  language = 'en', 
  setLanguage,
  iconColor = 'sky',
  setIconColor,
  bgColor = 'default',
  setBgColor,
  readingMode = false,
  setReadingMode,
  onOpenAiGoalsQuiz,
}) => {
  const t = translations[language];
  const iconDef = getIconColorDef(iconColor);
  const [name, setName] = useState(profile.name || 'RIDER');
  const [email, setEmail] = useState(profile.email || 'ridergeming170@gmail.com');
  const [major, setMajor] = useState(profile.major || 'Computer Science & Engineering');
  const [year, setYear] = useState(profile.year || 'Junior (Year 3)');
  const [gender, setGender] = useState<'male' | 'female' | 'other'>(profile.gender || 'male');
  const [savedMessage, setSavedMessage] = useState(false);
  const [showPhotoMenu, setShowPhotoMenu] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [skillTab, setSkillTab] = useState<'achieved' | 'missing'>('achieved');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Goal Change & History state
  const [isChangingGoal, setIsChangingGoal] = useState(false);
  const [newGoalName, setNewGoalName] = useState('');
  const [reasonForLeaving, setReasonForLeaving] = useState('');
  const [goalReasonError, setGoalReasonError] = useState<string | null>(null);

  // Help & Report state
  const [showHelpReportModal, setShowHelpReportModal] = useState(false);
  const [reportRating, setReportRating] = useState<number>(5);
  const [selectedComplaints, setSelectedComplaints] = useState<string[]>([]);
  const [reportSubmitted, setReportSubmitted] = useState(false);
  const [reportTicketId, setReportTicketId] = useState<string | null>(null);

  const handleToggleComplaint = (complaintTitle: string) => {
    setSelectedComplaints(prev => 
      prev.includes(complaintTitle)
        ? prev.filter(c => c !== complaintTitle)
        : [...prev, complaintTitle]
    );
  };

  const handleSendReport = () => {
    const ticketId = 'TKT-' + Math.floor(10000 + Math.random() * 90000);
    setReportTicketId(ticketId);
    setReportSubmitted(true);

    try {
      const existing = JSON.parse(localStorage.getItem('spa_reports') || '[]');
      const newReport = {
        ticketId,
        rating: reportRating,
        complaints: selectedComplaints.length > 0 ? selectedComplaints : ['General App Feedback / सामान्य अभिप्राय'],
        userName: profile.name,
        userEmail: profile.email,
        submittedAt: new Date().toISOString(),
      };
      localStorage.setItem('spa_reports', JSON.stringify([newReport, ...existing]));

      // Also create a notification
      const existingNotifs = JSON.parse(localStorage.getItem('spa_notifications') || '[]');
      const notif = {
        id: 'notif_' + Date.now(),
        title: `तक्रार नोंदवली (#${ticketId})`,
        message: `तुमचा अभिप्राय (${reportRating}★) व तक्रार यशस्वीरीत्या नोंदवली गेली. Ticket: #${ticketId}`,
        time: 'Just now',
        read: false,
        type: 'system',
      };
      localStorage.setItem('spa_notifications', JSON.stringify([notif, ...existingNotifs]));
    } catch (e) {
      console.error('Error saving report:', e);
    }
  };

  // Dynamic Skill Lists
  const [achievedSkills, setAchievedSkills] = useState<SkillItem[]>(() => {
    return profile.achievedSkills !== undefined
      ? profile.achievedSkills 
      : DEFAULT_ACHIEVED_SKILLS;
  });

  const [missingSkills, setMissingSkills] = useState<SkillItem[]>(() => {
    return profile.missingSkills !== undefined
      ? profile.missingSkills 
      : DEFAULT_MISSING_SKILLS;
  });

  useEffect(() => {
    if (profile.achievedSkills !== undefined) {
      setAchievedSkills(profile.achievedSkills);
    }
  }, [profile.achievedSkills]);

  useEffect(() => {
    if (profile.missingSkills !== undefined) {
      setMissingSkills(profile.missingSkills);
    }
  }, [profile.missingSkills]);

  // Modal for adding skills with AI scan & quiz
  const [isAddSkillModalOpen, setIsAddSkillModalOpen] = useState(false);
  const [addSkillModalType, setAddSkillModalType] = useState<'achieved' | 'missing'>('achieved');

  const handleOpenAddSkill = (type: 'achieved' | 'missing') => {
    setAddSkillModalType(type);
    setIsAddSkillModalOpen(true);
  };

  const handleAddAchievedSkill = (newSkill: SkillItem) => {
    const updated = [newSkill, ...achievedSkills];
    setAchievedSkills(updated);
    onUpdateProfile({
      ...profile,
      achievedSkills: updated,
      missingSkills,
    });
  };

  const handleAddMissingSkill = (newSkill: SkillItem) => {
    const updated = [newSkill, ...missingSkills];
    setMissingSkills(updated);
    onUpdateProfile({
      ...profile,
      achievedSkills,
      missingSkills: updated,
    });
  };

  const handleDeleteSkill = (id: string, type: 'achieved' | 'missing') => {
    if (type === 'achieved') {
      const updated = achievedSkills.filter(s => s.id !== id);
      setAchievedSkills(updated);
      onUpdateProfile({
        ...profile,
        achievedSkills: updated,
        missingSkills,
      });
    } else {
      const updated = missingSkills.filter(s => s.id !== id);
      setMissingSkills(updated);
      onUpdateProfile({
        ...profile,
        achievedSkills,
        missingSkills: updated,
      });
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    let finalGoalName = profile.goalName || 'Software Engineering';
    let finalHistory = profile.goalHistory || [];

    // If user is changing their goal
    if (isChangingGoal && newGoalName.trim()) {
      if (!reasonForLeaving.trim()) {
        setGoalReasonError('आधीचे ध्येय सोडण्याचे कारण निवडणे आवश्यक आहे! (Please select a reason for leaving the previous goal)');
        return;
      }
      setGoalReasonError(null);

      const historyItem: GoalHistoryItem = {
        id: 'gh_' + Date.now(),
        previousGoalName: profile.goalName || 'Software Engineering',
        newGoalName: newGoalName.trim(),
        reasonForLeaving: reasonForLeaving.trim(),
        changedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      };
      finalHistory = [historyItem, ...finalHistory];
      finalGoalName = newGoalName.trim();
    }

    onUpdateProfile({
      ...profile,
      name,
      email,
      major,
      year,
      gender,
      goalName: finalGoalName,
      goalHistory: finalHistory,
    });
    setSavedMessage(true);
    setTimeout(() => {
      setSavedMessage(false);
      setShowEditModal(false);
      setIsChangingGoal(false);
      setNewGoalName('');
      setReasonForLeaving('');
    }, 1200);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onUpdateProfile({
          ...profile,
          avatarUrl: reader.result as string,
        });
        setShowPhotoMenu(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    onUpdateProfile({
      ...profile,
      avatarUrl: undefined,
    });
    setShowPhotoMenu(false);
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in max-w-xl mx-auto relative">
      {/* Profile Header Card - Clean & Clutter-Free */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col items-center justify-center text-center space-y-3.5">
        {/* Avatar with Gender Indicator Icon Badge */}
        <div className="relative">
          <div 
            onClick={() => setShowPhotoMenu(true)}
            className="w-24 h-24 rounded-2xl bg-slate-100 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 flex items-center justify-center font-bold text-3xl text-slate-700 dark:text-slate-200 cursor-pointer relative group overflow-hidden shadow-md"
            title="Click to change profile photo"
          >
            {profile.avatarUrl ? (
              <img src={profile.avatarUrl} alt={name} className="w-full h-full object-cover rounded-2xl" />
            ) : (
              name ? name.charAt(0).toUpperCase() : <User size={40} className="text-slate-400 dark:text-slate-500" />
            )}
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <Camera size={22} className="text-white" />
            </div>
          </div>
          {/* Subtle Gender Icon Badge on corner of avatar */}
          <div 
            className={`absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center text-xs font-black shadow-md border-2 border-white dark:border-slate-900 ${
              (profile.gender || gender) === 'female'
                ? 'bg-pink-500 text-white'
                : 'bg-sky-500 text-white'
            }`}
            title={(profile.gender || gender) === 'female' ? 'Female (स्त्री)' : 'Male (पुरुष)'}
          >
            {(profile.gender || gender) === 'female' ? '♀' : '♂'}
          </div>
        </div>

        <div className="space-y-2 w-full">
          {/* User Name with Gender Icon */}
          <div className="flex items-center justify-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-wide">{name || 'RIDER'}</h1>
            <span 
              className={`font-black text-lg ${
                (profile.gender || gender) === 'female' ? 'text-pink-500' : 'text-sky-500'
              }`}
              title={(profile.gender || gender) === 'female' ? 'Female (स्त्री)' : 'Male (पुरुष)'}
            >
              {(profile.gender || gender) === 'female' ? '♀' : '♂'}
            </span>
          </div>

          {/* Action Buttons: Edit Profile & Help and Report */}
          <div className="flex items-center justify-center gap-2 pt-0.5 flex-wrap">
            <button
              type="button"
              onClick={() => {
                setGoalReasonError(null);
                setIsChangingGoal(false);
                setNewGoalName('');
                setReasonForLeaving('');
                setShowEditModal(true);
              }}
              className="px-4 py-2 rounded-2xl bg-sky-50 dark:bg-sky-950/70 hover:bg-sky-100 dark:hover:bg-sky-900/70 text-sky-600 dark:text-sky-400 font-bold text-xs transition-all flex items-center gap-1.5 active:scale-95 shadow-xs border border-sky-200/50 dark:border-sky-800/50 cursor-pointer"
            >
              <Pencil size={13} />
              <span>Edit Profile</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setReportSubmitted(false);
                setSelectedComplaints([]);
                setReportTicketId(null);
                setShowHelpReportModal(true);
              }}
              className="px-4 py-2 rounded-2xl bg-amber-50 dark:bg-amber-950/70 hover:bg-amber-100 dark:hover:bg-amber-900/70 text-amber-700 dark:text-amber-300 font-bold text-xs transition-all flex items-center gap-1.5 active:scale-95 shadow-xs border border-amber-200/50 dark:border-amber-800/50 cursor-pointer"
            >
              <HelpCircle size={14} className="text-amber-500" />
              <span>Help & Report</span>
            </button>
          </div>

          {/* Email Address directly under action buttons */}
          <div className="flex items-center justify-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-medium pt-0.5">
            <Mail size={13} className="text-sky-500 shrink-0" />
            <span className="select-all">{email || 'ridergeming170@gmail.com'}</span>
          </div>

          {/* Student ID & Active Goal Badges (No Birthday, No Age) */}
          <div className="flex items-center justify-center gap-2 flex-wrap pt-0.5 text-xs">
            {profile.studentId && (
              <span className="px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/70 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 font-bold tracking-wider">
                🎓 ID: {profile.studentId}
              </span>
            )}
            <span className="px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 font-semibold">
              🎯 Goal: {profile.goalName || 'Software Engineering'}
            </span>
          </div>
        </div>
      </div>

      {/* Horizontal Swipe / Tabs: Achieved Skills & Missing Skills */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        {/* Horizontal Toggle Header */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
          <button
            onClick={() => setSkillTab('achieved')}
            className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all ${
              skillTab === 'achieved'
                ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Award size={15} />
            <span>Achieved Skills</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
              {achievedSkills.length}
            </span>
          </button>

          <button
            onClick={() => setSkillTab('missing')}
            className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all ${
              skillTab === 'missing'
                ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Target size={15} />
            <span>Missing Skills</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
              {missingSkills.length}
            </span>
          </button>
        </div>

        {/* Vertical List Content */}
        {skillTab === 'achieved' ? (
          <div className="space-y-3 animate-in fade-in">
            {/* Header row with count */}
            <div className="flex items-center justify-between text-xs px-1">
              <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <CheckCircle2 size={15} className="text-emerald-500" />
                Completed Competencies
              </span>
              <span className="text-emerald-600 dark:text-emerald-400 font-bold text-xs">
                {achievedSkills.length} Total
              </span>
            </div>

            {/* List of Achieved Skills */}
            <div className="space-y-2 pt-1">
              {achievedSkills.map(skill => (
                <div
                  key={skill.id}
                  className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 shadow-sm hover:border-emerald-200 dark:hover:border-emerald-800 transition-colors group relative"
                >
                  <div className="min-w-0 flex-1 space-y-0.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
                      <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate">{skill.title}</h3>
                      {skill.isAiVerified && (
                        <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 flex items-center gap-0.5">
                          <Sparkles size={9} className="text-amber-500" />
                          AI Verified {skill.score ? `(${skill.score})` : ''}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 pl-6 leading-relaxed line-clamp-1">{skill.description}</p>
                    {skill.verifiedAt && (
                      <p className="text-[10px] text-slate-400 pl-6">Verified: {skill.verifiedAt}</p>
                    )}
                  </div>
                  <div className="text-right shrink-0 flex items-center gap-2">
                    <div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 inline-block">
                        {skill.badge || 'Mastered'}
                      </span>
                      <p className="text-xs font-black text-emerald-600 dark:text-emerald-400 mt-0.5">{skill.level || '100%'}</p>
                    </div>
                    {/* Delete button for custom added skills */}
                    {skill.id.startsWith('custom_') && (
                      <button
                        type="button"
                        onClick={() => handleDeleteSkill(skill.id, 'achieved')}
                        className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors opacity-80 group-hover:opacity-100"
                        title="Remove skill"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Bottom Add Achieved Skill Action Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={() => handleOpenAddSkill('achieved')}
                className="w-full py-3 px-4 rounded-2xl border-2 border-dashed border-emerald-300 dark:border-emerald-800/80 bg-emerald-50/50 dark:bg-emerald-950/20 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-98 shadow-xs"
              >
                <Plus size={16} />
                <span>+ Add Skill</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-3 animate-in fade-in">
            {/* Header row with count */}
            <div className="flex items-center justify-between text-xs px-1">
              <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <AlertCircle size={15} className="text-amber-500" />
                Skills In Queue & Needs Practice
              </span>
              <span className="text-amber-600 dark:text-amber-400 font-bold text-xs">
                {missingSkills.length} Pending
              </span>
            </div>

            {/* List of Missing Skills */}
            <div className="space-y-2 pt-1">
              {missingSkills.map(skill => (
                <div
                  key={skill.id}
                  className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 shadow-sm hover:border-amber-200 dark:hover:border-amber-800 transition-colors group relative"
                >
                  <div className="min-w-0 flex-1 space-y-0.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <AlertCircle size={16} className="text-amber-500 shrink-0" />
                      <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate">{skill.title}</h3>
                      {skill.isAdditional && (
                        <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800">
                          Additional Skill (Outside Main Goal)
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 pl-6 leading-relaxed line-clamp-1">{skill.description}</p>
                    {skill.isAdditional && (
                      <p className="text-[10px] text-amber-600 dark:text-amber-400 pl-6 font-medium">
                        💡 Self-learning: Not counted in primary goal pathway
                      </p>
                    )}
                  </div>
                  <div className="text-right shrink-0 flex items-center gap-2">
                    <div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full inline-block ${
                        skill.isAdditional 
                          ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800' 
                          : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400'
                      }`}>
                        {skill.badge || skill.status || 'Pending'}
                      </span>
                      <p className="text-xs font-black text-amber-600 dark:text-amber-400 mt-0.5">{skill.progress || '0%'}</p>
                    </div>
                    {/* Delete button for custom added skills */}
                    {skill.id.startsWith('custom_') && (
                      <button
                        type="button"
                        onClick={() => handleDeleteSkill(skill.id, 'missing')}
                        className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors opacity-80 group-hover:opacity-100"
                        title="Remove skill"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Bottom Add Missing Skill Action Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={() => handleOpenAddSkill('missing')}
                className="w-full py-3 px-4 rounded-2xl border-2 border-dashed border-indigo-300 dark:border-indigo-800/80 bg-indigo-50/50 dark:bg-indigo-950/20 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-98 shadow-xs"
              >
                <Plus size={16} />
                <span>+ Add Skill</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* AI Bot Skill Add & Verification Modal */}
      <SkillAddModal
        isOpen={isAddSkillModalOpen}
        onClose={() => setIsAddSkillModalOpen(false)}
        type={addSkillModalType}
        goalName={profile.goalName || 'Software Engineering'}
        onAddAchievedSkill={handleAddAchievedSkill}
        onAddMissingSkill={handleAddMissingSkill}
      />


      {/* Edit Profile Modal: ONLY displayed when clicking "Edit Your Profile" */}
      {showEditModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 relative animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400">
                  <Pencil size={18} />
                </div>
                <h2 className="font-bold text-slate-900 dark:text-white text-base">Edit Your Profile</h2>
              </div>
              <button
                onClick={() => setShowEditModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full"
              >
                <X size={20} />
              </button>
            </div>

            {savedMessage && (
              <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2 border border-emerald-200 dark:border-emerald-800 animate-in fade-in">
                <CheckCircle size={16} />
                <span>Profile saved successfully!</span>
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-4">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Full Name</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <User size={16} />
                  </span>
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                    placeholder="Full Name"
                    required
                  />
                </div>
              </div>

              {/* Gender Selection: Male ♂ / Female ♀ */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Gender (लिंग)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setGender('male')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                      gender === 'male'
                        ? 'bg-sky-50 dark:bg-sky-950/70 border-sky-400 text-sky-700 dark:text-sky-300 ring-2 ring-sky-500/30'
                        : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
                    }`}
                  >
                    <span className="text-base leading-none font-black text-sky-500">♂</span>
                    <span>Male (पुरुष)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setGender('female')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                      gender === 'female'
                        ? 'bg-pink-50 dark:bg-pink-950/70 border-pink-400 text-pink-700 dark:text-pink-300 ring-2 ring-pink-500/30'
                        : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
                    }`}
                  >
                    <span className="text-base leading-none font-black text-pink-500">♀</span>
                    <span>Female (स्त्री)</span>
                  </button>
                </div>
              </div>

              {/* Email Address */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Email Address</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Mail size={16} />
                  </span>
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                    placeholder="Email Address"
                  />
                </div>
              </div>

              {/* Major / Program */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Major / Program</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <BookOpen size={16} />
                  </span>
                  <input
                    type="text"
                    value={major}
                    onChange={e => setMajor(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                    placeholder="Major / Program"
                  />
                </div>
              </div>

              {/* Academic Year */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Academic Year</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Calendar size={16} />
                  </span>
                  <input
                    type="text"
                    value={year}
                    onChange={e => setYear(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                    placeholder="Academic Year"
                  />
                </div>
              </div>

              {/* GOAL MODIFICATION SECTION WITH MANDATORY REASON */}
              <div className="p-3.5 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200/80 dark:border-indigo-800/60 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-indigo-500 dark:text-indigo-400">
                      Active Career Goal
                    </span>
                    <p className="text-sm font-black text-indigo-950 dark:text-indigo-200 flex items-center gap-1.5">
                      <Target size={15} className="text-indigo-600 dark:text-indigo-400" />
                      {profile.goalName || 'Software Engineering'}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsChangingGoal(!isChangingGoal);
                      setGoalReasonError(null);
                      if (!isChangingGoal) {
                        setNewGoalName('');
                        setReasonForLeaving('');
                      }
                    }}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all shadow-xs cursor-pointer ${
                      isChangingGoal
                        ? 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200'
                        : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                    }`}
                  >
                    {isChangingGoal ? 'Cancel' : 'Change Goal (ध्येय बदला)'}
                  </button>
                </div>

                {isChangingGoal && (
                  <div className="space-y-3 pt-2 border-t border-indigo-100 dark:border-indigo-900/60 animate-in fade-in">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                          नवीन करिअर ध्येय (New Target Goal) *
                        </label>
                        {onOpenAiGoalsQuiz && (
                          <button
                            type="button"
                            onClick={onOpenAiGoalsQuiz}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 text-white text-[10px] font-bold shadow-xs hover:opacity-90 transition active:scale-95 cursor-pointer"
                          >
                            <Sparkles size={11} className="text-amber-300" />
                            <span>🦉 AI ने ध्येय ठरवा</span>
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        value={newGoalName}
                        onChange={e => setNewGoalName(e.target.value)}
                        placeholder="उदा. AI & Machine Learning, Full-Stack Dev..."
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        required={isChangingGoal}
                      />
                      <div className="flex flex-wrap gap-1.5 pt-2">
                        {POPULAR_GOALS.map(g => (
                          <button
                            key={g}
                            type="button"
                            onClick={() => setNewGoalName(g)}
                            className={`px-2 py-0.8 rounded-lg text-[10px] font-semibold border transition-all ${
                              newGoalName === g
                                ? 'bg-indigo-600 text-white border-indigo-600'
                                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-indigo-300'
                            }`}
                          >
                            {g}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* MANDATORY: REASON FOR LEAVING PREVIOUS GOAL */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-black text-rose-600 dark:text-rose-400 flex items-center gap-1">
                          <Flag size={12} />
                          आधीचे ध्येय सोडण्याचे कारण (Reason Required) *
                        </label>
                        <span className="text-[10px] font-bold text-rose-500">आवश्यक</span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        कृपया खालीलपैकी कारण निवडा:
                      </p>
                      
                      <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                        {GOAL_LEAVING_REASONS.map((r, idx) => (
                          <div
                            key={idx}
                            onClick={() => {
                              setReasonForLeaving(r);
                              setGoalReasonError(null);
                            }}
                            className={`p-2 rounded-xl text-xs border cursor-pointer transition-all flex items-center justify-between ${
                              reasonForLeaving === r
                                ? 'bg-rose-50 dark:bg-rose-950/70 border-rose-400 text-rose-900 dark:text-rose-200 font-bold'
                                : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                            }`}
                          >
                            <span className="text-[11px] leading-tight">{r}</span>
                            {reasonForLeaving === r && <Check size={14} className="text-rose-600 shrink-0 ml-1.5" />}
                          </div>
                        ))}
                      </div>

                      {goalReasonError && (
                        <div className="p-2 rounded-xl bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center gap-1.5 border border-rose-300 dark:border-rose-800">
                          <AlertCircle size={14} className="shrink-0" />
                          <span>{goalReasonError}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* GOAL HISTORY SECTION */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <History size={14} className="text-sky-500" />
                    Goal History (मागील ध्येयांचा इतिहास)
                  </span>
                  <span className="text-[10px] font-semibold text-slate-400">
                    {(profile.goalHistory?.length || 0)} नोंदी
                  </span>
                </div>

                {profile.goalHistory && profile.goalHistory.length > 0 ? (
                  <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                    {profile.goalHistory.map(item => (
                      <div key={item.id} className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1 text-xs">
                        <div className="flex items-center justify-between text-[10px] text-slate-400 font-medium">
                          <span>{item.changedAt}</span>
                          <span className="text-amber-600 dark:text-amber-400 font-bold">Goal Changed</span>
                        </div>
                        <div className="flex items-center gap-1.5 font-bold text-slate-800 dark:text-slate-200 text-xs">
                          <span className="line-through text-slate-400">{item.previousGoalName}</span>
                          <ChevronRight size={12} className="text-sky-500" />
                          <span className="text-emerald-600 dark:text-emerald-400">{item.newGoalName}</span>
                        </div>
                        <p className="text-[11px] text-rose-600 dark:text-rose-400 font-medium italic">
                          कारण: "{item.reasonForLeaving}"
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 italic py-1">
                    अद्याप कोणताही ध्येय बदल केलेला नाही. हे तुमचे पहिले ध्येय आहे.
                  </p>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="px-4 py-2.5 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold text-xs transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-sky-600 text-white font-bold text-xs shadow-md shadow-sky-600/20 hover:bg-sky-700 transition-all flex items-center gap-2"
                >
                  <Save size={16} /> Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* HELP AND REPORT MODAL (NO MANUAL TYPING REQUIRED) */}
      {showHelpReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 relative animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400">
                  <HelpCircle size={18} />
                </div>
                <div>
                  <h2 className="font-bold text-slate-900 dark:text-white text-base">Help & Report</h2>
                  <p className="text-[11px] text-slate-500">ॲप अभिप्राय व तक्रार निवारण</p>
                </div>
              </div>
              <button
                onClick={() => setShowHelpReportModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {reportSubmitted ? (
              /* Success / Ticket Confirmation Screen */
              <div className="py-6 text-center space-y-4 animate-in zoom-in-95">
                <div className="w-16 h-16 rounded-3xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-md">
                  <CheckCircle size={36} />
                </div>
                <div className="space-y-1">
                  <h3 className="font-black text-lg text-slate-900 dark:text-white">
                    तक्रार यशस्वीरित्या नोंदवली!
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    तुमचा अभिप्राय व समस्या आमच्या टीमकडे पाठवली आहे.
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Ticket ID:</span>
                    <span className="font-black font-mono text-sky-600 dark:text-sky-400">#{reportTicketId}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">App Rating:</span>
                    <span className="font-bold text-amber-500">{'★'.repeat(reportRating)}{'☆'.repeat(5 - reportRating)} ({reportRating}/5)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Selected Issues:</span>
                    <span className="font-bold text-slate-700 dark:text-slate-300">{selectedComplaints.length} नोंदी</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowHelpReportModal(false)}
                  className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all active:scale-98 cursor-pointer"
                >
                  Close / बंद करा
                </button>
              </div>
            ) : (
              /* Form to choose Rating and Select Predefined Complaints (NO TYPING) */
              <div className="space-y-4">
                {/* 1. App Rating (1 to 5 Stars) */}
                <div className="p-3.5 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40 space-y-2 text-center">
                  <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                    ॲपला रेटिंग द्या (Rate this App)
                  </label>
                  <div className="flex items-center justify-center gap-2">
                    {[1, 2, 3, 4, 5].map(star => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReportRating(star)}
                        className="p-1 hover:scale-125 transition-transform cursor-pointer"
                      >
                        <Star
                          size={28}
                          className={
                            star <= reportRating
                              ? 'text-amber-400 fill-amber-400'
                              : 'text-slate-300 dark:text-slate-600'
                          }
                        />
                      </button>
                    ))}
                  </div>
                  <p className="text-[11px] font-semibold text-amber-700 dark:text-amber-300">
                    {reportRating === 1 && '★☆☆☆☆ Poor (खूप समस्या आहेत)'}
                    {reportRating === 2 && '★★☆☆☆ Needs Improvement (सुधारणा हवी)'}
                    {reportRating === 3 && '★★★☆☆ Average (मध्यम अनुभव)'}
                    {reportRating === 4 && '★★★★☆ Good (छान ॲप)'}
                    {reportRating === 5 && '★★★★★ Excellent (उत्कृष्ट अनुभव!)'}
                  </p>
                </div>

                {/* 2. Predefined Complaints Selection - NO TYPING */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      ॲपमधील समस्या किंवा तक्रार निवडा (Select Issues):
                    </label>
                    <span className="text-[10px] font-bold text-sky-600 dark:text-sky-400">
                      {selectedComplaints.length} निवडले
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    स्वतः टाइप करण्याची गरज नाही, खालीलपैकी समस्यांवर क्लिक करा:
                  </p>

                  <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
                    {PREDEFINED_COMPLAINTS.map(item => {
                      const isSelected = selectedComplaints.includes(item.title);
                      return (
                        <div
                          key={item.id}
                          onClick={() => handleToggleComplaint(item.title)}
                          className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all flex items-start justify-between gap-2.5 ${
                            isSelected
                              ? 'bg-amber-50 dark:bg-amber-950/60 border-amber-400 dark:border-amber-700 text-amber-900 dark:text-amber-200 font-semibold'
                              : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                          }`}
                        >
                          <div className="space-y-0.5 min-w-0">
                            <p className="text-xs leading-snug">{item.title}</p>
                            <p className="text-[10px] text-slate-400 leading-tight">{item.desc}</p>
                          </div>
                          <div className={`w-5 h-5 rounded-lg border flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                            isSelected
                              ? 'bg-amber-500 border-amber-500 text-white'
                              : 'border-slate-300 dark:border-slate-600'
                          }`}>
                            {isSelected && <Check size={13} className="stroke-[3]" />}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Send Report Button */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowHelpReportModal(false)}
                    className="px-4 py-2.5 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold text-xs"
                  >
                    रद्द करा
                  </button>
                  <button
                    type="button"
                    onClick={handleSendReport}
                    className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-900 font-black text-xs shadow-md shadow-amber-500/20 transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
                  >
                    <Flag size={14} />
                    <span>Send Report (तक्रार पाठवा)</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Photo Option Modal (Add / Remove) */}
      {showPhotoMenu && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xs w-full shadow-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 text-center relative animate-in zoom-in-95">
            <button
              onClick={() => setShowPhotoMenu(false)}
              className="absolute top-3 right-3 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full"
            >
              <X size={18} />
            </button>

            <h3 className="font-bold text-slate-900 dark:text-white text-base">Profile Photo</h3>
            <p className="text-xs text-slate-500">Update or remove your avatar image</p>

            <div className="space-y-2 pt-2">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />

              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-3 rounded-xl bg-sky-600 text-white font-bold text-xs shadow-md shadow-sky-600/20 hover:bg-sky-700 transition-all flex items-center justify-center gap-2"
              >
                <Camera size={16} /> Choose from Device
              </button>

              {profile.avatarUrl && (
                <button
                  onClick={handleRemovePhoto}
                  className="w-full py-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 font-bold text-xs hover:bg-rose-100 transition-all flex items-center justify-center gap-2"
                >
                  <Trash2 size={16} /> Remove Photo
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Log Out Option */}
      {onLogout && (
        <div className="pt-2">
          <button
            onClick={onLogout}
            className="w-full py-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/40 text-rose-600 dark:text-rose-400 font-bold text-xs border border-rose-200/60 dark:border-rose-900/50 transition-all flex items-center justify-center gap-2 active:scale-98"
          >
            <LogOut size={16} />
            <span>Log Out</span>
          </button>
        </div>
      )}
    </div>
  );
};
