import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, 
  Send, 
  Sparkles, 
  Flame, 
  Award, 
  Bot, 
  CheckCircle2, 
  HelpCircle, 
  RotateCcw, 
  Lightbulb,
  Target,
  Clock,
  ShieldCheck,
  Zap,
  Lock
} from 'lucide-react';
import { UserProfile, TabType } from '../types';

interface AIBotScreenProps {
  profile: UserProfile;
  streakDays: number;
  onUpdateStreak: (days: number) => void;
  setActiveTab: (tab: TabType) => void;
  language?: 'en' | 'mr' | 'hi';
}

interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  suggestedAction?: string;
}

export const AIBotScreen: React.FC<AIBotScreenProps> = ({
  profile,
  streakDays,
  onUpdateStreak,
  setActiveTab,
  language = 'en',
}) => {
  const goalTitle = profile.goalName || 'AI Software Engineer';
  const isUnlocked = streakDays >= 7;

  // Initial welcome message
  const getInitialMessages = (): ChatMessage[] => [
    {
      id: 'm1',
      sender: 'bot',
      text: language === 'mr'
        ? `नमस्कार ${profile.name || 'विद्यार्थी'}! 👋 अभिनंदन! तुम्ही सलग 7 दिवस लॉग इन करून तुमचा पर्सनल AI Chat Bot अनलॉक केला आहे! 🔥\n\nतुमचे लक्ष्य '${goalTitle}' साध्य करण्यासाठी मी 24/7 तुमच्या मदतीसाठी तयार आहे. आज आपण काय शिकायचे?`
        : language === 'hi'
        ? `नमस्ते ${profile.name || 'विद्यार्थी'}! 👋 बधाई हो! आपने लगातार 7 दिन लॉग इन करके अपना पर्सनल AI Chat Bot अनलॉक कर लिया है! 🔥\n\nआपके लक्ष्य '${goalTitle}' को पूरा करने के लिए मैं हर समय तैयार हूँ। आज आप क्या सीखना चाहते हैं?`
        : `Hello ${profile.name || 'Student'}! 👋 Congratulations on keeping your 7-day login streak alive to unlock your dedicated AI Companion! 🔥\n\nI am here 24/7 to help you conquer '${goalTitle}'. What would you like to explore or practice today?`,
      timestamp: 'Just now',
    },
  ];

  const [messages, setMessages] = useState<ChatMessage[]>(getInitialMessages);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Auto scroll chat
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const promptSuggestions = language === 'mr' ? [
    '💡 आजची अभ्यासाची खास टीप (Study Tip)',
    `🎯 '${goalTitle}' साठी कोणती कौशल्ये आधी शिकावीत?`,
    '🔥 30 दिवसांची स्ट्रीक कशी पूर्ण करावी?',
    '⚡ इंटरव्ह्यू कोडिंगची सराव पद्धत',
  ] : language === 'hi' ? [
    '💡 आज की पढ़ाई की खास टिप (Study Tip)',
    `🎯 '${goalTitle}' के लिए पहले कौन से स्किल्स सीखें?`,
    '🔥 30 दिनों की स्ट्रीक कैसे पूरी करें?',
    '⚡ इंटरव्यू कोडिंग अभ्यास तकनीक',
  ] : [
    '💡 Give me today’s high-yield study tip',
    `🎯 Essential skill roadmap for '${goalTitle}'`,
    '🔥 How to reach the 30-Day Master Streak?',
    '⚡ Quick practice challenge for interview',
  ];

  const handleSend = (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query) return;

    const userMsg: ChatMessage = {
      id: 'usr_' + Date.now(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInputText('');
    setIsTyping(true);

    // AI intelligent response generator
    setTimeout(() => {
      let botResponse = '';
      const qLower = query.toLowerCase();

      if (qLower.includes('study tip') || qLower.includes('अभ्यास') || qLower.includes('tip')) {
        botResponse = language === 'mr'
          ? `💡 **आजची AI स्मार्ट टीप:**\n1. **25/5 Pomodoro Rule:** 25 मिनिटे एकाग्रतेने सराव करा, नंतर 5 मिनिटे ब्रेक घ्या.\n2. **Active Recall:** वाचण्यापेक्षा स्वतः कोड लिहून त्रुटी दुरुस्त करा.\n3. **Consistency:** दररोज 20 मिनिटे सुद्धा खूप मोठा फरक पाडतात!`
          : `💡 **Today's AI Smart Study Tip:**\n1. **Pomodoro Focus:** 25 minutes pure coding, 5 minutes resting.\n2. **Code First:** Don't just watch videos—type every line in your IDE.\n3. **Daily Habit:** Consistency beats intensity. Keep your streak burning! 🔥`;
      } else if (qLower.includes('skill') || qLower.includes('कौशल्ये') || qLower.includes('roadmap')) {
        botResponse = language === 'mr'
          ? `🎯 **'${goalTitle}' साठी स्टेप-बाय-स्टेप प्लॅन:**\n• **Step 1:** Core Fundamentals (Python / DSA)\n• **Step 2:** Hands-on Projects (Portfolio Building)\n• **Step 3:** System Architecture & Real Deployment\n• **Step 4:** Daily Assessment Quizzes!`
          : `🎯 **Step-by-Step Roadmap for '${goalTitle}':**\n• **Step 1:** Core Foundations (Logic & Data Structures)\n• **Step 2:** Mini Builds (Apply immediately)\n• **Step 3:** Modern Frameworks & API Integration\n• **Step 4:** Daily Reassessment & Quiz refinement!`;
      } else if (qLower.includes('30') || qLower.includes('streak') || qLower.includes('स्ट्रीक')) {
        botResponse = language === 'mr'
          ? `🔥 **30-Day Master Milestone Rules:**\n• तुम्ही सध्या **Day ${streakDays}** वर आहात!\n• **सलग लॉग इन:** दररोज ॲप ओपन करा आणि तुमचे रोजचे टास्क पूर्ण करा.\n• **Strict Rule:** जर एकही दिवस चुकला, तर स्ट्रीक पुन्हा **Day 1** वर रीसेट होते!\n• **30-Day Reward:** Golden Master Badge आणि Super AI Mentor अनलॉकिंग!`
          : `🔥 **30-Day Master Milestone Rules:**\n• You are currently on **Day ${streakDays}**!\n• **Daily Check-in:** Open the app daily and conquer your micro-tasks.\n• **Strict Rule:** If even 1 day is missed, your streak resets back to Day 1!\n• **30-Day Perk:** Golden Master Badge & Unlocked Super AI Mentor mode!`;
      } else {
        botResponse = language === 'mr'
          ? `उत्कृष्ट प्रश्न! 🚀 '${goalTitle}' च्या दिशेने वाटचाल करताना नेहमी लहान लहान ध्येये ठेवा. तुम्ही दररोज सलग लॉग इन करत आहात हे तुमच्या शिस्तीचे प्रतीक आहे. अजून काही अडचण असेल तर मला नक्की विचारा!`
          : `Great question! 🚀 In mastering '${goalTitle}', daily deliberate practice is everything. Your active ${streakDays}-day streak proves your commitment. What concept should we break down next?`;
      }

      const botMsg: ChatMessage = {
        id: 'bot_' + Date.now(),
        sender: 'bot',
        text: botResponse,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, botMsg]);
      setIsTyping(false);
    }, 600);
  };

  return (
    <div className="space-y-5 pb-24 animate-in fade-in max-w-3xl mx-auto">
      {/* Top Header & Navigation */}
      <div className="flex items-center justify-between bg-white dark:bg-slate-900 rounded-2xl p-3 sm:p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
        <button
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-1.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-sky-600 dark:hover:text-sky-400 transition-colors"
        >
          <ArrowLeft size={16} />
          <span>{language === 'mr' ? 'होम कडे परत' : 'Back to Home'}</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/60 text-emerald-600 dark:text-emerald-400 px-2.5 py-1 rounded-full text-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>AI Bot 24/7</span>
          </div>
          <div className="flex items-center gap-1 bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800/60 text-amber-600 dark:text-amber-400 px-2.5 py-1 rounded-full text-xs font-black">
            <Flame size={14} className="fill-amber-500 text-amber-500" />
            <span>{streakDays}d Streak</span>
          </div>
        </div>
      </div>

      {/* Locked Warning Banner (if visited with < 7 days streak) */}
      {!isUnlocked && (
        <div className="bg-amber-500/10 border-2 border-amber-500/40 rounded-3xl p-5 text-center space-y-3">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-500/20 text-amber-500 flex items-center justify-center font-bold">
            <Lock size={26} />
          </div>
          <div>
            <h3 className="text-base font-black text-amber-500">
              {language === 'mr' ? '7 दिवसांची लॉग इन स्ट्रीक आवश्यक आहे' : '7-Day Login Streak Required'}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 max-w-md mx-auto">
              {language === 'mr'
                ? `सध्या तुमची स्ट्रीक ${streakDays} दिवस आहे. AI Bot Companion अनलॉक करण्यासाठी सलग 7 दिवस लॉग इन आवश्यक आहे.`
                : `Your current streak is ${streakDays} day(s). You need a 7-consecutive-day login streak to unlock this AI Companion.`}
            </p>
          </div>

          <div className="pt-1 flex flex-wrap items-center justify-center gap-2">
            <button
              onClick={() => onUpdateStreak(7)}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-white font-extrabold text-xs shadow hover:scale-105 transition-all flex items-center gap-1.5"
            >
              <Zap size={14} />
              <span>{language === 'mr' ? '7 दिवसांची स्ट्रीक सेट करा (Test Mode)' : 'Set 7-Day Streak (Test Unlock)'}</span>
            </button>
            <button
              onClick={() => setActiveTab('home')}
              className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs hover:bg-slate-300 transition-colors"
            >
              {language === 'mr' ? 'होम वर जा' : 'Return to Home'}
            </button>
          </div>
        </div>
      )}

      {/* AI Bot Hero Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950 rounded-3xl p-5 sm:p-6 border border-sky-500/30 shadow-xl relative overflow-hidden text-white">
        {/* Glow Effects */}
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-sky-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
          {/* Animated Blinking AI Bot Pod */}
          <div className="relative flex-shrink-0 animate-bot-float">
            <div className="absolute -inset-2 rounded-3xl bg-gradient-to-r from-sky-400/40 via-cyan-400/40 to-indigo-500/40 blur-md pointer-events-none" />
            <div className="relative w-24 h-24 rounded-3xl p-1 bg-gradient-to-tr from-cyan-400 via-sky-500 to-indigo-500 shadow-[0_0_25px_rgba(56,189,248,0.45)]">
              <div className="w-full h-full bg-slate-950 rounded-[20px] flex flex-col items-center justify-center relative overflow-hidden p-2">
                {/* Antenna status */}
                <div className="absolute top-1.5 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-[8px] font-black tracking-wider text-emerald-400 uppercase">ACTIVE</span>
                </div>

                {/* Cute Futuristic Face Screen with Active Moving Eyes */}
                <div className="w-16 h-10 bg-slate-900/90 rounded-2xl border border-cyan-400/40 flex items-center justify-center gap-2.5 px-2 shadow-inner relative mt-2">
                  <div className="relative w-3.5 h-4 bg-cyan-400 rounded-full flex items-center justify-center animate-bot-eye shadow-[0_0_8px_#22d3ee]">
                    <div className="w-1.5 h-1.5 bg-white rounded-full animate-bot-pupil" />
                  </div>
                  <div className="relative w-3.5 h-4 bg-cyan-400 rounded-full flex items-center justify-center animate-bot-eye shadow-[0_0_8px_#22d3ee]">
                    <div className="w-1.5 h-1.5 bg-white rounded-full animate-bot-pupil" />
                  </div>
                  <div className="absolute bottom-1 w-3 h-1 border-b-2 border-cyan-300 rounded-full" />
                </div>

                {/* Micro lights */}
                <div className="absolute bottom-1 flex items-center gap-1">
                  <span className="w-1 h-1 rounded-full bg-sky-400 animate-pulse" />
                  <span className="w-1 h-1 rounded-full bg-indigo-400 animate-pulse delay-75" />
                  <span className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse delay-150" />
                </div>
              </div>
            </div>
          </div>

          {/* Details & Target Goal */}
          <div className="flex-1 space-y-1.5 min-w-0">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/20 border border-sky-400/40 text-sky-300 text-xs font-bold">
              <Sparkles size={13} />
              <span>Personal AI Study Companion</span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-sky-200 via-cyan-200 to-indigo-200">
              {profile.name ? `${profile.name}'s AI Mentor` : 'Your Personal AI Mentor'}
            </h2>
            <p className="text-xs text-slate-300 max-w-md">
              Focusing on: <strong className="text-white">{goalTitle}</strong> • Unlocked with your 7-Day Login Streak.
            </p>

            {/* 30-Day Milestone Target Bar */}
            <div className="pt-2">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-300 mb-1">
                <span className="flex items-center gap-1 text-amber-400">
                  <Award size={13} />
                  <span>30-Day Master Goal</span>
                </span>
                <span className="text-sky-300">{streakDays}/30 Days</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700">
                <div 
                  className="bg-gradient-to-r from-amber-500 via-orange-500 to-sky-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, Math.round((streakDays / 30) * 100))}%` }}
                />
              </div>
              <p className="text-[10px] text-slate-400 mt-1">
                ⚠️ Strict rule: Log in every day. Missed even 1 day? Streak resets to Day 1!
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Suggested Quick Action Chips */}
      <div className="space-y-1.5">
        <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 px-1 uppercase tracking-wider">
          {language === 'mr' ? 'जलद प्रश्न निवडा:' : 'Quick Prompts:'}
        </span>
        <div className="flex flex-wrap gap-2">
          {promptSuggestions.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(prompt)}
              className="text-xs px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-sky-500 dark:hover:border-sky-500 text-slate-700 dark:text-slate-200 hover:text-sky-600 dark:hover:text-sky-400 font-medium transition-all shadow-sm active:scale-95 text-left"
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Chat Window */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-lg flex flex-col h-[420px] overflow-hidden">
        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex gap-2.5 max-w-[85%] sm:max-w-[78%] ${
                msg.sender === 'user' ? 'ml-auto flex-row-reverse' : ''
              }`}
            >
              {msg.sender === 'bot' && (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 text-white flex items-center justify-center shrink-0 shadow-sm mt-0.5">
                  <Bot size={16} />
                </div>
              )}

              <div
                className={`rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-sky-600 to-indigo-600 text-white rounded-br-xs shadow-md'
                    : 'bg-slate-100 dark:bg-slate-800/90 text-slate-800 dark:text-slate-100 rounded-bl-xs border border-slate-200/80 dark:border-slate-700/60 shadow-sm'
                }`}
              >
                {msg.text}
                <div
                  className={`text-[9px] mt-1.5 text-right ${
                    msg.sender === 'user' ? 'text-sky-200' : 'text-slate-400'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-2.5 max-w-[80%] items-center">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <Bot size={16} />
              </div>
              <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl px-4 py-2.5 border border-slate-200 dark:border-slate-700 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-sky-500 rounded-full animate-bounce" />
                <span className="w-1.5 h-1.5 bg-sky-500 rounded-full animate-bounce delay-100" />
                <span className="w-1.5 h-1.5 bg-sky-500 rounded-full animate-bounce delay-200" />
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Input Bar */}
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 bg-slate-50 dark:bg-slate-950/70 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2"
        >
          <input
            type="text"
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            placeholder={language === 'mr' ? 'AI Bot ला काहीही विचारा...' : 'Ask AI Bot anything about your goal...'}
            className="flex-1 px-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-2.5 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 text-white hover:from-sky-500 hover:to-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed shadow transition-all cursor-pointer"
          >
            <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  );
};
