import React, { useState } from 'react';
import { AssessmentQuestion } from '../types';
import { Award, ArrowRight, RotateCcw, Sparkles } from 'lucide-react';

interface Props {
  questions: AssessmentQuestion[];
  onCompleteAssessment: (score: number) => void;
  language?: 'en' | 'mr' | 'hi';
}

export const AssessScreen: React.FC<Props> = ({ questions, onCompleteAssessment, language = 'en' }) => {
  const isMr = language === 'mr';
  const [started, setStarted] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [submittedAnswers, setSubmittedAnswers] = useState<{ [key: number]: number }>({});

  const handleStart = () => {
    setStarted(true);
    setCurrentIndex(0);
    setScore(0);
    setShowResult(false);
    setSelectedOption(null);
    setSubmittedAnswers({});
  };

  const handleSelectOption = (index: number) => {
    setSelectedOption(index);
  };

  const handleNext = () => {
    if (selectedOption === null) return;
    const currentQ = questions[currentIndex];
    const isCorrect = selectedOption === currentQ.correctIndex;
    const newScore = isCorrect ? score + 1 : score;
    setScore(newScore);
    setSubmittedAnswers({ ...submittedAnswers, [currentIndex]: selectedOption });

    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedOption(null);
    } else {
      setShowResult(true);
      onCompleteAssessment(newScore);
    }
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in max-w-2xl mx-auto pt-4">
      {!started ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-10 border border-slate-200 dark:border-slate-800 shadow-sm text-center space-y-6 max-w-lg mx-auto">
          <div className="w-20 h-20 bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400 rounded-3xl mx-auto flex items-center justify-center shadow-inner">
            <Sparkles size={36} />
          </div>

          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
              {isMr ? 'कौशल्याचे पुनर्मूल्यांकन' : 'Skill Reassessment'}
            </h2>
          </div>

          <button
            onClick={handleStart}
            className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 text-white font-bold text-sm shadow-xl shadow-sky-600/25 hover:from-sky-500 hover:to-indigo-500 transition-all inline-flex items-center gap-2 active:scale-95 cursor-pointer"
          >
            <span>{isMr ? 'पुनर्मूल्यांकन सुरू करा' : 'Start Reassessment'}</span>
            <ArrowRight size={18} />
          </button>
        </div>
      ) : !showResult ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 pb-4 border-b border-slate-100 dark:border-slate-800">
            <span>{isMr ? `प्रश्न ${currentIndex + 1} पैकी ${questions.length}` : `Question ${currentIndex + 1} of ${questions.length}`}</span>
            <span className="text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950 px-2.5 py-1 rounded-full">
              {questions[currentIndex].category}
            </span>
          </div>

          <h3 className="text-base font-bold text-slate-900 dark:text-white leading-relaxed">
            {questions[currentIndex].question}
          </h3>

          <div className="space-y-3">
            {questions[currentIndex].options.map((option, idx) => {
              const isSelected = selectedOption === idx;
              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  className={`w-full text-left p-4 rounded-2xl border text-xs font-medium transition-all flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'border-sky-600 bg-sky-50/50 dark:bg-sky-950/40 text-sky-900 dark:text-sky-200 shadow-sm'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <span>{option}</span>
                  <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                    isSelected ? 'border-sky-600 bg-sky-600 text-white' : 'border-slate-300 dark:border-slate-600'
                  }`}>
                    {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="flex justify-end pt-4">
            <button
              onClick={handleNext}
              disabled={selectedOption === null}
              className={`px-6 py-3 rounded-2xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                selectedOption === null
                  ? 'bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-600 cursor-not-allowed'
                  : 'bg-sky-600 text-white shadow-lg shadow-sky-600/20 hover:bg-sky-700'
              }`}
            >
              {currentIndex === questions.length - 1
                ? (isMr ? 'मूल्यांकन पूर्ण करा' : 'Finish Assessment')
                : (isMr ? 'पुढील प्रश्न' : 'Next Question')} <ArrowRight size={16} />
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm text-center space-y-6">
          <div className="w-20 h-20 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-full mx-auto flex items-center justify-center">
            <Award size={40} />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
              {isMr ? 'मूल्यांकन पूर्ण झाले!' : 'Assessment Complete!'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isMr
                ? `तुम्हाला ${questions.length} पैकी ${score} गुण मिळाले (${Math.round((score / questions.length) * 100)}%).`
                : `You scored ${score} out of ${questions.length} (${Math.round((score / questions.length) * 100)}%).`}
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 max-w-md mx-auto">
            {score >= questions.length * 0.7 ? (
              <p className="font-medium text-emerald-600 dark:text-emerald-400">
                {isMr
                  ? '🎉 उत्कृष्ट कामगिरी! तुमची प्रवीणता उच्च पातळीची आहे. दैनंदिन सातत्य कायम ठेवा.'
                  : '🎉 Outstanding performance! Your mastery level is high. Keep maintaining your daily streak.'}
              </p>
            ) : (
              <p className="font-medium text-amber-600 dark:text-amber-400">
                {isMr
                  ? '💡 चांगला प्रयत्न! कौशल्ये अधिक बळकट करण्यासाठी तुमचे दैनिक टास्क आणि पाथवे तपासा.'
                  : "💡 Good effort! Review your Today's Tasks and Learning Pathway to strengthen your skills."}
              </p>
            )}
          </div>

          <div className="flex justify-center gap-3 pt-2">
            <button
              onClick={handleStart}
              className="px-6 py-3 rounded-2xl bg-sky-600 text-white font-bold text-xs shadow-lg shadow-sky-600/20 hover:bg-sky-700 transition-all inline-flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw size={16} /> {isMr ? 'पुन्हा चाचणी द्या' : 'Start Reassessment'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
