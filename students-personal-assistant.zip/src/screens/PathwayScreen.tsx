import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Sparkles, Award, CheckCircle2, Clock3, AlertCircle, CheckCircle, BookOpen, FileText, Volume2, Video, Play, ChevronRight, X, Headphones, HelpCircle, ArrowRight } from 'lucide-react';
import { translations } from '../translations';

interface PathwayScreenProps {
  initialTab?: 'daily' | 'weekly' | 'monthly';
  onTabChange?: (tab: 'daily' | 'weekly' | 'monthly') => void;
  language?: 'en' | 'mr' | 'hi';
}

interface MonthlySkillItem {
  id: string;
  number: string;
  title: string;
  description: string;
  status: 'Completed' | 'Pending' | 'In Progress';
}

interface RoadmapDay {
  dayNum: number;
  title: string;
  status: 'completed' | 'current' | 'upcoming';
  topic: string;
}

interface CompletedDayDetail {
  dayNum: number;
  title: string;
  topic: string;
  completedDate: string;
  questionsSolved: number;
  totalQuestions: number;
  scorePercentage: number;
  summary: string;
  textNotes: string;
  audioDetails: {
    title: string;
    duration: string;
    description: string;
  };
  videoDetails: {
    title: string;
    duration: string;
    description: string;
    source: string;
  };
  tasksCompleted: string[];
}

export const PathwayScreen: React.FC<PathwayScreenProps> = ({ initialTab = 'daily', onTabChange, language = 'en' }) => {
  const t = translations[language];
  const [activeTab, setActiveTab] = useState<'daily' | 'weekly' | 'monthly'>(initialTab);
  const [selectedDayDetail, setSelectedDayDetail] = useState<CompletedDayDetail | null>(null);
  const [selectedMonthlySkillId, setSelectedMonthlySkillId] = useState<string | null>(null);

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const handleTabClick = (tab: 'daily' | 'weekly' | 'monthly') => {
    setActiveTab(tab);
    onTabChange?.(tab);
  };

  const monthlySkills: MonthlySkillItem[] = [
    {
      id: 'ms1',
      number: '1',
      title: 'Learn Python Basic',
      description: 'Variables, loops, functions, and fundamental syntax.',
      status: 'Completed',
    },
    {
      id: 'ms2',
      number: '2',
      title: 'Learn Computer Shortcut Keys',
      description: 'Essential keyboard shortcuts for fast navigation and productivity.',
      status: 'Completed',
    },
    {
      id: 'ms3',
      number: '3',
      title: 'Learn First Generation',
      description: 'History and architecture of vacuum tube computers (Day 3 currently active).',
      status: 'In Progress',
    },
    {
      id: 'ms4',
      number: '4',
      title: 'Learn Second Generation',
      description: 'Transistors and assembly language introduction.',
      status: 'Pending',
    },
    {
      id: 'ms5',
      number: '5',
      title: 'Learn Third Generation',
      description: 'Integrated circuits and operating system basics.',
      status: 'Pending',
    },
    {
      id: 'ms6',
      number: '6',
      title: 'Learn Fourth Generation',
      description: 'Microprocessors, VLSI, and modern computing revolution.',
      status: 'Pending',
    },
  ];

  const weeklyRoadmap: RoadmapDay[] = [
    { dayNum: 1, title: 'Day 1', status: 'completed', topic: 'Introduction to Vacuum Tubes & ENIAC' },
    { dayNum: 2, title: 'Day 2', status: 'completed', topic: 'Magnetic Drums & Punch Card Storage' },
    { dayNum: 3, title: 'Day 3', status: 'current', topic: 'First Gen Architecture & Limitations (Today)' },
    { dayNum: 4, title: 'Day 4', status: 'upcoming', topic: 'Machine Language & Binary Coding' },
    { dayNum: 5, title: 'Day 5', status: 'upcoming', topic: 'Vacuum Tube Reliability & Maintenance' },
    { dayNum: 6, title: 'Day 6', status: 'upcoming', topic: 'First Generation Summary & Quiz' },
  ];

  // Completed Monthly Skill Roadmap Data (Each with 6 completed days map + daily history)
  const completedSkillsWeekData: Record<string, {
    skillId: string;
    skillTitle: string;
    weekTitle: string;
    summary: string;
    completedDays: RoadmapDay[];
    daysHistory: Record<number, CompletedDayDetail>;
  }> = {
    ms1: {
      skillId: 'ms1',
      skillTitle: 'Skill 1: Learn Python Basic',
      weekTitle: 'Week 1 Roadmap: Python Programming Fundamentals (All 6 Days Completed)',
      summary: 'या आठवड्यातील सर्व ६ दिवस यशस्वीरित्या पूर्ण झाले आहेत. कोणत्याही दिवसावर टॅप करून त्याचे Questions, Audio, Video आणि Notes तपासू शकता.',
      completedDays: [
        { dayNum: 1, title: 'Day 1', status: 'completed', topic: 'Python Syntax, Variables & Data Types' },
        { dayNum: 2, title: 'Day 2', status: 'completed', topic: 'Conditional Statements (if-else, elif)' },
        { dayNum: 3, title: 'Day 3', status: 'completed', topic: 'Loops (for & while) and Iterations' },
        { dayNum: 4, title: 'Day 4', status: 'completed', topic: 'Functions, Parameters & Return Values' },
        { dayNum: 5, title: 'Day 5', status: 'completed', topic: 'Lists, Tuples & Dictionaries Data Structures' },
        { dayNum: 6, title: 'Day 6', status: 'completed', topic: 'Python Mini Project & Final Comprehensive Quiz' },
      ],
      daysHistory: {
        1: {
          dayNum: 1,
          title: 'Day 1: Python Syntax, Variables & Data Types',
          topic: 'Variables, Integers, Strings, Floats, Booleans & print() Function in Python',
          completedDate: 'Completed',
          questionsSolved: 40,
          totalQuestions: 40,
          scorePercentage: 100,
          summary: 'अभ्यास पूर्ण: Python व्हेरिएबल्स, डेटा टाईप्स आणि बेसिक सिन्टॅक्सचा संपूर्ण सराव करून ४० पैकी ४० प्रश्न १००% अचूक सोडवले.',
          textNotes: 'पायथॉनमध्ये व्हेरिएबल डिक्लेअर करण्यासाठी डेटा टाईप लिहिण्याची गरज नसते (Dynamically Typed). int, float, str, bool हे प्राथमिक डेटा प्रकार आहेत. print() आणि type() फंक्शन्सचा वापर समजून घेतला.',
          audioDetails: {
            title: 'Audio Lesson 1: Introduction to Python & Variable Concept',
            duration: '14 mins audio lecture',
            description: 'पायथॉनची सुरुवात कशी करावी, व्हेरिएबल्स कसे साठवले जातात आणि बेसिक सिन्टॅक्स मराठीत सोप्या भाषेत स्पष्ट केले आहे.',
          },
          videoDetails: {
            title: 'Video Class 1: Hands-on Python Setup & First Code',
            duration: '24 mins • 1080p HD',
            description: 'VS Code आणि IDLE मध्ये पायथॉन कोड कसा चालवायचा याचे थेट प्रात्यक्षिक.',
            source: 'Python Masterclass Academy',
          },
          tasksCompleted: [
            'अभ्यास: Python Basic Syntax & Variables Guide',
            'ऑडिओ व्याख्यान: Dynamically Typed Language चे महत्त्व',
            'व्हिडिओ लेक्चर: Practical Code Demonstration in Terminal',
            'सराव चाचणी: ४० पैकी ४० प्रश्न यशस्वीरित्या सोडवले',
          ],
        },
        2: {
          dayNum: 2,
          title: 'Day 2: Conditional Statements (if-else, elif)',
          topic: 'Decision Making in Python, Comparison Operators, Logical Operators & Indentation',
          completedDate: 'Completed',
          questionsSolved: 38,
          totalQuestions: 40,
          scorePercentage: 95,
          summary: 'अभ्यास पूर्ण: if-elif-else कंडिशन्स आणि इंडेंटेशनचे नियम शिकून ३८ प्रश्न यशस्वीरित्या सोडवले.',
          textNotes: 'पायथॉनमध्ये करली ब्रेसेस {} ऐवजी इंडेंटेशन (४ स्पेसेस) वापरले जाते. if, elif, else कीवर्ड्स द्वारे प्रोग्राम फ्लो नियंत्रित केला जातो.',
          audioDetails: {
            title: 'Audio Lesson 2: Logic Building with Conditions',
            duration: '12 mins audio session',
            description: 'कंडिशनल स्टेटमेंट्स आणि लॉजिकल ऑपरेटर्स (and, or, not) वरील ऑडिओ धडा.',
          },
          videoDetails: {
            title: 'Video Class 2: Decision Trees & If-Else in Python',
            duration: '20 mins • 1080p HD',
            description: 'रिअल-लाइफ उदाहरणे वापरून if-else कोड लिहिण्याचे प्रात्यक्षिक.',
            source: 'Python Logic Series',
          },
          tasksCompleted: [
            'अभ्यास: Indentation आणि Conditional Blocks',
            'ऑडिओ व्याख्यान: Nested If-Else समजून घेणे',
            'व्हिडिओ प्रात्यक्षिक: Voting Eligibility & Grading System Code',
            'सराव चाचणी: ४० पैकी ३८ प्रश्न पूर्ण',
          ],
        },
        3: {
          dayNum: 3,
          title: 'Day 3: Loops (for & while) and Iterations',
          topic: 'For Loops, While Loops, range() Function, Break & Continue Statements',
          completedDate: 'Completed',
          questionsSolved: 40,
          totalQuestions: 40,
          scorePercentage: 100,
          summary: 'अभ्यास पूर्ण: Loops आणि range() फंक्शनचा सखोल सराव करून सर्व ४० प्रश्नांची अचूक उत्तरे दिली.',
          textNotes: 'for loop हा सिक्वेन्सवर फिरण्यासाठी आणि while loop हा कंडिशन खरी असेपर्यंत चालवण्यासाठी वापरला जातो. break लूप थांबवतो आणि continue पुढील स्टेपवर जातो.',
          audioDetails: {
            title: 'Audio Lesson 3: Mastering Loops in Python',
            duration: '15 mins audio explanation',
            description: 'Infinite loop कसा टाळायचा आणि लूप ऑप्टिमायझेशन कसे करायचे याचे मार्गदर्शन.',
          },
          videoDetails: {
            title: 'Video Class 3: Loops & Nested Loops Explained Visually',
            duration: '22 mins • 1080p HD',
            description: 'Pattern printing आणि डेटा आयटम प्रिंटिंगचे सविस्तर व्हिज्युअल प्रात्यक्षिक.',
            source: 'Core Python Tutorials',
          },
          tasksCompleted: [
            'अभ्यास: For आणि While Loops चा फरक',
            'ऑडिओ व्याख्यान: break आणि continue चा योग्य वापर',
            'व्हिडिओ लेक्चर: Multiplication Table & Number Series',
            'सराव चाचणी: ४० पैकी ४० प्रश्न पूर्ण',
          ],
        },
        4: {
          dayNum: 4,
          title: 'Day 4: Functions, Parameters & Return Values',
          topic: 'def Keyword, Arguments, Default Parameters, Return Statement & Scope',
          completedDate: 'Completed',
          questionsSolved: 37,
          totalQuestions: 40,
          scorePercentage: 92,
          summary: 'अभ्यास पूर्ण: Functions तयार करणे, पॅरामीटर्स पास करणे आणि व्हॅल्यू रिटर्न करण्याचे तंत्र शिकून ३७ प्रश्न सोडवले.',
          textNotes: 'फंक्शन्स कोड पुन्हा वापरण्यायोग्य (reusable) बनवतात. def कीवर्डने फंक्शन तयार होते. return कीवर्ड रिझल्ट परत पाठवतो.',
          audioDetails: {
            title: 'Audio Lesson 4: Code Reusability with Python Functions',
            duration: '13 mins audio session',
            description: 'Global vs Local Variables आणि फंक्शन पॅरामीटर्सचे सुस्पष्ट ऑडिओ विश्लेषण.',
          },
          videoDetails: {
            title: 'Video Class 4: Writing Clean Modular Python Functions',
            duration: '25 mins • 1080p HD',
            description: 'कॅल्क्युलेटर आणि युटिलिटी फंक्शन्स तयार करण्याचा थेट कोडिंग वर्ग.',
            source: 'Python Pro Academy',
          },
          tasksCompleted: [
            'अभ्यास: Modular Programming संकल्पना',
            'ऑडिओ व्याख्यान: Function Call आणि Return Mechanism',
            'व्हिडिओ प्रात्यक्षिक: Calculator Functions Live Coding',
            'सराव चाचणी: ४० पैकी ३७ प्रश्न पूर्ण',
          ],
        },
        5: {
          dayNum: 5,
          title: 'Day 5: Lists, Tuples & Dictionaries Data Structures',
          topic: 'List Operations (append, remove, sort), Immutable Tuples, Key-Value Dictionaries',
          completedDate: 'Completed',
          questionsSolved: 39,
          totalQuestions: 40,
          scorePercentage: 98,
          summary: 'अभ्यास पूर्ण: Python डेटा स्ट्रक्चर्स (Lists, Tuples, Dictionaries) शिकून ३९ प्रश्न अचूक सोडवले.',
          textNotes: 'List ही म्यूटेबल (बदलण्यायोग्य) असते, तर Tuple इम्यूटेबल असते. Dictionary मध्ये डेटा key:value पेअर्समध्ये साठवला जातो.',
          audioDetails: {
            title: 'Audio Lesson 5: Python Data Collections Deep Dive',
            duration: '16 mins audio lecture',
            description: 'कधी List वापरावी आणि कधी Dictionary वापरावी यावरील तुलनात्मक ऑडिओ विश्लेषण.',
          },
          videoDetails: {
            title: 'Video Class 5: Working with Lists & Dictionaries in Real Projects',
            duration: '28 mins • 1080p HD',
            description: 'डेटा मॅनिप्युलेशन, इंडेक्सिंग आणि स्लाइसिंगचे प्रात्यक्षिक.',
            source: 'Modern Python Labs',
          },
          tasksCompleted: [
            'अभ्यास: Data Structures Cheat Sheet वाचन',
            'ऑडिओ व्याख्यान: Mutability vs Immutability',
            'व्हिडिओ प्रात्यक्षिक: Student Database using Dict & List',
            'सराव चाचणी: ४० पैकी ३९ प्रश्न सोडवले',
          ],
        },
        6: {
          dayNum: 6,
          title: 'Day 6: Python Mini Project & Final Comprehensive Quiz',
          topic: 'Full Revision, Mini Console App (Contact Book), Exception Handling & Certification Quiz',
          completedDate: 'Completed',
          questionsSolved: 40,
          totalQuestions: 40,
          scorePercentage: 100,
          summary: 'अभ्यास पूर्ण: संपूर्ण आठवड्याची उजळणी, मिनी प्रोजेक्ट तयार करणे आणि अंतिम चाचणीत ४० पैकी ४० गुण मिळवून कौशल्य पूर्ण केले.',
          textNotes: 'या अंतिम दिवशी शिकलेल्या सर्व घटकांचा वापर करून एक कन्सोल अप्लिकेशन बनवले. try-except द्वारे बेसिक एरर हँडलिंग समजून घेतले.',
          audioDetails: {
            title: 'Audio Lesson 6: Weekly Summary & Real-world Best Practices',
            duration: '15 mins podcast',
            description: 'Python बेसिक कौशल्याचा प्रत्यक्ष कामात कसा उपयोग होतो याचे अंतिम पुनरावलोकन.',
          },
          videoDetails: {
            title: 'Video Class 6: Building a Mini Python App from Scratch',
            duration: '32 mins • 1080p HD',
            description: 'संपूर्ण प्रोजेक्ट कोडिंग आणि अंतिम टेस्ट वॉकथ्रू.',
            source: 'Python Capstone Studio',
          },
          tasksCompleted: [
            'प्रकल्प: Mini Contact Book Console Project',
            'ऑडिओ व्याख्यान: Code Debugging व Best Practices',
            'व्हिडिओ प्रात्यक्षिक: Project Deployment & Code Review',
            'अंतिम परीक्षा: ४० पैकी ४० प्रश्न पूर्ण (१००% परिपूर्ण निकाल)',
          ],
        },
      },
    },
    ms2: {
      skillId: 'ms2',
      skillTitle: 'Skill 2: Learn Computer Shortcut Keys',
      weekTitle: 'Week 2 Roadmap: Master Computer Shortcut Keys (All 6 Days Completed)',
      summary: 'या आठवड्यातील सर्व ६ दिवस यशस्वीरित्या पूर्ण झाले आहेत. कोणत्याही दिवसावर टॅप करून त्याचे Questions, Audio, Video आणि Notes तपासू शकता.',
      completedDays: [
        { dayNum: 1, title: 'Day 1', status: 'completed', topic: 'Windows Navigation & System Shortcuts (Win+D, Win+E, Alt+Tab)' },
        { dayNum: 2, title: 'Day 2', status: 'completed', topic: 'Text Editing & Clipboard Mastery (Ctrl+C, V, X, Z, Y, A)' },
        { dayNum: 3, title: 'Day 3', status: 'completed', topic: 'Web Browser Power Shortcuts (Ctrl+T, W, Shift+T, Ctrl+L)' },
        { dayNum: 4, title: 'Day 4', status: 'completed', topic: 'MS Office & Document Formatting Shortcuts (Ctrl+B, I, U, F)' },
        { dayNum: 5, title: 'Day 5', status: 'completed', topic: 'File Explorer & Window Management (Win+Left/Right, F2, Del)' },
        { dayNum: 6, title: 'Day 6', status: 'completed', topic: 'Speed Testing, Shortcut Drill & Final Exam' },
      ],
      daysHistory: {
        1: {
          dayNum: 1,
          title: 'Day 1: Windows Navigation & System Shortcuts',
          topic: 'Windows Key Combinations, Fast App Switching, Task Manager & Lock Screen',
          completedDate: 'Completed',
          questionsSolved: 40,
          totalQuestions: 40,
          scorePercentage: 100,
          summary: 'अभ्यास पूर्ण: Windows की शॉर्टकट्स (Win+D, Win+E, Win+R, Alt+Tab) चा वेगवान वापर शिकून ४० प्रश्न सोडवले.',
          textNotes: 'Win+D ने थेट डेस्कटॉप उघडतो, Win+E ने फाईल एक्सप्लोरर उघडतो. Ctrl+Shift+Esc ने थेट टास्क मॅनेजर उघडता येतो.',
          audioDetails: {
            title: 'Audio Lesson 1: Essential Windows Shortcuts for Everyday Speed',
            duration: '11 mins audio guide',
            description: 'माऊस न वापरता संगणकावर वेगवान काम कसे करावे याचे सविस्तर ऑडिओ स्पष्टीकरण.',
          },
          videoDetails: {
            title: 'Video Class 1: Windows Superuser Shortcuts in Action',
            duration: '19 mins • 1080p HD',
            description: 'स्क्रीन रेकॉर्डिंगसह प्रत्येक शॉर्टकट कीचे थेट परिणाम आणि वापर.',
            source: 'Productivity Hacks Channel',
          },
          tasksCompleted: [
            'अभ्यास: Windows Hotkeys Reference Sheet',
            'ऑडिओ धडा: Window Snapping आणि Virtual Desktops',
            'व्हिडिओ प्रात्यक्षिक: Hands-on Keyboard Navigation',
            'सराव चाचणी: ४० पैकी ४० प्रश्न सोडवले',
          ],
        },
        2: {
          dayNum: 2,
          title: 'Day 2: Text Editing & Clipboard Mastery',
          topic: 'Ctrl+C, Ctrl+V, Ctrl+X, Ctrl+Z, Ctrl+Y, Ctrl+Backspace & Clipboard History (Win+V)',
          completedDate: 'Completed',
          questionsSolved: 40,
          totalQuestions: 40,
          scorePercentage: 100,
          summary: 'अभ्यास पूर्ण: टेक्स्ट एडिटिंग, अंडू/रीडू आणि क्लिपबोर्ड हिस्ट्री (Win+V) चा सराव करून ४० प्रश्न १००% अचूक सोडवले.',
          textNotes: 'Win+V ने Windows Clipboard History उघडते, ज्यामध्ये कॉपी केलेल्या अनेक गोष्टी सुरक्षित राहतात. Ctrl+Backspace ने संपूर्ण शब्द एकदम डिलीट होतो.',
          audioDetails: {
            title: 'Audio Lesson 2: Lightning-fast Text Selection & Editing',
            duration: '10 mins audio breakdown',
            description: 'Ctrl+Shift+बाण आणि Shift+Home/End वापरून सुपरफास्ट टेक्स्ट सिलेक्ट करण्याचे ऑडिओ तंत्र.',
          },
          videoDetails: {
            title: 'Video Class 2: Never Touch the Mouse While Typing',
            duration: '18 mins • 1080p HD',
            description: 'कीबोर्डवर दोन्ही हात ठेवून वेगाने ड्राफ्टिंग करण्याचे प्रात्यक्षिक.',
            source: 'Keyboard Mastery Studio',
          },
          tasksCompleted: [
            'अभ्यास: Editing Shortcuts Cheatsheet',
            'ऑडिओ धडा: Clipboard History चे छुपे फायदे',
            'व्हिडिओ प्रात्यक्षिक: Real-time Word Editing Practice',
            'सराव चाचणी: ४० पैकी ४० प्रश्न पूर्ण',
          ],
        },
        3: {
          dayNum: 3,
          title: 'Day 3: Web Browser Power Shortcuts',
          topic: 'Tabs Control (Ctrl+T, W, Shift+T), Address Bar (Ctrl+L), History (Ctrl+H), Downloads (Ctrl+J)',
          completedDate: 'Completed',
          questionsSolved: 39,
          totalQuestions: 40,
          scorePercentage: 98,
          summary: 'अभ्यास पूर्ण: Chrome/Edge ब्राउझरचे सर्व महत्त्वाचे टॅब आणि नेव्हिगेशन शॉर्टकट्स शिकून ३९ प्रश्न सोडवले.',
          textNotes: 'Ctrl+Shift+T चुकून बंद झालेला टॅब परत उघडतो. Ctrl+L लगेच सर्च बार/URL बार सिलेक्ट करतो. Ctrl+Tab टॅब्स दरम्यान पुढे जातो.',
          audioDetails: {
            title: 'Audio Lesson 3: Speed Surfing - Browser Shortcuts Explained',
            duration: '12 mins podcast',
            description: 'इंटरनेटवर संशोधन करताना वेळेची ५०% बचत करणारे ब्राउझर शॉर्टकट्स.',
          },
          videoDetails: {
            title: 'Video Class 3: Browsing Like a Pro Developer',
            duration: '21 mins • 1080p HD',
            description: 'क्रोम डेव्हलपर टूल्स, बुकमार्क्स आणि टॅब ऑर्गनायझेशन शॉर्टकट्स.',
            source: 'Web Navigation Academy',
          },
          tasksCompleted: [
            'अभ्यास: Browser Shortcuts Quick Guide',
            'ऑडिओ धडा: बंद झालेले टॅब्स रिकव्हर करण्याचे रहस्य',
            'व्हिडिओ प्रात्यक्षिक: Live Research Navigation without Mouse',
            'सराव चाचणी: ४० पैकी ३९ प्रश्न पूर्ण',
          ],
        },
        4: {
          dayNum: 4,
          title: 'Day 4: MS Office & Document Formatting Shortcuts',
          topic: 'Formatting (Ctrl+B, I, U), Alignment (Ctrl+L, E, R, J), Find & Replace (Ctrl+F, H)',
          completedDate: 'Completed',
          questionsSolved: 40,
          totalQuestions: 40,
          scorePercentage: 100,
          summary: 'अभ्यास पूर्ण: Word व Excel मधील फॉन्ट फॉरमॅटिंग आणि फाईंड-रिप्लेस शॉर्टकट्स पूर्ण करून १००% गुण मिळवले.',
          textNotes: 'Ctrl+H फाईंड आणि रिप्लेस डायलॉग उघडतो. Ctrl+Enter लगेच नवीन पेज सुरू करतो (Page Break). Ctrl+S डॉक्युमेंट सेव्ह करतो.',
          audioDetails: {
            title: 'Audio Lesson 4: Word & Excel Speed Formats',
            duration: '13 mins audio lecture',
            description: 'ऑफिस कामांमध्ये अहवाल आणि स्प्रेडशीट पटकन तयार करण्याचे कीबोर्ड शॉर्टकट्स.',
          },
          videoDetails: {
            title: 'Video Class 4: Formatting Long Documents in Minutes',
            duration: '23 mins • 1080p HD',
            description: 'Word डॉक्युमेंट फॉरमॅटिंगचे लाइव्ह प्रात्यक्षिक.',
            source: 'Office Productivity Hub',
          },
          tasksCompleted: [
            'अभ्यास: MS Office Shortcuts Reference',
            'ऑडिओ व्याख्यान: Alignment व Formatting Hotkeys',
            'व्हिडिओ प्रात्यक्षिक: Document Layout Styling',
            'सराव चाचणी: ४० पैकी ४० प्रश्न पूर्ण',
          ],
        },
        5: {
          dayNum: 5,
          title: 'Day 5: File Explorer & Window Management',
          topic: 'File Renaming (F2), Permanent Delete (Shift+Del), Properties (Alt+Enter), Split Screen Snap (Win+Arrows)',
          completedDate: 'Completed',
          questionsSolved: 38,
          totalQuestions: 40,
          scorePercentage: 95,
          summary: 'अभ्यास पूर्ण: फाईल मॅनेजमेंट आणि स्क्रीन स्प्लिटिंग शॉर्टकट्स शिकून ३८ प्रश्न सोडवले.',
          textNotes: 'F2 की सिलेक्ट केलेल्या फाईलचे नाव बदलण्यासाठी (Rename) असते. Shift+Delete फाईल कायमस्वरूपी रीसायकल बिनशिवाय नष्ट करतो. Win+बाण स्क्रीन अर्धी करतात.',
          audioDetails: {
            title: 'Audio Lesson 5: Effortless File Organization',
            duration: '11 mins audio guide',
            description: 'मोठ्या फाइल्स आणि फोल्डर्सचे व्यवस्थापन एका सेकंदात कसे करावे.',
          },
          videoDetails: {
            title: 'Video Class 5: Window Split & Multi-tasking Mastery',
            duration: '17 mins • 1080p HD',
            description: 'दोन मॉनिटर किंवा स्प्लिट स्क्रीनवर मल्टीटास्किंगचे प्रात्यक्षिक.',
            source: 'System Masters Series',
          },
          tasksCompleted: [
            'अभ्यास: Explorer & Hotkeys Guide',
            'ऑडिओ धडा: Shift+Delete चा सुरक्षित वापर',
            'व्हिडिओ प्रात्यक्षिक: Split Screen Workflow Demonstration',
            'सराव चाचणी: ४० पैकी ३८ प्रश्न पूर्ण',
          ],
        },
        6: {
          dayNum: 6,
          title: 'Day 6: Speed Testing, Shortcut Drill & Final Exam',
          topic: 'Speed Drill, Mixed Key Combinations, Real-time Simulation & Final Shortcut Certification Quiz',
          completedDate: 'Completed',
          questionsSolved: 40,
          totalQuestions: 40,
          scorePercentage: 100,
          summary: 'अभ्यास पूर्ण: सर्व शॉर्टकट्सचा अंतिम स्पीड टेस्ट ड्रिल आणि ४० पैकी ४० गुणांसह अंतिम प्रमाणपत्र चाचणी उत्तीर्ण.',
          textNotes: 'सर्व प्रमुख शॉर्टकट कीजची एकत्रित उजळणी पूर्ण झाली. कॉम्प्युटर वापरण्याचा वेग तिप्पट झाला.',
          audioDetails: {
            title: 'Audio Lesson 6: Final Review & Lifetime Productivity Tips',
            duration: '14 mins audio recap',
            description: 'शॉर्टकट कीज कायम लक्षात ठेवण्यासाठी मसल मेमरी कशी तयार करावी याचे मार्गदर्शन.',
          },
          videoDetails: {
            title: 'Video Class 6: The Ultimate Speed Run Challenge',
            duration: '26 mins • 1080p HD',
            description: 'माऊसशिवाय सर्व कार्ये २ मिनिटांत पूर्ण करण्याचा स्पीड रन डेमो.',
            source: 'Productivity Labs',
          },
          tasksCompleted: [
            'अभ्यास: Master Shortcut Key Compendium',
            'ऑडिओ व्याख्यान: Muscle Memory Building Strategies',
            'व्हिडिओ प्रात्यक्षिक: The 2-Minute Mouse-free Challenge',
            'अंतिम चाचणी: ४० पैकी ४० प्रश्न पूर्ण (१००% अचूक निकाल)',
          ],
        },
      },
    },
  };

  const completedDaysData: Record<number, CompletedDayDetail> = {
    1: {
      dayNum: 1,
      title: 'Day 1: Introduction to Vacuum Tubes & ENIAC',
      topic: 'Introduction to Vacuum Tubes, Electronic Numerical Integrator, and Early Thermionic Valves',
      completedDate: 'Monday (Finished)',
      questionsSolved: 35,
      totalQuestions: 40,
      scorePercentage: 88,
      summary: 'अभ्यास पूर्ण: Day 1 मध्ये Vacuum Tube तंत्रज्ञान, ENIAC कॉम्प्युटरची रचना, आणि 1940 च्या दशकातील पहिल्या इलेक्ट्रॉनिक कॉम्प्युटरची मूळ संकल्पना शिकून 35 प्रश्न सोडवले गेले.',
      textNotes: 'व्हॅक्यूम ट्यूब (Thermionic Valves) हे पहिल्या पिढीच्या कॉम्प्युटरमध्ये विद्युत सिग्नल नियंत्रित करण्यासाठी वापरले गेले. ENIAC (1945) मध्ये १८,००० हून अधिक व्हॅक्यूम ट्यूब वापरण्यात आल्या होत्या, ज्या खूप उष्णता निर्माण करत असत.',
      audioDetails: {
        title: 'Day 1 Audio Breakdown: The Rise of ENIAC & Vacuum Tubes',
        duration: '12 mins audio session',
        description: 'तज्ज्ञ ऑडिओ पॉडकास्ट ज्यामध्ये व्हॅक्यूम ट्यूबचे कार्य, स्विचिंग स्पीड आणि ENIAC चा इतिहास मराठी/इंग्रजीमध्ये समजावला आहे.',
      },
      videoDetails: {
        title: 'Day 1 Masterclass Video: How First Generation Computers Worked',
        duration: '22 mins • 1080p HD',
        description: 'अॅनिमेटेड 3D व्हिडिओ ज्यामध्ये ENIAC चे हार्डवेअर, व्हॅक्यूम ट्यूबचे सर्किट आणि प्रत्यक्ष गणना प्रक्रिया दाखवली आहे.',
        source: 'AI Academy Lecture Series',
      },
      tasksCompleted: [
        'अभ्यास: व्हॅक्यूम ट्यूबची रचना आणि मूलभूत संकल्पना (Text Guide)',
        'ऑडिओ व्याख्यान: ENIAC ची पार्श्वभूमी आणि मर्यादा',
        'व्हिडिओ लेक्चर: First Gen Architecture Walkthrough',
        'सराव चाचणी: 40 पैकी 35 बहुपर्यायी प्रश्न (MCQs) यशस्वीरित्या सोडवले',
      ],
    },
    2: {
      dayNum: 2,
      title: 'Day 2: Magnetic Drums & Punch Card Storage',
      topic: 'Magnetic Drum Memory, Punch Cards, Paper Tape, and Primary Storage Mechanisms',
      completedDate: 'Tuesday (Finished)',
      questionsSolved: 40,
      totalQuestions: 40,
      scorePercentage: 100,
      summary: 'अभ्यास पूर्ण: Day 2 मध्ये मॅग्नेटिक ड्रम मेमरी आणि पंच कार्ड्सद्वारे डेटा इनपुट/स्टोरेज कसा होत होता हे शिकून १००% गुणांसह सर्व ४० प्रश्न अचूक सोडवले.',
      textNotes: 'मॅग्नेटिक ड्रम हे पहिल्या पिढीच्या संगणकांमधील मुख्य मेमरी तंत्रज्ञान होते. यामध्ये फिरणाऱ्या धातूच्या ड्रमवर चुंबकीय कोटिंगद्वारे डेटा साठवला जात असे. पंच कार्ड्सच्या माध्यमातून इनपुट दिले जात होते.',
      audioDetails: {
        title: 'Day 2 Audio Session: Storage Revolution of the 1950s',
        duration: '10 mins audio explanation',
        description: 'पंच कार्ड्स आणि ड्रम मेमरीच्या कार्यपद्धतीवरील सुस्पष्ट ऑडिओ ऑडिओ विश्लेषण.',
      },
      videoDetails: {
        title: 'Day 2 Video Demonstration: Magnetic Drum & Punch Card Systems',
        duration: '18 mins • 1080p HD',
        description: 'पंच कार्ड रीडर आणि ड्रम स्टोरेजचे प्रात्यक्षिक दाखवणारा सविस्तर व्हिडिओ ट्यूटोरियल.',
        source: 'Computer History Archives',
      },
      tasksCompleted: [
        'अभ्यास: पंच कार्ड आणि मॅग्नेटिक ड्रम नोट्स वाचन',
        'ऑडिओ व्याख्यान: डेटा स्टोरेज आणि सायकल टाइम',
        'व्हिडिओ व्याख्यान: प्रात्यक्षिक व हार्डवेअर संरचना',
        'सराव चाचणी: ४० पैकी ४० प्रश्न पूर्ण (१००% अचूकता)',
      ],
    },
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Completed':
        return <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center gap-1"><CheckCircle2 size={11} /> Completed</span>;
      case 'In Progress':
        return <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400 flex items-center gap-1"><Clock3 size={11} /> In Progress</span>;
      case 'Pending':
        return <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 flex items-center gap-1"><AlertCircle size={11} /> Pending</span>;
      default:
        return <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">Upcoming</span>;
    }
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in max-w-2xl mx-auto">
      {/* Horizontal Row for Daily, Weekly, Monthly */}
      <div className="grid grid-cols-3 gap-1.5 p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl">
        <button
          onClick={() => handleTabClick('daily')}
          className={`flex items-center justify-center gap-1.5 py-3 px-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'daily'
              ? 'bg-white dark:bg-slate-900 text-sky-600 dark:text-sky-400 shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Calendar size={15} /> {t.daily}
        </button>

        <button
          onClick={() => handleTabClick('weekly')}
          className={`flex items-center justify-center gap-1.5 py-3 px-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'weekly'
              ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Clock size={15} /> {t.weekly}
        </button>

        <button
          onClick={() => handleTabClick('monthly')}
          className={`flex items-center justify-center gap-1.5 py-3 px-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'monthly'
              ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Sparkles size={15} /> {t.monthly}
        </button>
      </div>

      {/* Content screen displayed based on selected tab */}
      <div className="space-y-3 animate-in fade-in">
        {activeTab === 'daily' && (
          <div className="space-y-4">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-sky-600 dark:text-sky-400">Daily Learning • Day 3 of 6 (Pending Skill)</span>
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white mt-0.5">Skill 3: Learn First Generation Computers</h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed pt-1 border-t border-slate-100 dark:border-slate-800">
                <b>First Generation (1940-1956):</b> Vacuum tubes for circuitry, magnetic drums for memory, massive room-sized footprint, and reliance on machine language. This skill is currently pending in your weekly roadmap.
              </p>
            </div>

            <div className="space-y-2.5">
              <h3 className="font-bold text-slate-900 dark:text-white text-xs px-1">How to Learn This Skill (Text, Audio & Video)</h3>

              <div className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400">
                    <FileText size={16} />
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-slate-900 dark:text-white">Text Notes & Documentation</h4>
                    <p className="text-[10px] text-slate-500">Read detailed architecture notes</p>
                  </div>
                </div>
                <span className="text-[10px] font-semibold text-sky-600 bg-sky-50 dark:bg-sky-950 px-2.5 py-1 rounded-lg">Read</span>
              </div>

              <div className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                    <Volume2 size={16} />
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-slate-900 dark:text-white">Audio Podcast & Explanation</h4>
                    <p className="text-[10px] text-slate-500">Listen to 10-minute audio breakdown</p>
                  </div>
                </div>
                <span className="text-[10px] font-semibold text-indigo-600 bg-indigo-50 dark:bg-indigo-950 px-2.5 py-1 rounded-lg flex items-center gap-1"><Play size={10} fill="currentColor" /> Listen</span>
              </div>

              <div className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400">
                    <Video size={16} />
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-slate-900 dark:text-white">Video Lecture & Animation</h4>
                    <p className="text-[10px] text-slate-500">Watch animated video walkthrough</p>
                  </div>
                </div>
                <span className="text-[10px] font-semibold text-amber-600 bg-amber-50 dark:bg-amber-950 px-2.5 py-1 rounded-lg flex items-center gap-1"><Play size={10} fill="currentColor" /> Watch</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'weekly' && (
          <div className="space-y-4">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">Weekly Skill Roadmap</span>
                <h2 className="font-extrabold text-base text-slate-900 dark:text-white mt-0.5">Skill 3: Learn First Generation (6-Day Roadmap)</h2>
              </div>
              <div className="p-2.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                <Clock size={22} />
              </div>
            </div>

            <div className="space-y-2.5">
              {weeklyRoadmap.map(day => {
                const isCompleted = day.status === 'completed';
                const hasDetails = Boolean(completedDaysData[day.dayNum]);

                return (
                  <div
                    key={day.dayNum}
                    onClick={() => {
                      if (isCompleted && hasDetails) {
                        setSelectedDayDetail(completedDaysData[day.dayNum]);
                      } else if (day.status === 'current') {
                        handleTabClick('daily');
                      }
                    }}
                    role={isCompleted || day.status === 'current' ? 'button' : undefined}
                    tabIndex={isCompleted || day.status === 'current' ? 0 : undefined}
                    className={`rounded-2xl p-4 border flex items-center justify-between gap-3 shadow-sm transition-all ${
                      isCompleted
                        ? 'bg-emerald-50/20 dark:bg-emerald-950/10 border-emerald-200 dark:border-emerald-900/50 hover:bg-emerald-50/40 hover:border-emerald-300 dark:hover:border-emerald-700 cursor-pointer active:scale-[0.99]'
                        : day.status === 'current'
                        ? 'bg-sky-50 dark:bg-sky-950/40 border-sky-300 dark:border-sky-800 cursor-pointer hover:bg-sky-100/50 active:scale-[0.99]'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-80'
                    }`}
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className={`w-8 h-8 rounded-xl font-extrabold text-xs flex items-center justify-center shrink-0 ${
                        isCompleted
                          ? 'bg-emerald-600 text-white shadow-sm'
                          : day.status === 'current'
                          ? 'bg-sky-600 text-white shadow-md animate-pulse'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}>
                        {day.dayNum}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate">{day.title}</h3>
                          {day.status === 'current' && (
                            <span className="text-[9px] font-bold bg-sky-600 text-white px-2 py-0.5 rounded-full">Today</span>
                          )}
                          {isCompleted && (
                            <span className="text-[9px] font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-full flex items-center gap-1">
                              <CheckCircle2 size={10} /> Tap for Daily Task
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">{day.topic}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`text-[10px] font-semibold px-2.5 py-1 rounded-lg shrink-0 ${
                        isCompleted
                          ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950'
                          : day.status === 'current'
                          ? 'text-sky-600 bg-sky-50 dark:bg-sky-950'
                          : 'text-slate-400 bg-slate-100 dark:bg-slate-800'
                      }`}>
                        {isCompleted ? 'Completed (Tap)' : day.status === 'current' ? 'In Progress (Day 3)' : 'Upcoming'}
                      </span>
                      {isCompleted && (
                        <ChevronRight size={16} className="text-emerald-500 shrink-0" />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'monthly' && (
          <div className="space-y-4">
            {/* If a completed monthly skill is selected, show its full 6-day weekly roadmap like current week */}
            {selectedMonthlySkillId && completedSkillsWeekData[selectedMonthlySkillId] ? (
              <div className="space-y-4 animate-in fade-in">
                {/* Back button to monthly list */}
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => setSelectedMonthlySkillId(null)}
                    className="flex items-center gap-2 text-xs font-bold text-amber-600 dark:text-amber-400 hover:text-amber-700 bg-amber-50 dark:bg-amber-950/70 border border-amber-200 dark:border-amber-900/50 px-3.5 py-2 rounded-xl transition-all shadow-sm"
                  >
                    ← Back to Monthly Skills
                  </button>
                  <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-900/40 flex items-center gap-1">
                    <CheckCircle2 size={12} /> 100% Completed Week
                  </span>
                </div>

                {/* Week Header Banner */}
                <div className="bg-gradient-to-br from-white to-amber-50/40 dark:from-slate-900 dark:to-amber-950/20 rounded-3xl p-5 border border-amber-200 dark:border-amber-900/40 shadow-sm space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                      {completedSkillsWeekData[selectedMonthlySkillId].skillTitle}
                    </span>
                    <span className="text-[10px] font-bold bg-amber-500 text-white px-2.5 py-0.5 rounded-full shadow-sm">
                      6 of 6 Days Finished
                    </span>
                  </div>
                  <h2 className="font-extrabold text-base text-slate-900 dark:text-white">
                    {completedSkillsWeekData[selectedMonthlySkillId].weekTitle}
                  </h2>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800/80 pt-2">
                    {completedSkillsWeekData[selectedMonthlySkillId].summary}
                  </p>
                </div>

                {/* 6 Days Roadmap - exactly like Weekly tab, all completed and clickable */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between px-1">
                    <h3 className="font-bold text-slate-900 dark:text-white text-xs">
                      6 Days Pathway (Tap any day to see Daily Task History)
                    </h3>
                    <span className="text-[10px] text-slate-400 font-medium">All 6 days completed</span>
                  </div>

                  {completedSkillsWeekData[selectedMonthlySkillId].completedDays.map(day => {
                    const dayHistory = completedSkillsWeekData[selectedMonthlySkillId]?.daysHistory[day.dayNum];

                    return (
                      <div
                        key={day.dayNum}
                        onClick={() => {
                          if (dayHistory) {
                            setSelectedDayDetail(dayHistory);
                          }
                        }}
                        className="rounded-2xl p-4 border flex items-center justify-between gap-3 shadow-sm bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 cursor-pointer hover:border-emerald-300 dark:hover:border-emerald-700 hover:shadow-md transition-all active:scale-[0.99] group"
                      >
                        <div className="flex items-center gap-3.5 min-w-0">
                          <div className="w-9 h-9 rounded-xl font-bold text-xs flex items-center justify-center shrink-0 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 group-hover:scale-105 transition-transform">
                            {day.dayNum}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate">{day.title}</h3>
                              <span className="text-[9px] font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-full flex items-center gap-1">
                                <CheckCircle2 size={10} /> Tap for Daily Task History
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">{day.topic}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-[10px] font-semibold px-2.5 py-1 rounded-lg shrink-0 text-emerald-600 bg-emerald-50 dark:bg-emerald-950 border border-emerald-100 dark:border-emerald-900/30">
                            Completed (Tap)
                          </span>
                          <ChevronRight size={16} className="text-emerald-500 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              /* Default Monthly Skills List */
              <>
                <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">Monthly Skills Roadmap</span>
                    <h2 className="font-extrabold text-base text-slate-900 dark:text-white mt-0.5">Essential Computer & Programming Skills</h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">पूर्ण झालेल्या कौशल्यावर टॅप करा आणि त्याचा ६ दिवसांचा Weekly Roadmap व Daily Task History पाहा.</p>
                  </div>
                  <div className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 shrink-0">
                    <Award size={22} />
                  </div>
                </div>

                <div className="space-y-2.5">
                  {monthlySkills.map(skill => {
                    const isSkillCompleted = skill.status === 'Completed';
                    const isSkillInProgress = skill.status === 'In Progress';
                    const hasWeeklyData = Boolean(completedSkillsWeekData[skill.id]);

                    return (
                      <div
                        key={skill.id}
                        onClick={() => {
                          if (isSkillCompleted && hasWeeklyData) {
                            setSelectedMonthlySkillId(skill.id);
                          }
                        }}
                        className={`bg-white dark:bg-slate-900 rounded-2xl p-4 border flex items-center gap-4 shadow-sm transition-all ${
                          isSkillCompleted && hasWeeklyData
                            ? 'border-emerald-200 dark:border-emerald-900/40 cursor-pointer hover:border-amber-400 dark:hover:border-amber-600 hover:shadow-md active:scale-[0.99] group'
                            : isSkillInProgress
                            ? 'border-sky-200 dark:border-sky-900/50 bg-sky-50/20 dark:bg-sky-950/10'
                            : 'border-slate-200 dark:border-slate-800 opacity-75'
                        }`}
                      >
                        <div className={`w-8 h-8 rounded-xl font-extrabold text-xs flex items-center justify-center shrink-0 ${
                          isSkillCompleted
                            ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400'
                            : isSkillInProgress
                            ? 'bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400 ring-2 ring-sky-400/40'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                        }`}>
                          {skill.number}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate">
                              {skill.title}
                            </h3>
                            {isSkillCompleted ? (
                              <span className="text-[9px] font-bold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 px-2 py-0.5 rounded-full flex items-center gap-1">
                                <Sparkles size={10} /> Tap for Weekly Roadmap
                              </span>
                            ) : isSkillInProgress ? (
                              <span className="text-[9px] font-bold bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 px-2 py-0.5 rounded-full">
                                Currently Active
                              </span>
                            ) : (
                              <span className="text-[9px] font-medium text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full">
                                Incomplete
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">{skill.description}</p>
                        </div>
                        <div className="shrink-0 flex items-center gap-2">
                          {getStatusBadge(skill.status)}
                          {isSkillCompleted && (
                            <ChevronRight size={16} className="text-amber-500 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* Completed Day Task Details Modal (Daily Task Jasach Open Hoto Tasach Pan History) */}
      {selectedDayDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 relative animate-in zoom-in-95 space-y-5 my-8">
            {/* Top Close Button */}
            <button
              onClick={() => setSelectedDayDetail(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Close details"
            >
              <X size={20} />
            </button>

            {/* Header info */}
            <div className="flex items-start gap-3 pr-8">
              <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 shrink-0">
                <CheckCircle2 size={24} />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-full">
                    Day Completed Task History
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium">
                    {selectedDayDetail.completedDate}
                  </span>
                </div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white mt-1 leading-snug">
                  {selectedDayDetail.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {selectedDayDetail.topic}
                </p>
              </div>
            </div>

            {/* Questions Solved Card (kiti questions complete kelet te) */}
            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/30 p-4 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                    <HelpCircle size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-emerald-950 dark:text-emerald-200">
                      Questions Solved on This Day
                    </h4>
                    <p className="text-[11px] text-emerald-800/80 dark:text-emerald-400">
                      या दिवशी सोडवलेले प्रश्न आणि अचूकता
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-base font-extrabold text-emerald-700 dark:text-emerald-300">
                    {selectedDayDetail.questionsSolved} / {selectedDayDetail.totalQuestions}
                  </span>
                  <span className="text-[10px] font-bold block text-emerald-600 dark:text-emerald-400">
                    ({selectedDayDetail.scorePercentage}% Score)
                  </span>
                </div>
              </div>

              {/* Progress Bar for Questions */}
              <div className="w-full bg-emerald-200/60 dark:bg-emerald-900/50 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                  style={{ width: `${selectedDayDetail.scorePercentage}%` }}
                />
              </div>

              <p className="text-xs text-emerald-900 dark:text-emerald-200 leading-relaxed pt-1">
                {selectedDayDetail.summary}
              </p>
            </div>

            {/* Short Study Details & Text Notes */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-sky-600 dark:text-sky-400">
                <FileText size={16} />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
                  Study Material & Text Notes Summary
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {selectedDayDetail.textNotes}
              </p>
            </div>

            {/* Video Details (Video konta hota) */}
            <div className="bg-amber-50/60 dark:bg-amber-950/30 p-4 rounded-2xl border border-amber-200 dark:border-amber-900/50 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400">
                  <Video size={16} />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900 dark:text-amber-200">
                    Video Lecture Watched
                  </h4>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300">
                  {selectedDayDetail.videoDetails.duration}
                </span>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-amber-100 dark:border-amber-900/60 flex items-center justify-between gap-3 shadow-sm">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0">
                    <Play size={16} fill="currentColor" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-xs text-slate-900 dark:text-white truncate">
                      {selectedDayDetail.videoDetails.title}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {selectedDayDetail.videoDetails.source}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-1 rounded-md shrink-0">
                  Watched
                </span>
              </div>
              <p className="text-[11px] text-amber-900/90 dark:text-amber-300/80 leading-normal">
                {selectedDayDetail.videoDetails.description}
              </p>
            </div>

            {/* Audio Details (Audio konta hota) */}
            <div className="bg-indigo-50/60 dark:bg-indigo-950/30 p-4 rounded-2xl border border-indigo-200 dark:border-indigo-900/50 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-indigo-700 dark:text-indigo-400">
                  <Headphones size={16} />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-900 dark:text-indigo-200">
                    Audio Podcast & Lecture Listened
                  </h4>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-900/60 text-indigo-800 dark:text-indigo-300">
                  {selectedDayDetail.audioDetails.duration}
                </span>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-100 dark:border-indigo-900/60 flex items-center justify-between gap-3 shadow-sm">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
                    <Volume2 size={16} />
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-xs text-slate-900 dark:text-white truncate">
                      {selectedDayDetail.audioDetails.title}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      Completed Audio Lesson
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-1 rounded-md shrink-0">
                  Listened
                </span>
              </div>
              <p className="text-[11px] text-indigo-900/90 dark:text-indigo-300/80 leading-normal">
                {selectedDayDetail.audioDetails.description}
              </p>
            </div>

            {/* Completed Tasks Checklist */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                All Steps Finished on This Day:
              </h4>
              <div className="space-y-1.5">
                {selectedDayDetail.tasksCompleted.map((tText, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
                    <CheckCircle2 size={14} className="text-emerald-500 shrink-0" />
                    <span>{tText}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Close Button */}
            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedDayDetail(null)}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold hover:opacity-90 transition-opacity shadow"
              >
                Close Day Task History
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
