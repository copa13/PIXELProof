import React, { useState } from 'react';
import { TaskItem, UserProfile, TabType } from '../types';
import { translations } from '../translations';
import { 
  BookOpen, 
  Code, 
  Wrench, 
  ChevronRight, 
  Sparkles, 
  TrendingUp, 
  CheckCircle2, 
  Sun, 
  Play,
  Check,
  Circle
} from 'lucide-react';

interface Props {
  profile: UserProfile;
  tasks: TaskItem[];
  onToggleTask: (id: string) => void;
  onOpenTaskModal: (task: TaskItem) => void;
  setActiveTab: (tab: TabType) => void;
  language: 'en' | 'mr' | 'hi';
  onUpdateStreak?: (days: number) => void;
  onSimulateMissedDay?: () => void;
}

export const HomeScreen: React.FC<Props> = ({
  profile,
  tasks,
  onToggleTask,
  onOpenTaskModal,
  setActiveTab,
  language,
  onUpdateStreak,
  onSimulateMissedDay,
}) => {
  const t = translations[language];
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Determine time-based greeting
  const hour = new Date().getHours();
  const greeting = hour < 12 ? (language === 'mr' ? 'शुभ प्रभात,' : language === 'hi' ? 'सुप्रभात,' : 'Good Morning,') : hour < 17 ? (language === 'mr' ? 'शुभ दुपार,' : language === 'hi' ? 'शुभ दोपहर,' : 'Good Afternoon,') : (language === 'mr' ? 'शुभ संध्याकाळ,' : language === 'hi' ? 'शुभ संध्या,' : 'Good Evening,');

  // Calculate overall progress
  const completedCount = tasks.filter(t => t.completed).length;
  const totalCount = tasks.length;
  const progressPercentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const getTaskIcon = (category: string) => {
    switch (category) {
      case 'learn':
        return <BookOpen size={16} className="text-sky-600 dark:text-sky-400" />;
      case 'practise':
        return <Code size={16} className="text-indigo-600 dark:text-indigo-400" />;
      case 'build':
        return <Wrench size={16} className="text-emerald-600 dark:text-emerald-400" />;
      case 'reassess':
        return <span className="font-extrabold text-xs text-amber-600 dark:text-amber-400 tracking-tighter flex items-baseline">R<span className="text-[9px] lowercase font-semibold">e</span></span>;
      default:
        return <Sparkles size={16} className="text-sky-600 dark:text-sky-400" />;
    }
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 text-white text-xs px-4 py-2.5 rounded-2xl shadow-2xl border border-sky-400/40 animate-in fade-in slide-in-from-top-4 flex items-center gap-2">
          <Sparkles size={14} className="text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Row: Welcome Section & Today Progress Card side-by-side */}
      <div className="grid grid-cols-2 gap-3">
        {/* Welcome Section */}
        <section className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-sky-600 dark:text-sky-400 mb-1">
            <Sun size={16} />
            <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-sky-50 dark:bg-sky-950">{t.welcome}</span>
          </div>
          <div>
            <p className="text-[11px] font-medium text-sky-600 dark:text-sky-400">{greeting}</p>
            <h1 className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
              {profile.name || 'Student'}
            </h1>
          </div>
          <p className="text-[10px] text-slate-500 dark:text-slate-400 italic truncate mt-1">
            “Small steps today...”
          </p>
        </section>

        {/* Today Progress Card */}
        <section className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-sky-600 dark:text-sky-400 mb-1">
            <TrendingUp size={16} />
            <span className="text-[9px] font-bold px-2.5 py-0.5 rounded-full bg-sky-50 dark:bg-sky-950 text-sky-700 dark:text-sky-300">
              {progressPercentage}%
            </span>
          </div>
          <div>
            <p className="text-xs font-bold text-slate-900 dark:text-white">{t.todayProgress}</p>
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden my-1.5">
              <div 
                className="bg-gradient-to-r from-sky-500 to-indigo-600 h-full rounded-full transition-all duration-500" 
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 dark:text-slate-400">Keep going!</p>
        </section>
      </div>

      {/* Today's Tasks */}
      <section className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h2 className="font-bold text-slate-900 dark:text-white text-base">{t.todaysTasks}</h2>
          <span className="text-xs font-semibold text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/80 px-2.5 py-1 rounded-full border border-sky-100 dark:border-sky-900">
            {completedCount}/{totalCount} {t.completed}
          </span>
        </div>

        <div className="space-y-2.5">
          {tasks.map(task => (
            <div
              key={task.id}
              className={`group bg-white dark:bg-slate-900 rounded-2xl p-3.5 border transition-all hover:shadow-md flex items-center justify-between gap-3 ${
                task.completed
                  ? 'border-emerald-200/80 dark:border-emerald-900/50 bg-emerald-50/20 dark:bg-emerald-950/10'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className="flex items-center gap-3 flex-1 min-w-0">
                {/* Checkbox toggle only for task 2 */}
                {task.id === '2' ? (
                  <button
                    onClick={() => onToggleTask(task.id)}
                    aria-label={task.completed ? 'Mark incomplete' : 'Mark complete'}
                    className="p-1 rounded-xl text-slate-400 hover:text-sky-600 transition-colors shrink-0"
                  >
                    {task.completed ? (
                      <CheckCircle2 size={20} className="text-emerald-600 dark:text-emerald-500" />
                    ) : (
                      <Circle size={20} className="text-slate-300 dark:text-slate-600" />
                    )}
                  </button>
                ) : (
                  <div className="w-5 shrink-0" />
                )}

                <div 
                  onClick={() => onOpenTaskModal(task)}
                  className="flex-1 cursor-pointer min-w-0"
                >
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded-lg bg-sky-50 dark:bg-sky-950/60 shrink-0">
                      {getTaskIcon(task.category)}
                    </span>
                    <h3 className="font-semibold text-xs text-slate-900 dark:text-white">
                      {task.title}
                    </h3>
                  </div>
                </div>
              </div>

              {/* Start button & Navigation arrow */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => onOpenTaskModal(task)}
                  className="px-3 py-1.5 rounded-xl bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400 text-xs font-bold hover:bg-sky-100 transition-colors flex items-center gap-1 shadow-sm"
                >
                  <Play size={12} fill="currentColor" /> {t.start}
                </button>
                <button
                  onClick={() => onOpenTaskModal(task)}
                  aria-label={`Open task details for ${task.title}`}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-sky-600 dark:hover:text-sky-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

