import React, { useState } from 'react';
import { 
  ArrowLeft, 
  X, 
  Sparkles, 
  CheckCircle2, 
  RotateCcw,
  Compass,
  Tag
} from 'lucide-react';
import { 
  aiGoalsBank, 
  getQuestionById, 
  createInitialQuizState, 
  answerQuestion, 
  undoLastQuestion,
  computeCareerMatches
} from '../utils/aiGoalsEngine';
import { AiGoalsQuizState, CareerMatchResult } from '../types/aiGoals';

interface AiDecidedGoalsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language?: 'en' | 'mr' | 'hi';
  onSelectCareer?: (careerTitle: string, meta: Record<string, any>) => void;
}

export const AiDecidedGoalsModal: React.FC<AiDecidedGoalsModalProps> = ({
  isOpen,
  onClose,
  language = 'mr',
  onSelectCareer,
}) => {
  // 1. Core quiz state: current question, question number (1..15), history, tag scores, cluster, track, meta values
  const [quizState, setQuizState] = useState<AiGoalsQuizState>(() => createInitialQuizState());
  
  // Transient UI states for interaction feedback and buddy message animations
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [animating, setAnimating] = useState<boolean>(false);
  const [buddyNotice, setBuddyNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  // Retrieve the current question object safely from the question bank
  const currentQuestion = getQuestionById(quizState.currentQuestionId);

  // Restart quiz back to Q1 with zero scores
  const handleRestart = () => {
    setQuizState(createInitialQuizState());
    setSelectedIdx(null);
    setBuddyNotice(null);
    setAnimating(false);
  };

  // Undo one question back: restores previous question, questionNumber, tags, cluster, track & meta
  const handleBack = () => {
    if (quizState.history.length === 0) {
      onClose();
      return;
    }
    const rolledBack = undoLastQuestion(quizState);
    setQuizState(rolledBack);
    setSelectedIdx(null);
    setBuddyNotice(null);
  };

  // Tap an option: triggers smooth transition, buddy encouraging message, and branching to next question
  const handleOptionClick = (index: number) => {
    if (animating) return; // Prevent double tap during transition
    setSelectedIdx(index);
    setAnimating(true);

    // Compute updated state and encouraging buddy line
    const { newState, buddyMessage } = answerQuestion(quizState, index);
    setBuddyNotice(buddyMessage);

    // Smooth animation delay so user sees option selection & buddy message before question change
    setTimeout(() => {
      setQuizState(newState);
      setSelectedIdx(null);
      setAnimating(false);
    }, 450);
  };

  // Percentage progress across exactly 15 questions (1..15)
  const progressPercent = Math.min(100, Math.round(((quizState.questionNumber - 1) / 15) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Top Header: Navigation, Question counter "प्रश्न 6 / 15", and Close */}
        <div className="px-5 pt-5 pb-3 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/70 dark:bg-slate-900/70">
          <div className="flex items-center justify-between gap-3 mb-3">
            {/* Back Button (Undos last question) */}
            <button
              onClick={handleBack}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition active:scale-95 cursor-pointer"
              title="मागे जा (Previous question)"
            >
              <ArrowLeft size={16} />
              <span>{quizState.questionNumber > 1 ? 'मागे जा' : 'बाहेर पडा'}</span>
            </button>

            {/* Central Progress Title: Exactly "प्रश्न 6 / 15" format */}
            <div className="text-center">
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-sky-50 dark:bg-sky-950/80 border border-sky-200/60 dark:border-sky-800/60 text-sky-700 dark:text-sky-300 text-xs font-extrabold tracking-wide shadow-xs">
                <Compass size={13} className="text-sky-600 dark:text-sky-400" />
                {`प्रश्न ${quizState.questionNumber} / 15`}
              </span>
            </div>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition active:scale-95 cursor-pointer"
              title="बंद करा"
            >
              <X size={18} />
            </button>
          </div>

          {/* Progress Bar (0% to 100%) */}
          <div className="space-y-1">
            <div className="w-full h-2.5 bg-slate-200/80 dark:bg-slate-800 rounded-full overflow-hidden p-0.5">
              <div 
                className="h-full bg-gradient-to-r from-sky-500 via-indigo-500 to-emerald-500 rounded-full transition-all duration-300 ease-out shadow-xs"
                style={{ width: `${Math.max(6, progressPercent)}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-[10px] text-slate-500 dark:text-slate-400 px-0.5 font-medium">
              <span>सुरुवात (Q1)</span>
              <span>{quizState.questionNumber}/15 पूर्ण</span>
              <span>ध्येय (Result)</span>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          
          {/* Friendly Buddy (🦉) encouraging banner shown after answers */}
          {buddyNotice && (
            <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-200 text-xs font-medium flex items-center gap-2.5 animate-in slide-in-from-top-2 duration-300 shadow-xs">
              <span className="text-lg">🦉</span>
              <p className="flex-1 leading-snug">{buddyNotice}</p>
            </div>
          )}

          {/* Question Display Screen */}
          {currentQuestion && !quizState.isFinished ? (
            <div className={`space-y-5 transition-opacity duration-200 ${animating ? 'opacity-50' : 'opacity-100'}`}>
              
              {/* Category Badge & Branching Context */}
              <div className="flex items-center justify-between gap-2 flex-wrap">
                {currentQuestion.category && (
                  <span className="px-3 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200/60 dark:border-indigo-800/60 text-indigo-700 dark:text-indigo-300 text-[11px] font-bold">
                    {currentQuestion.category}
                  </span>
                )}
                
                {/* Active Cluster / Track badge if already selected earlier */}
                {(quizState.cluster || quizState.track) && (
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md font-mono">
                    {quizState.track ? `Track: ${quizState.track}` : `Cluster: ${quizState.cluster}`}
                  </span>
                )}
              </div>

              {/* The Question Text */}
              <div className="bg-slate-50/80 dark:bg-slate-800/40 rounded-2xl p-4 sm:p-5 border border-slate-100 dark:border-slate-800">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-relaxed">
                  {currentQuestion.text}
                </h2>
              </div>

              {/* Large Rounded Option Cards */}
              <div className="space-y-3 pt-1">
                {currentQuestion.options.map((opt, idx) => {
                  const isSelected = selectedIdx === idx;
                  const optionLetters = ['A', 'B', 'C', 'D', 'E'];
                  const letterBadge = optionLetters[idx] || `${idx + 1}`;

                  return (
                    <button
                      key={idx}
                      onClick={() => handleOptionClick(idx)}
                      disabled={animating}
                      className={`w-full text-left p-4 sm:p-5 rounded-2xl border transition-all duration-200 flex items-center justify-between gap-4 cursor-pointer select-none group active:scale-[0.99] ${
                        isSelected
                          ? 'border-sky-500 bg-sky-50/80 dark:bg-sky-950/60 text-sky-950 dark:text-sky-100 ring-2 ring-sky-500/20 shadow-md scale-[1.01]'
                          : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-sky-300 dark:hover:border-sky-700 hover:bg-slate-50/60 dark:hover:bg-slate-800/50 text-slate-800 dark:text-slate-200 shadow-xs'
                      }`}
                    >
                      <div className="flex items-center gap-3.5 flex-1">
                        {/* Option Letter Indicator */}
                        <span className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 transition-colors ${
                          isSelected
                            ? 'bg-sky-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 group-hover:bg-sky-100 dark:group-hover:bg-sky-900/60 group-hover:text-sky-600 dark:group-hover:text-sky-300'
                        }`}>
                          {letterBadge}
                        </span>

                        {/* Marathi Option Text */}
                        <span className="text-sm font-medium leading-normal flex-1">
                          {opt.text}
                        </span>
                      </div>

                      {/* Selection Check Circle */}
                      <div className={`w-6 h-6 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                        isSelected
                          ? 'border-sky-600 bg-sky-600 text-white'
                          : 'border-slate-300 dark:border-slate-700 text-transparent group-hover:border-sky-400'
                      }`}>
                        <CheckCircle2 size={15} />
                      </div>
                    </button>
                  );
                })}
              </div>

            </div>
          ) : (
            /* Result Screen: Step 4 Spec (#1 Career as "तुमचं ध्येय", circular Match %, next 2-4 careers, why text, "हे करिअर निवडा" button) */
            (() => {
              const matches = computeCareerMatches(quizState.tagScores, quizState.track);
              const topCareerMatch = matches[0];
              const otherMatches = matches.slice(1, 4);

              return (
                <div className="space-y-6 animate-in fade-in zoom-in-95">
                  {/* Top #1 Career Card: तुमचं ध्येय */}
                  <div className="bg-gradient-to-br from-indigo-900/40 via-sky-950/50 to-slate-900 border-2 border-sky-500/50 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden text-center sm:text-left">
                    <div className="absolute -right-10 -bottom-10 w-44 h-44 bg-sky-500/15 rounded-full blur-2xl pointer-events-none" />
                    <div className="absolute -left-10 -top-10 w-44 h-44 bg-indigo-500/15 rounded-full blur-2xl pointer-events-none" />

                    {/* Badge */}
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/20 border border-sky-400/40 text-sky-300 text-xs font-black tracking-wide mb-3">
                      <Sparkles size={13} className="text-amber-300" />
                      <span>तुमचं ध्येय (AI Recommended Goal)</span>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
                      {/* Large Animated Circular Match % */}
                      <div className="relative w-28 h-28 shrink-0 flex items-center justify-center">
                        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                          <circle
                            cx="50"
                            cy="50"
                            r="42"
                            className="stroke-slate-700/60"
                            strokeWidth="9"
                            fill="transparent"
                          />
                          <circle
                            cx="50"
                            cy="50"
                            r="42"
                            className="stroke-sky-400 transition-all duration-1000 ease-out"
                            strokeWidth="9"
                            strokeDasharray={264}
                            strokeDashoffset={264 - (264 * (topCareerMatch?.matchPercent || 96)) / 100}
                            strokeLinecap="round"
                            fill="transparent"
                          />
                        </svg>
                        <div className="absolute flex flex-col items-center justify-center">
                          <span className="text-2xl font-black text-white tabular-nums tracking-tighter">
                            {topCareerMatch?.matchPercent || 96}%
                          </span>
                          <span className="text-[10px] font-bold text-sky-300 uppercase">Match</span>
                        </div>
                      </div>

                      {/* Career Details */}
                      <div className="flex-1 space-y-2">
                        <h3 className="text-lg sm:text-xl font-black text-white leading-tight">
                          {topCareerMatch?.career.title}
                        </h3>
                        {topCareerMatch?.career.description && (
                          <p className="text-xs text-slate-300 leading-relaxed">
                            {topCareerMatch.career.description}
                          </p>
                        )}

                        {/* Marathi Template "Why" Text built from top contributing tags */}
                        <div className="p-3 rounded-2xl bg-slate-900/80 border border-sky-500/30 text-left space-y-1 mt-2">
                          <div className="flex items-center gap-1.5 text-sky-300 font-bold text-[11px]">
                            <Compass size={13} />
                            <span>AI विश्लेषण (हे करिअर का?):</span>
                          </div>
                          <p className="text-xs text-slate-200 leading-relaxed">
                            {topCareerMatch?.whyText}
                          </p>
                        </div>

                        {/* Key Skills */}
                        {topCareerMatch?.career.keySkills && (
                          <div className="flex flex-wrap gap-1.5 pt-1">
                            {topCareerMatch.career.keySkills.map((sk, sIdx) => (
                              <span
                                key={sIdx}
                                className="px-2.5 py-0.5 rounded-lg bg-sky-950/70 border border-sky-700/60 text-sky-200 text-[10px] font-semibold"
                              >
                                {sk}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Primary Action Button: "हे करिअर निवडा" */}
                    <div className="mt-5 pt-3 border-t border-slate-700/60 flex flex-col sm:flex-row items-center justify-between gap-3">
                      <div className="text-[11px] text-slate-400">
                        {quizState.metaValues.weeklyHours && (
                          <span>वेळ: {quizState.metaValues.weeklyHours} तास/आठवडा • </span>
                        )}
                        {quizState.metaValues.learningLanguage && (
                          <span>भाषा: {quizState.metaValues.learningLanguage}</span>
                        )}
                      </div>
                      <button
                        onClick={() => {
                          if (topCareerMatch) {
                            onSelectCareer?.(topCareerMatch.career.title, quizState.metaValues);
                            onClose();
                          }
                        }}
                        className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-sky-600 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-white font-extrabold text-sm shadow-lg shadow-sky-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                      >
                        <CheckCircle2 size={16} />
                        <span>हे करिअर निवडा (Choose This Goal)</span>
                      </button>
                    </div>
                  </div>

                  {/* Next 2-4 Career Matches */}
                  {otherMatches.length > 0 && (
                    <div className="space-y-3 text-left">
                      <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5 px-1">
                        <Tag size={12} className="text-sky-500" />
                        <span>इतर सर्वोत्तम करिअर पर्याय (Alternative Matches):</span>
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        {otherMatches.map((m, idx) => (
                          <div
                            key={m.career.id}
                            className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 space-y-2 flex flex-col justify-between"
                          >
                            <div className="space-y-1.5">
                              <div className="flex items-center justify-between gap-2">
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-750 text-slate-700 dark:text-slate-300 font-mono">
                                  #{idx + 2}
                                </span>
                                <span className="text-xs font-black text-sky-600 dark:text-sky-400">
                                  {m.matchPercent}% Match
                                </span>
                              </div>
                              <h5 className="text-xs font-bold text-slate-900 dark:text-white leading-snug">
                                {m.career.title}
                              </h5>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                                {m.whyText}
                              </p>
                            </div>
                            <button
                              onClick={() => {
                                onSelectCareer?.(m.career.title, quizState.metaValues);
                                onClose();
                              }}
                              className="w-full py-1.5 rounded-xl bg-slate-200/80 dark:bg-slate-750 hover:bg-sky-500 hover:text-white text-slate-700 dark:text-slate-200 text-[11px] font-bold transition cursor-pointer"
                            >
                              हे करिअर निवडा
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Restart or Review Answers */}
                  <div className="flex items-center justify-between pt-2 px-1 text-xs text-slate-500 dark:text-slate-400">
                    <button
                      onClick={handleRestart}
                      className="hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 font-semibold cursor-pointer"
                    >
                      <RotateCcw size={13} />
                      <span>प्रश्नावली पुन्हा सुरू करा</span>
                    </button>
                    <button
                      onClick={onClose}
                      className="hover:underline cursor-pointer"
                    >
                      खिडकी बंद करा
                    </button>
                  </div>
                </div>
              );
            })()
          )}

        </div>

        {/* Footer info banner */}
        <div className="px-5 py-3 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span className="flex items-center gap-1.5">
            <Sparkles size={13} className="text-amber-500" />
            AI Decided Goals • १५ प्रश्नांचे मूल्यांकन
          </span>
          <span>
            {quizState.history.length > 0 ? (
              <button
                onClick={handleBack}
                className="text-sky-600 dark:text-sky-400 hover:underline font-semibold cursor-pointer"
              >
                मागील प्रश्न दुरुस्त करा
              </button>
            ) : (
              'पर्याय निवडून पुढे चला'
            )}
          </span>
        </div>

      </div>
    </div>
  );
};
