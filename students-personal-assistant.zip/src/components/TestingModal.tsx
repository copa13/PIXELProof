import React, { useState } from 'react';
import { TaskItem } from '../types';
import { X, Code, Play, CheckCircle2, Award, ArrowRight } from 'lucide-react';

interface Props {
  task: TaskItem | null;
  onClose: () => void;
  language: 'en' | 'mr' | 'hi';
}

interface Question {
  id: number;
  question: string;
  options: string[];
  correct: number;
}

export const TestingModal: React.FC<Props> = ({ task, onClose, language }) => {
  if (!task) return null;

  const isMarathi = language === 'mr';
  const [step, setStep] = useState<'config' | 'test' | 'result'>('config');
  const [questionCount, setQuestionCount] = useState<number>(20);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState<number>(0);

  const generateQuestions = (count: number): Question[] => {
    const list: Question[] = [];
    for (let i = 1; i <= count; i++) {
      list.push({
        id: i,
        question: isMarathi 
          ? `प्रश्न ${i}: डायनॅमिक प्रोग्रामिंग आणि डेटा स्ट्रक्चर्स (Question #${i}) मधील योग्य पर्याय कोणता?`
          : `Practice Testing Question #${i}: What is the optimal approach for this algorithmic challenge?`,
        options: [
          isMarathi ? 'ऑप्टिमाइज्ड डायनॅमिक प्रोग्रामिंग' : 'Optimized Dynamic Programming',
          isMarathi ? 'ब्रूट फोर्स अप्रोच' : 'Brute Force Approach',
          isMarathi ? 'लीनियर सर्च' : 'Linear Search',
          isMarathi ? 'रँडम शफलिंग' : 'Random Shuffling',
        ],
        correct: 0,
      });
    }
    return list;
  };

  const [questions, setQuestions] = useState<Question[]>([]);

  const handleStartTest = () => {
    const generated = generateQuestions(questionCount);
    setQuestions(generated);
    setCurrentIndex(0);
    setScore(0);
    setSelectedOption(null);
    setStep('test');
  };

  const handleNextQuestion = () => {
    if (selectedOption === null) return;
    const currentQ = questions[currentIndex];
    const isCorrect = selectedOption === currentQ.correct;
    const newScore = isCorrect ? score + 1 : score;
    setScore(newScore);

    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedOption(null);
    } else {
      setStep('result');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 dark:border-slate-800 p-6 relative animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full"
        >
          <X size={20} />
        </button>

        {step === 'config' && (
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                <Code size={24} />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  {isMarathi ? 'प्रॅक्टिस टेस्ट (Testing)' : 'Practice Testing'}
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">{task.title}</h3>
              </div>
            </div>

            <div className="space-y-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Select question quantity
              </label>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="20"
                  max="50"
                  step="5"
                  value={questionCount}
                  onChange={e => setQuestionCount(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
                <span className="font-extrabold text-lg text-indigo-600 dark:text-indigo-400 w-12 text-center bg-indigo-50 dark:bg-indigo-950 py-1 rounded-xl">
                  {questionCount}
                </span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={handleStartTest}
                className="px-6 py-3 rounded-2xl bg-indigo-600 text-white font-bold text-xs shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all flex items-center gap-2"
              >
                <Play size={16} fill="currentColor" /> {isMarathi ? 'टेस्ट सुरू करा' : 'Start Test'}
              </button>
            </div>
          </div>
        )}

        {step === 'test' && questions.length > 0 && (
          <div className="space-y-6">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 pb-3 border-b border-slate-100 dark:border-slate-800">
              <span>{isMarathi ? `प्रश्न ${currentIndex + 1} / ${questions.length}` : `Question ${currentIndex + 1} of ${questions.length}`}</span>
              <span className="text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950 px-2.5 py-1 rounded-full">
                Practice Test
              </span>
            </div>

            <h3 className="text-base font-bold text-slate-900 dark:text-white leading-relaxed">
              {questions[currentIndex].question}
            </h3>

            <div className="space-y-3">
              {questions[currentIndex].options.map((option, idx) => {
                const isSelected = selectedOption === idx;
                return (
                  <button
                    key={idx}
                    onClick={() => setSelectedOption(idx)}
                    className={`w-full text-left p-4 rounded-2xl border text-xs font-medium transition-all flex items-center justify-between ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200 shadow-sm'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    <span>{option}</span>
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                      isSelected ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-slate-300 dark:border-slate-600'
                    }`}>
                      {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="flex justify-end pt-4">
              <button
                onClick={handleNextQuestion}
                disabled={selectedOption === null}
                className={`px-6 py-3 rounded-2xl font-bold text-xs flex items-center gap-2 transition-all ${
                  selectedOption === null
                    ? 'bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-600 cursor-not-allowed'
                    : 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20 hover:bg-indigo-700'
                }`}
              >
                {currentIndex === questions.length - 1 ? (isMarathi ? 'टेस्ट पूर्ण करा' : 'Finish Test') : (isMarathi ? 'पुढील प्रश्न' : 'Next Question')} <ArrowRight size={16} />
              </button>
            </div>
          </div>
        )}

        {step === 'result' && (
          <div className="space-y-6 text-center">
            <div className="w-20 h-20 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-full mx-auto flex items-center justify-center">
              <Award size={40} />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
                Calculation Today's Task
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isMarathi ? 'तुम्ही सर्व प्रश्न यशस्वीरित्या पूर्ण केले आहेत.' : 'You have successfully completed all test questions.'}
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 max-w-xs mx-auto space-y-2">
              <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Final Score Calculation</p>
              <p className="text-3xl font-black text-slate-900 dark:text-white">
                {score} / {questions.length}
              </p>
              <p className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                {Math.round((score / questions.length) * 100)}% Accuracy
              </p>
            </div>

            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={onClose}
                className="px-6 py-3 rounded-2xl bg-indigo-600 text-white font-bold text-xs shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all flex items-center gap-2"
              >
                <CheckCircle2 size={16} /> {isMarathi ? 'पूर्ण झाले (Done)' : 'Done'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
