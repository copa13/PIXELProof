import React, { useState, useEffect } from 'react';
import { 
  X, 
  Check, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  Bot, 
  Zap, 
  Award, 
  Target, 
  HelpCircle, 
  ArrowRight, 
  RotateCcw, 
  BookOpen, 
  ShieldCheck, 
  Plus, 
  Info,
  Clock,
  CheckCheck
} from 'lucide-react';
import { SkillItem } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  type: 'achieved' | 'missing';
  goalName?: string;
  onAddAchievedSkill: (skill: SkillItem) => void;
  onAddMissingSkill: (skill: SkillItem) => void;
}

interface Question {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
}

// Popular skill suggestions for quick selection
const POPULAR_SKILLS = [
  'React.js',
  'TypeScript',
  'Python',
  'SQL & PostgreSQL',
  'Node.js & Express',
  'Docker & Containers',
  'Git & GitHub',
  'Tailwind CSS',
  'Data Structures & Algorithms',
  'REST APIs & GraphQL',
  'Machine Learning Basics',
  'Next.js 14',
  'Cybersecurity Fundamentals',
  'Linux & Bash Shell',
];

// Rich predefined question database for popular tech skills
const SKILL_QUESTION_BANK: Record<string, Question[]> = {
  'react': [
    { id: 1, question: 'Which React hook is primarily designed for running side effects such as data fetching or subscriptions?', options: ['useState', 'useEffect', 'useMemo', 'useReducer'], correctIndex: 1 },
    { id: 2, question: 'Why does React require a unique "key" prop when rendering dynamic arrays of elements?', options: ['To style elements automatically', 'To enable React to identify which items have changed, added, or removed efficiently', 'To bind event listeners to the DOM', 'To convert elements into pure web components'], correctIndex: 1 },
    { id: 3, question: 'How do you pass data from a parent component down to a child component in standard React?', options: ['Via global window variables', 'Via Props', 'Via HTML data attributes', 'Via Redux actions only'], correctIndex: 1 },
    { id: 4, question: 'Which hook should you use to preserve and memoize an expensive calculated value across renders?', options: ['useCallback', 'useMemo', 'useRef', 'useEffect'], correctIndex: 1 },
    { id: 5, question: 'What is the primary purpose of the useCallback hook in React?', options: ['To trigger DOM updates', 'To memoize a callback function instance between renders', 'To replace useState completely', 'To run asynchronous network requests'], correctIndex: 1 },
    { id: 6, question: 'What is the Virtual DOM in React?', options: ['A direct binary clone of the browser window', 'A lightweight in-memory representation of the real DOM tree', 'A backend server rendering engine', 'A CSS preprocessing module'], correctIndex: 1 },
    { id: 7, question: 'What happens when state is updated using a setState setter function?', options: ['The browser hard reloads the entire page', 'React schedules a re-render of the component and its children', 'All global variables are deleted', 'The DOM is destroyed and rebuilt from scratch'], correctIndex: 1 },
    { id: 8, question: 'Which hook allows storing a mutable value that does NOT trigger a re-render when changed?', options: ['useState', 'useRef', 'useContext', 'useId'], correctIndex: 1 },
    { id: 9, question: 'What is the purpose of React Context API?', options: ['To replace CSS stylesheet imports', 'To share data globally across the component tree without prop drilling', 'To compile TypeScript to JavaScript', 'To communicate with WebSockets automatically'], correctIndex: 1 },
    { id: 10, question: 'In React Strict Mode, why do effect hooks and render functions run twice in development?', options: ['Because of a compiler bug in Vite', 'To help detect unexpected side-effects and cleanup bugs early', 'To double memory allocation', 'To verify internet connectivity'], correctIndex: 1 },
    { id: 11, question: 'What lifecycle phase does the cleanup return function of useEffect execute?', options: ['Before component unmounts or before the effect re-runs', 'Only when the user closes their browser tab', 'Never unless explicitly called by name', 'During initial HTML parsing only'], correctIndex: 0 },
    { id: 12, question: 'What is a Controlled Component in React form handling?', options: ['A component whose form state is driven by React state via value and onChange', 'An input whose value is controlled by external jQuery plugins', 'A read-only input that cannot be edited', 'A component rendered exclusively on the server'], correctIndex: 0 },
    { id: 13, question: 'How can you catch JavaScript errors anywhere in a child component tree in React?', options: ['Using Error Boundaries with componentDidCatch / getDerivedStateFromError', 'Wrapping index.html in a try-catch block', 'Using window.alert in every component', 'Errors cannot be caught in React components'], correctIndex: 0 },
    { id: 14, question: 'What does React.memo() do when wrapping a functional component?', options: ['Forces the component to re-render every 500ms', 'Skips rendering the component if its props have not changed (shallow comparison)', 'Encrypts the component props in memory', 'Converts functional components to class components'], correctIndex: 1 },
    { id: 15, question: 'Which React feature allows rendering children into a DOM node outside the parent hierarchy?', options: ['React Portals (createPortal)', 'React Fragments', 'React Suspense', 'React Hydrate'], correctIndex: 0 },
    { id: 16, question: 'What is the rule regarding the order of hook calls in React components?', options: ['Hooks must be called inside loops and conditional statements', 'Hooks must only be called at the top level of the component and in the same order', 'Hooks can only be called inside setTimeout callbacks', 'Hooks must be alphabetical'], correctIndex: 1 },
    { id: 17, question: 'What is React Suspense primarily used for?', options: ['Pausing JavaScript execution permanently', 'Displaying fallback UI while child components are loading data or code-split chunks', 'Debugging network latency issues in devtools', 'Preventing click events from propagating'], correctIndex: 1 },
    { id: 18, question: 'Why should you avoid mutating state directly (e.g., state.push(item)) in React?', options: ['Because JavaScript will throw a syntax error', 'Because React relies on reference inequality to detect changes and trigger re-renders', 'Because arrays in React are immutable by default', 'It causes high battery consumption only'], correctIndex: 1 },
    { id: 19, question: 'What does the useReducer hook return?', options: ['A promise and a cancel function', 'A tuple containing the current state and a dispatch function', 'An array of action strings', 'A single DOM reference'], correctIndex: 1 },
    { id: 20, question: 'In modern React 18+, what is Concurrent Rendering designed to accomplish?', options: ['Run React on multiple CPU cores via WebAssembly', 'Keep UI responsive by allowing React to interrupt, pause, or resume rendering work', 'Automatically optimize database queries', 'Replace Node.js backends entirely'], correctIndex: 1 },
  ],
  'python': [
    { id: 1, question: 'Which of the following built-in data types in Python is MUTABLE and ordered?', options: ['Tuple', 'List', 'FrozenSet', 'String'], correctIndex: 1 },
    { id: 2, question: 'What keyword is used to handle exceptions and catch errors in Python?', options: ['catch', 'except', 'handle', 'rescue'], correctIndex: 1 },
    { id: 3, question: 'What is the purpose of the "__init__" method in a Python class?', options: ['Destroys class instances upon garbage collection', 'Acts as the constructor initializer when creating a new object instance', 'Compiles bytecode into machine code', 'Imports standard libraries automatically'], correctIndex: 1 },
    { id: 4, question: 'What does the Global Interpreter Lock (GIL) in CPython do?', options: ['Prevents more than one native thread from executing Python bytecodes at once', 'Locks the filesystem during write operations', 'Encrypts user passwords in memory', 'Blocks external network connections'], correctIndex: 0 },
    { id: 5, question: 'Which built-in Python function returns an iterator of tuples pairing elements with indices?', options: ['zip()', 'enumerate()', 'range()', 'map()'], correctIndex: 1 },
    { id: 6, question: 'What does the "yield" keyword do inside a Python function?', options: ['Terminates the program immediately', 'Turns the function into a generator that yields values one at a time on demand', 'Forces a garbage collection cycle', 'Imports a module dynamically'], correctIndex: 1 },
    { id: 7, question: 'What is the difference between "==" and "is" operators in Python?', options: ['"==" checks equality of value, while "is" checks object identity in memory', '"==" checks memory address, "is" checks value', 'They are completely interchangeable', '"is" is only used for strings'], correctIndex: 0 },
    { id: 8, question: 'How do you create a shallow copy of a list named `my_list` in Python?', options: ['my_list[:]', 'copy(my_list)', 'my_list.clone()', 'Both A and list(my_list)'], correctIndex: 3 },
    { id: 9, question: 'What is a Python decorator?', options: ['A visual CSS styling tool in Jupyter', 'A callable that takes another function as input and extends its behavior without modifying it', 'A comment block above a class', 'A package manager like pip'], correctIndex: 1 },
    { id: 10, question: 'What is the time complexity of looking up a key in a standard Python dictionary on average?', options: ['O(N)', 'O(1)', 'O(log N)', 'O(N^2)'], correctIndex: 1 },
    { id: 11, question: 'What built-in module provides support for running unit tests in Python?', options: ['pytest', 'unittest', 'testrunner', 'assertlib'], correctIndex: 1 },
    { id: 12, question: 'What statement allows managing resources (like closing files) safely via context managers?', options: ['using', 'with', 'open_safe', 'manage'], correctIndex: 1 },
    { id: 13, question: 'What does `*args` and `**kwargs` represent in a Python function definition?', options: ['Pointers to C memory addresses', 'Arbitrary positional arguments (tuple) and arbitrary keyword arguments (dict)', 'Mathematical multiplication operators only', 'Type annotations for integers and strings'], correctIndex: 1 },
    { id: 14, question: 'Which comprehension syntax creates a set containing the squares of numbers from 0 to 4?', options: ['{x**2 for x in range(5)}', '[x**2 for x in range(5)]', '(x**2 for x in range(5))', '{x: x**2 for x in range(5)}'], correctIndex: 0 },
    { id: 15, question: 'What is the purpose of the `__str__` vs `__repr__` dunder methods in Python?', options: ['__str__ is for readable user display; __repr__ is for unambiguous developer inspection', 'They are identical with no difference', '__str__ prints integers, __repr__ prints floats', '__repr__ is only used in Python 2'], correctIndex: 0 },
    { id: 16, question: 'What happens if you pass a mutable object (like a list `[]`) as a default parameter in Python?', options: ['Python creates a fresh copy on every function call', 'The default list is created once at function definition and shared across all calls', 'Python throws a SyntaxError', 'The list is automatically converted to a tuple'], correctIndex: 1 },
    { id: 17, question: 'Which Python standard library is used for handling JSON data serialization and parsing?', options: ['json', 'simplejson', 'jsonify', 'parser'], correctIndex: 0 },
    { id: 18, question: 'What does `async def` and `await` enable in Python 3.5+?', options: ['Multi-core CPU parallel execution', 'Coroutines and asynchronous event-loop driven programming via asyncio', 'Automatic multithread synchronization', 'Direct GPU rendering'], correctIndex: 1 },
    { id: 19, question: 'What is the standard tool used to create isolated virtual environments in Python 3?', options: ['pipenv', 'venv', 'conda', 'npm'], correctIndex: 1 },
    { id: 20, question: 'What does PEP 8 define in the Python ecosystem?', options: ['The Python Package Index standards', 'The official Style Guide for Python code formatting and conventions', 'The security encryption policy', 'The Python Enhancement Proposal for version 4.0'], correctIndex: 1 },
  ],
};

// Generates 20 smart contextual questions for any custom skill
function getQuestionsForSkill(skillName: string): Question[] {
  const normalized = skillName.toLowerCase().trim();
  for (const [key, questions] of Object.entries(SKILL_QUESTION_BANK)) {
    if (normalized.includes(key) && questions.length === 20) {
      return questions;
    }
  }

  // Universal 20-Question Comprehensive Assessment Engine
  const baseTemplates = [
    {
      q: `What is the primary role and architectural foundation of "${skillName}"?`,
      opts: [
        `It serves as an outdated legacy script with no modern production relevance`,
        `It provides modular, standardized capabilities to solve domain challenges efficiently`,
        `It is exclusively used for storing static images on a server`,
        `It bypasses operating system security layers completely`
      ],
      c: 1,
    },
    {
      q: `Which naming convention and code organization strategy is recommended when structuring a "${skillName}" project?`,
      opts: [
        `Placing all application code and variables into a single massive index file`,
        `Clear folder modularity, separation of concerns, and descriptive naming conventions`,
        `Using randomized alphanumeric names for functions to obfuscate code`,
        `Hardcoding all database passwords into client templates`
      ],
      c: 1,
    },
    {
      q: `How are state, variables, and scoping typically isolated in "${skillName}" to prevent memory leaks?`,
      opts: [
        `Declaring everything on global window or root namespaces without scoping`,
        `Encapsulating state within bounded modules, local scopes, and explicit lifecycle hooks`,
        `Disabling garbage collection in environment settings`,
        `Storing all user inputs in hardcoded system files`
      ],
      c: 1,
    },
    {
      q: `What is the industry best practice for handling exceptions and runtime errors when working with "${skillName}"?`,
      opts: [
        `Suppressing errors silently so users never know what failed`,
        `Graceful exception handling, structured error logging, and friendly user fallback states`,
        `Crashing the entire application server immediately on any null value`,
        `Exposing raw database credentials in the user error dialog`
      ],
      c: 1,
    },
    {
      q: `How does "${skillName}" execute and synchronize asynchronous operations or I/O workloads?`,
      opts: [
        `Freezing user interaction synchronously until remote servers respond`,
        `Utilizing event loops, promises, callbacks, or reactive background pipelines`,
        `Spawning unconstrained infinite threads without thread pools`,
        `Asynchronous execution is strictly impossible in this domain`
      ],
      c: 1,
    },
    {
      q: `Which technique yields the highest performance gains when optimizing "${skillName}" in production?`,
      opts: [
        `Sending redundant network polling requests every 10 milliseconds`,
        `Implementing strategic caching, lazy-loading, and eliminating redundant computations`,
        `Disabling encryption and authentication checks completely`,
        `Running heavy computational loops synchronously on the main UI thread`
      ],
      c: 1,
    },
    {
      q: `What security principle must always be enforced when processing external user input in "${skillName}"?`,
      opts: [
        `Trusting all client input implicitly without sanitization`,
        `Strict input validation, parameterized payloads, and output sanitization to prevent injection`,
        `Storing user passwords in clear plain text files`,
        `Disabling CORS and HTTPS certificates`
      ],
      c: 1,
    },
    {
      q: `How should third-party dependencies and packages be managed in a "${skillName}" environment?`,
      opts: [
        `Copying arbitrary code from untrusted forums directly into source files`,
        `Using audited package managers with lockfiles, version pinning, and vulnerability scans`,
        `Never updating dependencies under any circumstances`,
        `Installing every available package globally without version checks`
      ],
      c: 1,
    },
    {
      q: `What is the primary purpose of writing automated unit tests for "${skillName}" code?`,
      opts: [
        `To make the codebase unnecessarily large and slow down build times`,
        `To verify individual units work as expected and prevent regression bugs during refactoring`,
        `To replace manual code review and automated deployment entirely`,
        `Unit testing is considered deprecated in modern development`
      ],
      c: 1,
    },
    {
      q: `Which debugging tool or approach is most effective for diagnosing issues in "${skillName}"?`,
      opts: [
        `Guessing and editing random lines of code until it compiles`,
        `Using dedicated debuggers, structured stack traces, breakpoints, and targeted logging`,
        `Deleting the error reporting framework from the project`,
        `Restarting the computer after every code change`
      ],
      c: 1,
    },
    {
      q: `How does "${skillName}" facilitate code reusability across large software architectures?`,
      opts: [
        `Copy-pasting identical blocks of code across 50 different files`,
        `Abstracting common logic into reusable components, utility libraries, or shared services`,
        `Creating circular dependencies between unrelated submodules`,
        `Disabling import and export statements entirely`
      ],
      c: 1,
    },
    {
      q: `What is the role of continuous integration (CI) pipelines when developing projects with "${skillName}"?`,
      opts: [
        `Automatically deploying unverified code to production on every keystroke`,
        `Automating build verification, lint checks, test suites, and security scans on pull requests`,
        `Deleting git history periodically to save disk space`,
        `Bypassing code reviews and branching strategies`
      ],
      c: 1,
    },
    {
      q: `How should sensitive API keys and database credentials be configured in a "${skillName}" application?`,
      opts: [
        `Hardcoding keys in public GitHub repositories and client bundles`,
        `Injecting credentials via secure environment variables and server secrets managers`,
        `Writing API keys in clear text inside README files`,
        `Sending keys via unencrypted HTTP query parameters`
      ],
      c: 1,
    },
    {
      q: `Which data serialization standard is most widely used for exchanging information between "${skillName}" and web clients?`,
      opts: [
        `Binary raw machine assembly code`,
        `Standard JSON (JavaScript Object Notation) or Protocol Buffers`,
        `Unformatted text paragraphs with no structure`,
        `Proprietary encrypted floppy disk formats`
      ],
      c: 1,
    },
    {
      q: `What is the recommended Git branching strategy when collaborating on "${skillName}" features?`,
      opts: [
        `Pushing directly to the main production branch without pull requests or reviews`,
        `Short-lived feature branches with descriptive names and peer code reviews before merging`,
        `Keeping changes on a local machine without committing for six months`,
        `Overwriting teammate commits with force-push commands daily`
      ],
      c: 1,
    },
    {
      q: `How does memory management and garbage collection behave in modern "${skillName}" runtimes?`,
      opts: [
        `Allocating memory continuously until physical RAM crashes with an out-of-memory error`,
        `Automatically tracing object reachability and reclaiming unreferenced memory buffers`,
        `Requiring manual hardware solder changes on physical RAM chips`,
        `Memory management is not supported by computer operating systems`
      ],
      c: 1,
    },
    {
      q: `What design pattern is most commonly used in "${skillName}" to decouple consumers from object creation?`,
      opts: [
        `Spaghetti Code Pattern`,
        `Factory, Dependency Injection, or Provider Patterns`,
        `Hardcoded Static Instance Pattern`,
        `Global Mutable Variable Pattern`
      ],
      c: 1,
    },
    {
      q: `When scaling "${skillName}" to support millions of concurrent users, what horizontal strategy is preferred?`,
      opts: [
        `Running on a single oversized hardware machine with no redundancy`,
        `Stateless microservices behind load balancers with auto-scaling container groups`,
        `Limiting application usage to one user at a time`,
        `Disabling database indexing to reduce CPU usage`
      ],
      c: 1,
    },
    {
      q: `What is the primary purpose of code linters and formatters (like ESLint, Prettier, or Black) in "${skillName}"?`,
      opts: [
        `To intentionally change the algorithmic complexity of functions`,
        `To enforce consistent style guides, catch syntax errors early, and improve readability`,
        `To encrypt source code before uploading to version control`,
        `To prevent code from compiling on other operating systems`
      ],
      c: 1,
    },
    {
      q: `What milestone best certifies that a developer has attained genuine mastery in "${skillName}"?`,
      opts: [
        `Memorizing cheat sheets without ever building real-world projects`,
        `Building, testing, debugging, and deploying production-ready systems independently with high quality`,
        `Copying code without understanding underlying architecture or trade-offs`,
        `Refusing to follow documentation and established standards`
      ],
      c: 1,
    },
  ];

  return baseTemplates.map((t, index) => ({
    id: index + 1,
    question: t.q,
    options: t.opts,
    correctIndex: t.c,
  }));
}

export const SkillAddModal: React.FC<Props> = ({
  isOpen,
  onClose,
  type,
  goalName = 'Software Engineering',
  onAddAchievedSkill,
  onAddMissingSkill,
}) => {
  const [skillName, setSkillName] = useState('');
  const [description, setDescription] = useState('');
  const [step, setStep] = useState<'input' | 'scanning' | 'quiz' | 'quiz_result' | 'missing_confirm'>('input');
  
  // Scanning state
  const [scanProgress, setScanProgress] = useState(0);
  const [scanStepText, setScanStepText] = useState('Initializing AI Bot Scanner...');
  
  // Quiz state (for achieved skill)
  const [questions, setQuestions] = useState<Question[]>([]);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [score, setScore] = useState<number>(0);

  // Missing skill options
  const [priority, setPriority] = useState<'Normal' | 'High' | 'Self-Paced'>('Self-Paced');

  // Reset modal state when opened
  useEffect(() => {
    if (isOpen) {
      setSkillName('');
      setDescription('');
      setStep('input');
      setScanProgress(0);
      setSelectedAnswers({});
      setScore(0);
    }
  }, [isOpen, type]);

  if (!isOpen) return null;

  // Handle start scan
  const handleStartScan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!skillName.trim()) return;

    setStep('scanning');
    setScanProgress(10);
    setScanStepText(`Analyzing technical taxonomy for "${skillName}"...`);

    // Dynamic scanning animation phases
    const timer1 = setTimeout(() => {
      setScanProgress(45);
      setScanStepText(
        type === 'achieved'
          ? `Evaluating competency depth & difficulty tier for "${skillName}"...`
          : `Benchmarking "${skillName}" against primary goal roadmap...`
      );
    }, 600);

    const timer2 = setTimeout(() => {
      setScanProgress(80);
      setScanStepText(
        type === 'achieved'
          ? `Generating 20 skill verification questions to test genuine mastery...`
          : `Classifying as "Additional Skill (Outside Main Goal)"...`
      );
    }, 1200);

    const timer3 = setTimeout(() => {
      setScanProgress(100);
      if (type === 'achieved') {
        const qList = getQuestionsForSkill(skillName);
        setQuestions(qList);
        setSelectedAnswers({});
        setStep('quiz');
      } else {
        setStep('missing_confirm');
      }
    }, 1800);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  };

  // Submit quiz answers
  const handleSubmitQuiz = () => {
    let correctCount = 0;
    questions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctIndex) {
        correctCount += 1;
      }
    });
    setScore(correctCount);
    setStep('quiz_result');
  };

  // Confirm adding achieved skill
  const handleConfirmAchieved = () => {
    const finalDesc = description.trim() || `Verified proficiency in ${skillName} through 20-question AI Bot assessment test.`;
    const newSkill: SkillItem = {
      id: 'custom_achieved_' + Date.now(),
      title: skillName.trim(),
      description: finalDesc,
      level: score >= 18 ? '100%' : score >= 16 ? '95%' : '85%',
      badge: score >= 18 ? 'AI Mastered' : 'AI Verified',
      isAiVerified: true,
      score: `${score}/${questions.length}`,
      verifiedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    };

    onAddAchievedSkill(newSkill);
    onClose();
  };

  // Confirm adding missing skill (as Additional Skill outside main goal)
  const handleConfirmMissing = () => {
    const finalDesc = description.trim() || `Self-paced additional skill in ${skillName} queued for extra learning.`;
    const newSkill: SkillItem = {
      id: 'custom_missing_' + Date.now(),
      title: skillName.trim(),
      description: finalDesc,
      status: `Queued (${priority})`,
      progress: '0%',
      badge: 'Additional Skill',
      isAdditional: true, // Marked as outside main goal!
    };

    onAddMissingSkill(newSkill);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden relative animate-in zoom-in-95 flex flex-col max-h-[92vh]">
        
        {/* Top Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-slate-50 via-white to-slate-50 dark:from-slate-900 dark:via-slate-900/90 dark:to-slate-900">
          <div className="flex items-center gap-2.5">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
              type === 'achieved' 
                ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800' 
                : 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800'
            }`}>
              {type === 'achieved' ? <Award size={20} /> : <Target size={20} />}
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900 dark:text-white">
                {type === 'achieved' ? 'Add Achieved Skill' : 'Add Missing Skill'}
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                <Sparkles size={11} className="text-amber-500" />
                {type === 'achieved' ? 'AI Bot Skill Verification Quiz' : 'Additional Skill (Outside Main Goal)'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">

          {/* STEP 1: INPUT */}
          {step === 'input' && (
            <form onSubmit={handleStartScan} className="space-y-5">
              {/* Context Pill */}
              <div className={`p-3.5 rounded-2xl border text-xs leading-relaxed ${
                type === 'achieved'
                  ? 'bg-emerald-50/70 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/60 text-emerald-800 dark:text-emerald-300'
                  : 'bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800/60 text-indigo-800 dark:text-indigo-300'
              }`}>
                {type === 'achieved' ? (
                  <div className="flex gap-2">
                    <ShieldCheck size={18} className="text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">AI Skill Verification System:</span> Enter the skill you have mastered. Our AI Bot will run a quick scan and present a 3-question quiz to verify that you genuinely possess this skill!
                    </div>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <Info size={18} className="text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">Additional Skill Registration:</span> Missing skills added here are categorized as <span className="font-black underline">Additional Skills</span>. They are for your independent self-learning and <span className="font-bold">will NOT count towards or alter your main goal ({goalName})</span>!
                    </div>
                  </div>
                )}
              </div>

              {/* Skill Name Input */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Skill Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={skillName}
                    onChange={(e) => setSkillName(e.target.value)}
                    placeholder="e.g. React.js, TypeScript, SQL, Docker, Python..."
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500 shadow-sm"
                    autoFocus
                    required
                  />
                  {skillName && (
                    <button
                      type="button"
                      onClick={() => setSkillName('')}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    >
                      <X size={15} />
                    </button>
                  )}
                </div>
              </div>

              {/* Quick Suggestion Chips */}
              <div className="space-y-2">
                <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  Popular Tech Suggestions:
                </span>
                <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
                  {POPULAR_SKILLS.map((sk) => (
                    <button
                      key={sk}
                      type="button"
                      onClick={() => setSkillName(sk)}
                      className={`text-xs px-2.5 py-1.5 rounded-xl border transition-all text-left flex items-center gap-1 ${
                        skillName.toLowerCase() === sk.toLowerCase()
                          ? 'bg-sky-600 text-white border-sky-600 shadow-sm'
                          : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <Plus size={11} className="opacity-70" />
                      <span>{sk}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Optional Description */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Brief Overview <span className="text-slate-400 text-[10px] font-normal">(Optional)</span>
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={
                    type === 'achieved'
                      ? 'What practical experience do you have with this skill?'
                      : 'Why do you want to learn this additional skill?'
                  }
                  rows={2}
                  className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500 resize-none shadow-sm"
                />
              </div>

              {/* Action Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={!skillName.trim()}
                  className={`w-full py-3.5 px-4 rounded-2xl font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-2 active:scale-98 ${
                    !skillName.trim()
                      ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                      : type === 'achieved'
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-500/20'
                      : 'bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 text-white shadow-indigo-500/20'
                  }`}
                >
                  <Bot size={16} />
                  <span>
                    {type === 'achieved'
                      ? 'Scan with AI Bot & Open Verification Quiz'
                      : 'Scan with AI Bot & Register Additional Skill'}
                  </span>
                  <ArrowRight size={14} />
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: AI BOT SCANNING */}
          {step === 'scanning' && (
            <div className="py-8 px-4 flex flex-col items-center justify-center text-center space-y-6 animate-in fade-in">
              {/* Bot Avatar with Radar Scan effect */}
              <div className="relative">
                {/* Rotating scanner ring */}
                <div className="absolute -inset-4 rounded-full border-2 border-dashed border-sky-400 dark:border-sky-500 animate-spin" style={{ animationDuration: '6s' }} />
                <div className="absolute -inset-2 rounded-full bg-sky-500/20 dark:bg-sky-400/20 animate-ping" style={{ animationDuration: '2s' }} />
                
                {/* Robot Head */}
                <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border-2 border-sky-400/80 shadow-xl shadow-sky-500/20 flex flex-col items-center justify-center relative overflow-hidden">
                  {/* Glowing Antenna */}
                  <div className="absolute top-1.5 w-2 h-2 rounded-full bg-cyan-400 shadow-sm shadow-cyan-300 animate-pulse" />
                  
                  {/* Visor / Eye Display */}
                  <div className="w-16 h-8 rounded-xl bg-slate-950/90 border border-cyan-500/40 flex items-center justify-center gap-3 px-2 shadow-inner">
                    <div className="w-3.5 h-3.5 rounded-full bg-cyan-400 shadow-sm shadow-cyan-300 animate-pulse" />
                    <div className="w-3.5 h-3.5 rounded-full bg-cyan-400 shadow-sm shadow-cyan-300 animate-pulse" />
                  </div>

                  {/* Tech status bar */}
                  <div className="mt-2 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    <span className="text-[8px] font-mono font-bold tracking-widest text-cyan-300 uppercase">SCANNING</span>
                  </div>

                  {/* Horizontal Scan Beam Line */}
                  <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-bounce opacity-75" />
                </div>
              </div>

              {/* Scanning Status Text */}
              <div className="space-y-2 max-w-sm">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-100 dark:bg-sky-950/70 border border-sky-200 dark:border-sky-800 text-[11px] font-bold text-sky-700 dark:text-sky-300">
                  <Zap size={12} className="text-amber-500 animate-pulse" />
                  <span>AI Bot Deep Engine Active</span>
                </div>
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  Scanning Competency: <span className="text-sky-600 dark:text-sky-400">{skillName}</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                  {scanStepText}
                </p>
              </div>

              {/* Progress Bar */}
              <div className="w-full max-w-xs space-y-1.5">
                <div className="w-full h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden p-0.5 border border-slate-200 dark:border-slate-700">
                  <div 
                    className="h-full rounded-full bg-gradient-to-r from-sky-500 to-indigo-600 transition-all duration-300 shadow-sm"
                    style={{ width: `${scanProgress}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] font-mono text-slate-400">
                  <span>AI Verification Engine</span>
                  <span className="font-bold text-sky-600 dark:text-sky-400">{scanProgress}%</span>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: QUIZ (For Achieved Skill Verification - 20 QUESTIONS) */}
          {step === 'quiz' && (
            <div className="space-y-4 animate-in fade-in">
              {/* Quiz Banner */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-500/10 to-sky-500/10 border border-emerald-200/60 dark:border-emerald-800/60 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-emerald-500 text-white shrink-0 shadow-sm">
                  <HelpCircle size={18} />
                </div>
                <div className="flex-1">
                  <h4 className="text-xs font-black text-slate-900 dark:text-white">
                    AI Bot 20-Question Competency Check
                  </h4>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
                    Please answer the 20 technical questions below for <span className="font-bold text-slate-900 dark:text-white">{skillName}</span>. To qualify as an <span className="font-bold text-emerald-600 dark:text-emerald-400">AI Verified Achieved Skill</span>, you need to score at least 14 out of 20 (70%).
                  </p>
                </div>
              </div>

              {/* Question Navigator Bar with 20 Pills + Demo Fill */}
              <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <span>Questions Overview (1 - 20):</span>
                    <span className="text-sky-600 dark:text-sky-400 font-black">
                      {Object.keys(selectedAnswers).length} / {questions.length} Answered
                    </span>
                  </span>

                  <button
                    type="button"
                    onClick={() => {
                      const allAnswers: Record<number, number> = {};
                      questions.forEach(q => {
                        allAnswers[q.id] = q.correctIndex;
                      });
                      setSelectedAnswers(allAnswers);
                    }}
                    className="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-900 border border-sky-300 dark:border-sky-800 text-sky-700 dark:text-sky-300 text-[10px] font-bold flex items-center gap-1 shadow-xs hover:bg-sky-50 active:scale-95 transition-all cursor-pointer"
                    title="Quickly fill all 20 questions with verified answers for demo testing"
                  >
                    <Zap size={11} className="text-amber-500 fill-amber-500" />
                    <span>Quick Fill All 20 (Demo)</span>
                  </button>
                </div>

                {/* 20 Pill Grid */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  {questions.map((q, idx) => {
                    const isAnswered = selectedAnswers[q.id] !== undefined;
                    return (
                      <button
                        key={q.id}
                        type="button"
                        onClick={() => {
                          const el = document.getElementById(`q-item-${q.id}`);
                          if (el) {
                            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                          }
                        }}
                        className={`w-6 h-6 rounded-lg text-[10px] font-bold transition-all flex items-center justify-center border cursor-pointer ${
                          isAnswered
                            ? 'bg-emerald-500 text-white border-emerald-600 shadow-xs'
                            : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border-slate-300 dark:border-slate-700 hover:border-sky-400'
                        }`}
                        title={`Jump to Question ${idx + 1}`}
                      >
                        {idx + 1}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Questions List (All 20 Questions) */}
              <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-1">
                {questions.map((q, qIndex) => (
                  <div 
                    id={`q-item-${q.id}`}
                    key={q.id}
                    className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs"
                  >
                    <div className="flex items-start gap-2">
                      <span className="px-2 py-0.5 rounded-lg bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-black text-[11px] shrink-0 mt-0.5">
                        Q{qIndex + 1} of 20
                      </span>
                      <p className="text-xs font-bold text-slate-900 dark:text-white leading-relaxed">
                        {q.question}
                      </p>
                    </div>

                    {/* Options */}
                    <div className="space-y-2 pl-1">
                      {q.options.map((opt, optIndex) => {
                        const isSelected = selectedAnswers[q.id] === optIndex;
                        return (
                          <button
                            key={optIndex}
                            type="button"
                            onClick={() => setSelectedAnswers(prev => ({ ...prev, [q.id]: optIndex }))}
                            className={`w-full p-2.5 rounded-xl text-left text-xs transition-all flex items-center justify-between border cursor-pointer ${
                              isSelected
                                ? 'bg-sky-50 dark:bg-sky-950/60 border-sky-500 text-sky-900 dark:text-sky-200 font-bold shadow-sm'
                                : 'bg-white dark:bg-slate-900/80 hover:bg-slate-100 dark:hover:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                            }`}
                          >
                            <span className="flex-1 pr-2">{opt}</span>
                            <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                              isSelected 
                                ? 'border-sky-500 bg-sky-500 text-white' 
                                : 'border-slate-300 dark:border-slate-600'
                            }`}>
                              {isSelected && <Check size={10} strokeWidth={3} />}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>

              {/* Submit Quiz Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleSubmitQuiz}
                  disabled={Object.keys(selectedAnswers).length === 0}
                  className={`w-full py-3.5 px-4 rounded-2xl font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-2 active:scale-98 ${
                    Object.keys(selectedAnswers).length === 0
                      ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-500/25 cursor-pointer'
                  }`}
                >
                  <CheckCheck size={16} />
                  <span>
                    Submit 20 Answers & Calculate AI Score ({Object.keys(selectedAnswers).length}/{questions.length} answered)
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: QUIZ RESULT (Pass / Fail) */}
          {step === 'quiz_result' && (
            <div className="py-6 px-3 flex flex-col items-center justify-center text-center space-y-5 animate-in fade-in">
              {score >= 14 ? (
                <>
                  {/* Pass Visual */}
                  <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-xl shadow-emerald-500/30 animate-bounce">
                    <CheckCircle2 size={44} />
                  </div>

                  <div className="space-y-1.5">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 border border-emerald-200 dark:border-emerald-800 text-xs font-bold text-emerald-700 dark:text-emerald-300">
                      <Sparkles size={12} />
                      <span>AI Verification Passed! ({Math.round((score / 20) * 100)}%)</span>
                    </div>
                    <h3 className="text-xl font-black text-slate-900 dark:text-white">
                      Skill Authenticated: {skillName}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-medium max-w-sm">
                      Outstanding performance! You answered <span className="font-bold text-emerald-600 dark:text-emerald-400">{score} of {questions.length} questions correctly</span>. Your skill is verified and confirmed.
                    </p>
                  </div>

                  {/* Verification Pill Card */}
                  <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-left w-full space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200">{skillName}</span>
                      <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-emerald-200 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200">
                        {score >= 18 ? '100% Tested' : '85% Tested'}
                      </span>
                    </div>
                    <p className="text-[11px] text-emerald-700 dark:text-emerald-300">
                      Badge: AI Verified Mastered | Scored {score}/{questions.length} | Verified on {new Date().toLocaleDateString()}
                    </p>
                  </div>

                  {/* Confirm Button */}
                  <div className="w-full pt-2">
                    <button
                      type="button"
                      onClick={handleConfirmAchieved}
                      className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-lg shadow-emerald-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Award size={16} />
                      <span>Save & Add to Achieved Skills</span>
                    </button>
                  </div>
                </>
              ) : (
                <>
                  {/* Needs Practice Visual */}
                  <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-amber-500 to-orange-600 text-white flex items-center justify-center shadow-xl shadow-amber-500/30">
                    <AlertCircle size={40} />
                  </div>

                  <div className="space-y-1.5">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 text-xs font-bold text-amber-700 dark:text-amber-300">
                      <span>Score: {score} / {questions.length} Correct ({Math.round((score / 20) * 100)}%)</span>
                    </div>
                    <h3 className="text-lg font-black text-slate-900 dark:text-white">
                      Practice Needed in {skillName}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-medium max-w-sm">
                      You need at least 14 correct answers (70%) out of 20 to achieve verified status. You can retry the quiz or add it to your Missing Skills queue to learn and practice first!
                    </p>
                  </div>

                  {/* Dual Action Options */}
                  <div className="w-full space-y-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedAnswers({});
                        setStep('quiz');
                      }}
                      className="w-full py-3 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-md shadow-sky-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <RotateCcw size={15} />
                      <span>Retry Verification Quiz</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        // Switch to adding as missing skill
                        setStep('missing_confirm');
                      }}
                      className="w-full py-3 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 font-bold text-xs hover:bg-amber-100 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Target size={15} />
                      <span>Add as Additional Missing Skill to Learn</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          )}

          {/* STEP 5: MISSING SKILL CONFIRMATION (Categorized as Additional Skill) */}
          {step === 'missing_confirm' && (
            <div className="space-y-5 animate-in fade-in">
              {/* Bot Recommendation Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-50 via-sky-50 to-indigo-50 dark:from-indigo-950/50 dark:via-slate-900 dark:to-indigo-950/50 border-2 border-indigo-200 dark:border-indigo-800 shadow-sm space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-600/30 shrink-0">
                    <Bot size={20} />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 uppercase tracking-wider">
                      AI Bot Classification
                    </span>
                    <h3 className="text-base font-black text-slate-900 dark:text-white mt-0.5">
                      {skillName}
                    </h3>
                  </div>
                </div>

                {/* Clear Special Notice: Outside Goal Rule */}
                <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-indigo-100 dark:border-indigo-900/60 text-xs text-slate-700 dark:text-slate-300 space-y-2 shadow-inner">
                  <div className="flex items-center gap-2 font-bold text-indigo-700 dark:text-indigo-400">
                    <ShieldCheck size={16} />
                    <span>Special Rule: Additional Skill (अतिरिक्त कौशल्य)</span>
                  </div>
                  <p className="leading-relaxed text-[11px] text-slate-600 dark:text-slate-300">
                    This skill is registered as an <span className="font-bold text-indigo-600 dark:text-indigo-400">Additional Skill</span> for your supplementary self-learning.
                  </p>
                  <div className="p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-[11px] text-amber-800 dark:text-amber-300 font-medium">
                    📌 <strong>Goal Scope Notice:</strong> This skill <span className="font-bold underline">will NOT be counted</span> into your primary career goal ({goalName}) roadmap calculation. You can learn it independently at your own pace without any pressure!
                  </div>
                </div>
              </div>

              {/* Learning Priority Selector */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Select Learning Preference:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Self-Paced', 'Normal', 'High'] as const).map((pr) => (
                    <button
                      key={pr}
                      type="button"
                      onClick={() => setPriority(pr)}
                      className={`p-2.5 rounded-xl text-xs font-bold border transition-all text-center ${
                        priority === pr
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {pr}
                    </button>
                  ))}
                </div>
              </div>

              {/* Confirm Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleConfirmMissing}
                  className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 text-white font-bold text-xs shadow-lg shadow-indigo-500/25 transition-all flex items-center justify-center gap-2 active:scale-98"
                >
                  <Plus size={16} />
                  <span>Confirm & Add as Additional Skill</span>
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Modal Bottom Status Bar */}
        <div className="p-3 bg-slate-50 dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between px-6">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            AI Bot Assistant Online
          </span>
          {step === 'quiz' && (
            <span className="font-mono font-bold text-sky-600 dark:text-sky-400">
              3 Questions
            </span>
          )}
          {step === 'input' && (
            <span className="text-slate-400">Instant AI Scan Ready</span>
          )}
        </div>

      </div>
    </div>
  );
};
