import React, { useState } from 'react';
import { TaskItem } from '../types';
import { X, CheckCircle2, Circle, Clock, BookOpen, ArrowRight } from 'lucide-react';

interface Props {
  task: TaskItem | null;
  onClose: () => void;
  onToggleComplete: (id: string) => void;
}

export const TaskModal: React.FC<Props> = ({ task, onClose, onToggleComplete }) => {
  if (!task) return null;
  const [submitting, setSubmitting] = useState(false);

  const handleComplete = () => {
    setSubmitting(true);
    setTimeout(() => {
      onToggleComplete(task.id);
      setSubmitting(false);
      onClose();
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 dark:border-slate-800 p-6 relative animate-in zoom-in-95">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 rounded-2xl bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400">
            <BookOpen size={24} />
          </div>
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-sky-600 dark:text-sky-400">
              {task.category}
            </span>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">{task.title}</h3>
          </div>
        </div>

        <p className="text-sm text-slate-600 dark:text-slate-300 mb-6 leading-relaxed">
          {task.description}
        </p>

        {task.details && (
          <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl mb-6 border border-slate-100 dark:border-slate-800">
            <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Detailed Instructions</h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal">{task.details}</p>
          </div>
        )}

        <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <Clock size={14} />
            <span>{task.duration || '20 mins'}</span>
          </div>

          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              Close
            </button>
            <button
              onClick={handleComplete}
              disabled={submitting}
              className={`px-4 py-2 rounded-xl text-xs font-medium text-white flex items-center gap-2 transition-all ${
                task.completed
                  ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20'
                  : 'bg-sky-600 hover:bg-sky-700 shadow-sky-600/20'
              } shadow-lg`}
            >
              {task.completed ? (
                <>
                  <CheckCircle2 size={16} /> Completed
                </>
              ) : (
                <>
                  Mark Complete <ArrowRight size={14} />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
