import React, { useState } from 'react';
import { 
  Sliders, 
  ChevronRight, 
  ChevronLeft, 
  SkipForward, 
  X, 
  Minus, 
  Layers, 
  Sparkles,
  Tv,
  Bell
} from 'lucide-react';
import { 
  sendTaskReminderNotification, 
  requestNotificationPermission, 
  getNotificationPermission 
} from '../utils/notification';

export type DemoScreenKey =
  | 'login'
  | 'signup'
  | 'onboarding_1'
  | 'onboarding_2'
  | 'onboarding_3'
  | 'onboarding_4'
  | 'onboarding_5'
  | 'onboarding_6'
  | 'onboarding_7'
  | 'onboarding_8'
  | 'onboarding_9'
  | 'tab_home'
  | 'tab_pathway'
  | 'tab_progress'
  | 'tab_assess'
  | 'tab_profile'
  | 'tab_aibot';

export interface DemoScreenItem {
  key: DemoScreenKey;
  label: string;
  category: 'Auth' | 'Onboarding' | 'Dashboard';
}

export const DEMO_SCREENS: DemoScreenItem[] = [
  { key: 'login', label: 'Login Screen', category: 'Auth' },
  { key: 'signup', label: 'Sign Up / Create Account', category: 'Auth' },
  { key: 'onboarding_1', label: 'Step 1: Profile & Age Auto-calc', category: 'Onboarding' },
  { key: 'onboarding_2', label: 'Step 2: Goal Decision (AI vs Self)', category: 'Onboarding' },
  { key: 'onboarding_3', label: 'Step 3: AI Scanner & Verification', category: 'Onboarding' },
  { key: 'onboarding_4', label: 'Step 4: Questions Slider & Bot', category: 'Onboarding' },
  { key: 'onboarding_5', label: 'Step 5: Question Gameplay Challenges', category: 'Onboarding' },
  { key: 'onboarding_6', label: 'Step 6: Calculation & Score Results', category: 'Onboarding' },
  { key: 'onboarding_7', label: 'Step 7: 10 AI Recommended Goals', category: 'Onboarding' },
  { key: 'onboarding_8', label: 'Step 8: Achieved & Missing Skills', category: 'Onboarding' },
  { key: 'onboarding_9', label: 'Step 9: Generated Student ID Card', category: 'Onboarding' },
  { key: 'tab_home', label: 'Home Dashboard', category: 'Dashboard' },
  { key: 'tab_pathway', label: 'Pathway / Career Goals', category: 'Dashboard' },
  { key: 'tab_progress', label: 'Progress & Skill Stats', category: 'Dashboard' },
  { key: 'tab_assess', label: 'Assess & Quizzes', category: 'Dashboard' },
  { key: 'tab_profile', label: 'Profile & Student Pass', category: 'Dashboard' },
];

interface DemoWindowProps {
  currentScreen: DemoScreenKey;
  onNavigate: (screenKey: DemoScreenKey) => void;
  onNext: () => void;
  onBack: () => void;
  onSkip: () => void;
  onClose: () => void;
  language?: 'en' | 'mr' | 'hi';
}

export const DemoWindow: React.FC<DemoWindowProps> = ({
  currentScreen,
  onNavigate,
  onNext,
  onBack,
  onSkip,
  onClose,
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(true);
  const [testFeedback, setTestFeedback] = useState<string | null>(null);

  const handleTriggerTestNotification = async () => {
    let perm = getNotificationPermission();
    if (perm === 'default') {
      perm = await requestNotificationPermission();
    }
    const res = sendTaskReminderNotification({
      title: '⚠️ Daily Task Incomplete Reminder!',
      body: 'Your daily tasks are incomplete. Spend 15 minutes to finish them and stay on track!',
    });
    if (res.success) {
      setTestFeedback('🔔 Test notification sent to device!');
    } else if (res.reason === 'denied') {
      setTestFeedback('⚠️ Notifications blocked in browser.');
    } else {
      setTestFeedback('🔔 Notification triggered! (Chime played)');
    }
    setTimeout(() => setTestFeedback(null), 3500);
  };

  // Find index in screen list
  const currentIndex = DEMO_SCREENS.findIndex(s => s.key === currentScreen);
  const currentItem = DEMO_SCREENS[currentIndex] || DEMO_SCREENS[0];

  return (
    <div className="fixed z-[9999] pointer-events-auto select-none">
      {/* 1. BUBBLE ICON (When window is collapsed or floating) */}
      {!isOpen && (
        <div className="fixed bottom-20 right-4 sm:bottom-6 sm:right-6 animate-in zoom-in-75 duration-200">
          <button
            type="button"
            onClick={() => setIsOpen(true)}
            title="Open Demo Window"
            className="group relative flex items-center gap-2 p-3.5 rounded-full bg-gradient-to-tr from-sky-600 via-indigo-600 to-cyan-500 text-white shadow-[0_0_25px_rgba(56,189,248,0.55)] border-2 border-white/60 hover:scale-105 active:scale-95 transition-all cursor-pointer"
          >
            {/* Pulsing Outer Ring */}
            <span className="absolute -inset-1 rounded-full bg-cyan-400/40 animate-ping opacity-60 pointer-events-none" />

            {/* Bubble Icon */}
            <div className="relative flex items-center justify-center">
              <Sliders size={22} className="group-hover:rotate-45 transition-transform duration-300" />
            </div>

            {/* Floating label */}
            <span className="text-xs font-black tracking-wide pr-1 hidden sm:inline">
              Demo Window
            </span>

            {/* Small status indicator badge */}
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-slate-900 absolute top-0 right-0 shadow" />
          </button>
        </div>
      )}

      {/* 2. DEMO WINDOW (Small compact floating window - 'Choti Vino') */}
      {isOpen && (
        <div className="fixed bottom-20 right-4 sm:bottom-6 sm:right-6 w-[320px] sm:w-[350px] bg-slate-900/95 backdrop-blur-2xl text-white rounded-3xl border border-sky-500/40 shadow-[0_20px_50px_rgba(0,0,0,0.65),0_0_30px_rgba(56,189,248,0.25)] p-4 space-y-3.5 animate-in slide-in-from-bottom-5 zoom-in-95 duration-200">
          {/* Window Header */}
          <div className="flex items-center justify-between pb-2.5 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-sm shadow-sky-500/40">
                <Sliders size={15} />
              </div>
              <div>
                <h3 className="text-xs font-black tracking-wide text-white flex items-center gap-1.5">
                  <span>Demo Window</span>
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-sky-500/20 text-sky-300 border border-sky-400/30">
                    LIVE
                  </span>
                </h3>
                <span className="text-[10px] text-slate-400 block leading-tight">
                  Screen Navigator Mode
                </span>
              </div>
            </div>

            {/* Minimize to Bubble & Close */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                title="Minimize to Bubble"
                className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <Minus size={14} />
              </button>
              <button
                type="button"
                onClick={onClose}
                title="Close Demo Window"
                className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 transition-colors cursor-pointer"
              >
                <X size={14} />
              </button>
            </div>
          </div>

          {/* Current Screen Indicator */}
          <div className="px-3 py-2 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between text-[11px]">
            <span className="text-slate-400 flex items-center gap-1">
              <Tv size={12} className="text-sky-400" />
              <span>Current:</span>
            </span>
            <span className="font-bold text-sky-300 truncate max-w-[180px]">
              {currentItem.label}
            </span>
          </div>

          {/* Screen Selector Dropdown */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <Layers size={12} className="text-cyan-400" />
                <span>Screen:</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                {currentIndex + 1} of {DEMO_SCREENS.length}
              </span>
            </label>
            <div className="relative">
              <select
                value={currentScreen}
                onChange={(e) => onNavigate(e.target.value as DemoScreenKey)}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-950 border border-sky-500/30 text-white text-xs font-semibold focus:outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400 cursor-pointer appearance-none pr-8"
              >
                <optgroup label="Authentication & Sign In">
                  {DEMO_SCREENS.filter(s => s.category === 'Auth').map(s => (
                    <option key={s.key} value={s.key} className="bg-slate-900 text-white">
                      {s.label}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="Onboarding Steps (1 to 9)">
                  {DEMO_SCREENS.filter(s => s.category === 'Onboarding').map(s => (
                    <option key={s.key} value={s.key} className="bg-slate-900 text-white">
                      {s.label}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="Main App Dashboard Tabs">
                  {DEMO_SCREENS.filter(s => s.category === 'Dashboard').map(s => (
                    <option key={s.key} value={s.key} className="bg-slate-900 text-white">
                      {s.label}
                    </option>
                  ))}
                </optgroup>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2.5 text-slate-400">
                <ChevronRight size={14} className="rotate-90" />
              </div>
            </div>
          </div>

          {/* Navigation Action Buttons: Back, Next, Skip */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            {/* BACK BUTTON */}
            <button
              type="button"
              onClick={onBack}
              disabled={currentIndex <= 0}
              className="py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 hover:text-white font-bold text-xs flex items-center justify-center gap-1 border border-slate-700/80 transition-all cursor-pointer disabled:cursor-not-allowed"
            >
              <ChevronLeft size={15} />
              <span>Back</span>
            </button>

            {/* NEXT BUTTON */}
            <button
              type="button"
              onClick={onNext}
              disabled={currentIndex >= DEMO_SCREENS.length - 1}
              className="py-2.5 px-2 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-md shadow-sky-600/30 border border-sky-400/40 transition-all cursor-pointer disabled:cursor-not-allowed"
            >
              <span>Next</span>
              <ChevronRight size={15} />
            </button>

            {/* SKIP BUTTON */}
            <button
              type="button"
              onClick={onSkip}
              className="py-2.5 px-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-1 shadow-md shadow-amber-500/20 transition-all cursor-pointer"
            >
              <SkipForward size={14} />
              <span>Skip</span>
            </button>
          </div>

          {/* Test Reminder Notification Action */}
          <div className="pt-2 border-t border-slate-800/80 space-y-1">
            <button
              type="button"
              onClick={handleTriggerTestNotification}
              className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-amber-500/20 via-orange-500/25 to-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-300 font-extrabold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-sm"
            >
              <Bell size={13} className="text-amber-400" />
              <span>Test Reminder Notification 🔔</span>
            </button>
            {testFeedback && (
              <p className="text-[10px] text-center text-amber-300 font-semibold animate-in fade-in">
                {testFeedback}
              </p>
            )}
          </div>

          {/* Quick Info & Hint */}
          <div className="pt-1 flex items-center justify-between text-[10px] text-slate-400 border-t border-slate-800/80">
            <span className="flex items-center gap-1">
              <Sparkles size={11} className="text-amber-400" />
              <span>Demo Nav Active</span>
            </span>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="text-sky-400 hover:underline cursor-pointer"
            >
              Collapse to Bubble
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
