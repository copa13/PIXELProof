import React, { useState } from 'react';
import { 
  Bell, 
  Moon, 
  Sun, 
  User as UserIcon, 
  ArrowLeft, 
  Globe, 
  Settings, 
  X, 
  CheckCircle2, 
  Type, 
  Sliders, 
  Clock, 
  Smartphone, 
  Sparkles,
  BookOpen,
  Palette,
  Check
} from 'lucide-react';
import { NotificationItem, UserProfile, TabType, IconColorKey, BgColorKey } from '../types';
import { 
  sendTaskReminderNotification, 
  requestNotificationPermission, 
  getNotificationPermission 
} from '../utils/notification';
import { ICON_COLORS, BG_COLORS, getIconColorDef, getBgColorDef } from '../utils/theme';
import { translations } from '../translations';

interface Props {
  profile: UserProfile;
  notifications: NotificationItem[];
  onMarkNotificationRead: (id: string) => void;
  onUpdateProfile?: (profile: UserProfile) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  language: 'en' | 'mr' | 'hi';
  setLanguage: (lang: 'en' | 'mr' | 'hi') => void;
  fontSize: 'small' | 'medium' | 'large';
  setFontSize: (size: 'small' | 'medium' | 'large') => void;
  demoWindowEnabled?: boolean;
  setDemoWindowEnabled?: (val: boolean) => void;
  iconColor?: IconColorKey;
  setIconColor?: (val: IconColorKey) => void;
  bgColor?: BgColorKey;
  setBgColor?: (val: BgColorKey) => void;
  readingMode?: boolean;
  setReadingMode?: (val: boolean) => void;
}

export const Header: React.FC<Props> = ({
  profile,
  notifications,
  onMarkNotificationRead,
  onUpdateProfile,
  darkMode,
  setDarkMode,
  activeTab,
  setActiveTab,
  language,
  setLanguage,
  fontSize,
  setFontSize,
  demoWindowEnabled = false,
  setDemoWindowEnabled,
  iconColor = 'sky',
  setIconColor,
  bgColor = 'default',
  setBgColor,
  readingMode = false,
  setReadingMode,
}) => {
  const t = translations[language];
  const iconDef = getIconColorDef(iconColor);
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  const [showSettingsDrawer, setShowSettingsDrawer] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const unreadCount = notifications.filter(n => !n.read).length;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <>
      <header className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors relative">
        {/* Left side: Back Button (if not home) + Profile Pic followed by User Name */}
        <div className="flex items-center gap-2.5 z-10">
          {activeTab !== 'home' && (
            <button
              onClick={() => setActiveTab('home')}
              aria-label="Back to Home"
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors flex items-center gap-1.5 text-xs font-semibold mr-0.5"
            >
              <ArrowLeft size={18} />
              <span className="hidden sm:inline">{language === 'mr' ? 'होम' : 'Home'}</span>
            </button>
          )}

          <button
            onClick={() => setActiveTab('profile')}
            aria-label="Profile"
            className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-none"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-sky-600 to-indigo-600 text-white flex items-center justify-center font-bold text-sm shadow-md group-hover:ring-2 group-hover:ring-sky-400 transition-all border-2 border-white dark:border-slate-800 flex-shrink-0 overflow-hidden">
              {profile.avatarUrl ? (
                <img src={profile.avatarUrl} alt={profile.name} className="w-full h-full object-cover rounded-full" />
              ) : (
                profile.name ? profile.name.charAt(0).toUpperCase() : <UserIcon size={18} />
              )}
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-extrabold text-sm text-slate-900 dark:text-white leading-tight group-hover:text-sky-500 transition-colors max-w-[150px] sm:max-w-[240px] truncate">
                {profile.name || 'User'}
              </span>
              <div className="flex items-center gap-1.5 text-[11px] leading-tight truncate pt-0.5">
                <span className="font-bold text-sky-600 dark:text-sky-400">
                  {profile.studentId ? `ID: ${profile.studentId}` : 'ID: RIDER2026'}
                </span>
              </div>
            </div>
          </button>
        </div>

        {/* Right side: Notifications & Settings Icon */}
        <div className="flex items-center gap-2 relative">
          {/* Notifications Button */}
          <div className="relative">
            <button
              onClick={() => setShowNotificationModal(true)}
              aria-label="Notifications"
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors relative"
            >
              <Bell size={20} />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-sky-600 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>
          </div>

          {/* Settings Button */}
          <button
            onClick={() => setShowSettingsDrawer(true)}
            aria-label="Settings"
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Settings size={20} />
          </button>
        </div>
      </header>

      {/* Right Side 25% Settings Drawer */}
      {showSettingsDrawer && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/50 backdrop-blur-sm animate-in fade-in">
          <div className="w-full sm:w-80 md:w-96 bg-white dark:bg-slate-900 h-full shadow-2xl border-l border-slate-200 dark:border-slate-800 p-6 flex flex-col justify-between animate-in slide-in-from-right duration-300">
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <Settings size={18} /> Settings & Preferences
                </h3>
                <button
                  onClick={() => setShowSettingsDrawer(false)}
                  className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full"
                >
                  <X size={20} />
                </button>
              </div>

              {/* 1. Theme Mode (Day / Night / Reading Mode) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <Sun size={14} className={iconDef.tailwindText} />
                    <span>{t.theme || 'Theme & Mode'}</span>
                  </label>
                  {readingMode && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200 border border-amber-300 dark:border-amber-800 flex items-center gap-1">
                      <BookOpen size={10} /> {language === 'mr' ? 'वाचन मोड सक्रिय' : 'Reading Active'}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setReadingMode?.(false);
                      setDarkMode(false);
                      if (bgColor === 'sepia') setBgColor?.('default');
                    }}
                    className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl text-[11px] font-semibold transition-all cursor-pointer ${
                      !darkMode && !readingMode
                        ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-md ring-2 ring-sky-500/30'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <Sun size={15} className="mb-0.5 text-amber-500" />
                    <span>{t.dayMode || 'Day'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setReadingMode?.(false);
                      setDarkMode(true);
                      if (bgColor === 'sepia') setBgColor?.('default');
                    }}
                    className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl text-[11px] font-semibold transition-all cursor-pointer ${
                      darkMode && !readingMode
                        ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-md ring-2 ring-indigo-500/30'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <Moon size={15} className="mb-0.5 text-indigo-400" />
                    <span>{t.nightMode || 'Night'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setReadingMode?.(true);
                      setBgColor?.('sepia');
                    }}
                    className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl text-[11px] font-semibold transition-all cursor-pointer ${
                      readingMode
                        ? 'bg-amber-600 text-white shadow-md ring-2 ring-amber-400/50'
                        : 'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border border-amber-200/60 dark:border-amber-900/40 hover:bg-amber-100'
                    }`}
                  >
                    <BookOpen size={15} className="mb-0.5 text-amber-600 dark:text-amber-300" />
                    <span>{t.readingMode || 'Reading'}</span>
                  </button>
                </div>
              </div>

              {/* 2. Icon Color Selection (आयकॉन रंग निवडा) */}
              <div className="space-y-2 pt-1 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <Palette size={14} className={iconDef.tailwindText} />
                    <span>{t.iconColor || 'Icon Color (आयकॉन रंग)'}</span>
                  </label>
                  <span className="text-[10px] font-bold text-slate-400">
                    {language === 'mr' ? iconDef.nameMr : iconDef.nameEn}
                  </span>
                </div>

                <div className="grid grid-cols-5 gap-2">
                  {ICON_COLORS.map(c => {
                    const isSelected = iconColor === c.key;
                    return (
                      <button
                        key={c.key}
                        type="button"
                        onClick={() => {
                          setIconColor?.(c.key);
                          showToast(`${language === 'mr' ? 'आयकॉन रंग बदलला:' : 'Icon color updated:'} ${language === 'mr' ? c.nameMr : c.nameEn}`);
                        }}
                        title={language === 'mr' ? c.nameMr : c.nameEn}
                        className={`h-9 rounded-xl flex items-center justify-center transition-all cursor-pointer relative group ${
                          isSelected
                            ? 'ring-2 ring-offset-2 ring-offset-white dark:ring-offset-slate-900 shadow-sm scale-105'
                            : 'hover:scale-105 opacity-85 hover:opacity-100'
                        }`}
                        style={{ 
                          backgroundColor: c.hex,
                          boxShadow: isSelected ? `0 0 12px ${c.hex}80` : undefined
                        }}
                      >
                        {isSelected && (
                          <Check size={16} className="text-white stroke-[3] drop-shadow-sm" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 3. Background Theme & Colors (पार्श्वभूमी रंग) */}
              <div className="space-y-2 pt-1 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <Sparkles size={14} className={iconDef.tailwindText} />
                    <span>{t.backgroundColor || 'Background Theme (पार्श्वभूमी रंग)'}</span>
                  </label>
                  <span className="text-[10px] font-bold text-slate-400">
                    {language === 'mr' ? getBgColorDef(bgColor).nameMr : getBgColorDef(bgColor).nameEn}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-1.5">
                  {BG_COLORS.map(b => {
                    const isSelected = bgColor === b.key;
                    return (
                      <button
                        key={b.key}
                        type="button"
                        onClick={() => {
                          setBgColor?.(b.key);
                          if (b.isReading) {
                            setReadingMode?.(true);
                          } else if (readingMode) {
                            setReadingMode?.(false);
                          }
                          if (b.isDark && !darkMode) {
                            setDarkMode(true);
                          }
                          showToast(`${language === 'mr' ? 'पार्श्वभूमी बदलली:' : 'Background theme set:'} ${language === 'mr' ? b.nameMr : b.nameEn}`);
                        }}
                        className={`p-2 rounded-xl text-left border transition-all flex items-center gap-2 cursor-pointer ${
                          isSelected
                            ? 'border-sky-500 bg-sky-50/70 dark:bg-sky-950/40 ring-1 ring-sky-500 text-slate-900 dark:text-white font-bold'
                            : 'border-slate-200 dark:border-slate-700/80 bg-slate-50/50 dark:bg-slate-800/40 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        <span 
                          className="w-4 h-4 rounded-full border border-slate-400/40 shrink-0 shadow-xs" 
                          style={{ backgroundColor: b.accentPreview }}
                        />
                        <span className="text-[11px] leading-tight truncate">
                          {language === 'mr' ? b.nameMr.split(' ')[0] : b.nameEn.split(' ')[0]}
                        </span>
                        {isSelected && <Check size={12} className="ml-auto text-sky-500 shrink-0 stroke-[3]" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Language Selection */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Globe size={13} /> Language / भाषा
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    onClick={() => setLanguage('en')}
                    className={`py-1.5 rounded-xl text-xs font-medium transition-all ${
                      language === 'en'
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    English
                  </button>
                  <button
                    onClick={() => setLanguage('mr')}
                    className={`py-1.5 rounded-xl text-xs font-medium transition-all ${
                      language === 'mr'
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    मराठी
                  </button>
                  <button
                    onClick={() => setLanguage('hi')}
                    className={`py-1.5 rounded-xl text-xs font-medium transition-all ${
                      language === 'hi'
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    हिंदी
                  </button>
                </div>
              </div>

              {/* Font Size Selection */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Type size={13} /> Font Size / फॉन्ट आकार
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    onClick={() => setFontSize('small')}
                    className={`py-1.5 rounded-xl text-xs font-medium transition-all ${
                      fontSize === 'small'
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    Small
                  </button>
                  <button
                    onClick={() => setFontSize('medium')}
                    className={`py-1.5 rounded-xl text-xs font-medium transition-all ${
                      fontSize === 'medium'
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    Medium
                  </button>
                  <button
                    onClick={() => setFontSize('large')}
                    className={`py-1.5 rounded-xl text-xs font-medium transition-all ${
                      fontSize === 'large'
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    Large
                  </button>
                </div>
              </div>

              {/* Demo Window Switch */}
              {setDemoWindowEnabled && (
                <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between p-3 rounded-2xl bg-sky-50 dark:bg-slate-800/60 border border-sky-100 dark:border-slate-700/80">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 text-white flex items-center justify-center font-bold shadow-sm">
                        <Sliders size={16} />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block">
                          {language === 'mr' ? 'डेमो विंडो (Demo Window)' : 'Demo Window'}
                        </span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 block">
                          {language === 'mr' ? 'बबल मेन्यू आणि स्क्रीन नेव्हिगेटर' : 'Bubble menu & screen navigator'}
                        </span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setDemoWindowEnabled(!demoWindowEnabled)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                        demoWindowEnabled ? 'bg-sky-600' : 'bg-slate-300 dark:bg-slate-700'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          demoWindowEnabled ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setShowSettingsDrawer(false)}
                className="w-full py-3 rounded-xl bg-slate-900 dark:bg-slate-800 text-white font-bold text-xs shadow hover:opacity-90"
              >
                Close Settings
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Screen Notification Modal */}
      {showNotificationModal && (
        <div className="fixed inset-0 z-50 bg-white dark:bg-slate-950 flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400">
                <Bell size={22} />
              </div>
              <div>
                <h2 className="font-extrabold text-lg text-slate-900 dark:text-white">Notifications</h2>
                <p className="text-xs text-slate-500">{unreadCount} unread messages</p>
              </div>
            </div>
            <button
              onClick={() => setShowNotificationModal(false)}
              className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            >
              <X size={22} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto max-w-2xl w-full mx-auto p-4 sm:p-6 space-y-4">
            {/* Toast Feedback */}
            {toastMessage && (
              <div className="p-3 rounded-2xl bg-slate-900 text-white border border-sky-500/50 text-xs font-bold shadow-lg animate-in fade-in slide-in-from-top-2 flex items-center justify-between">
                <span>{toastMessage}</span>
                <button onClick={() => setToastMessage(null)} className="text-slate-400 hover:text-white ml-2">
                  <X size={14} />
                </button>
              </div>
            )}

            {/* DAILY TASK INCOMPLETE EVENING REMINDER CARD */}
            <div className="p-5 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950 border border-amber-500/30 text-white space-y-3.5 shadow-xl relative overflow-hidden">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-amber-400 flex items-center justify-center shrink-0">
                    <Bell size={20} className="animate-bounce" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-white flex items-center gap-2">
                      <span>{language === 'mr' ? 'दैनिक टास्क संध्याकाळचे रिमाइंडर' : 'Daily Task Incomplete Reminder'}</span>
                    </h3>
                    <p className="text-[11px] text-slate-300 leading-tight">
                      {language === 'mr' ? 'टास्क बाकी राहिल्यास संध्याकाळी सूचना मिळेल' : "Evening alert if today's task is incomplete"}
                    </p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 font-extrabold text-xs shrink-0 flex items-center gap-1">
                  <Clock size={12} />
                  <span>{profile.reminderTime || '8:00 PM'}</span>
                </span>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {language === 'mr'
                  ? 'जर तुमचे आजचे टास्क पूर्ण झाले नाही, तर तुम्हाला संध्याकाळी कधी आठवण करून देऊ? खालीलपैकी वेळ निवडा:'
                  : 'If today\'s task is incomplete, what evening time should we remind you? Select a time below:'}
              </p>

              {/* Time selection chips (5 PM to 10 PM) */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 pt-1">
                {['5:00 PM', '6:00 PM', '7:00 PM', '8:00 PM', '9:00 PM', '10:00 PM'].map((time) => {
                  const isSelected = (profile.reminderTime || '8:00 PM') === time;
                  return (
                    <button
                      key={time}
                      type="button"
                      onClick={() => {
                        if (onUpdateProfile) {
                          onUpdateProfile({
                            ...profile,
                            reminderTime: time,
                            reminderEnabled: true,
                          });
                        }
                        showToast(`⏰ ${language === 'mr' ? `रिमाइंडर वेळ सेट केली: ${time}` : `Reminder time set to ${time}`}`);
                      }}
                      className={`py-2 px-1 rounded-2xl text-xs font-bold transition-all border cursor-pointer flex flex-col items-center justify-center gap-0.5 active:scale-95 ${
                        isSelected
                          ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20 font-black'
                          : 'bg-slate-950/70 hover:bg-slate-800 text-slate-300 border-slate-800'
                      }`}
                    >
                      <Clock size={12} className={isSelected ? 'text-slate-950' : 'text-slate-400'} />
                      <span className="leading-tight">{time}</span>
                      <span className="text-[9px] opacity-75">{time.split(':')[0]} {language === 'mr' ? 'वाजता' : 'PM'}</span>
                    </button>
                  );
                })}
              </div>

              {/* Permission & Test Controls */}
              <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2.5">
                <button
                  type="button"
                  onClick={async () => {
                    const perm = await requestNotificationPermission();
                    if (onUpdateProfile) {
                      onUpdateProfile({
                        ...profile,
                        notificationsAllowed: perm === 'granted',
                      });
                    }
                    if (perm === 'granted') {
                      showToast('✅ Phone notifications enabled!');
                    } else if (perm === 'denied') {
                      showToast('⚠️ Notifications blocked in browser. Allow in site settings.');
                    }
                  }}
                  className="w-full sm:w-auto px-3 py-2 rounded-xl bg-sky-500/15 hover:bg-sky-500/25 border border-sky-400/30 text-sky-300 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
                >
                  <Smartphone size={13} />
                  <span>
                    {getNotificationPermission() === 'granted'
                      ? (language === 'mr' ? 'फोन नोटिफिकेशन्स सुरू ✅' : 'Device Notifications Active ✅')
                      : (language === 'mr' ? 'फोन नोटिफिकेशन सुरू करा 🔔' : 'Allow Device Notifications 🔔')}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={async () => {
                    if (getNotificationPermission() === 'default') {
                      await requestNotificationPermission();
                    }
                    const res = sendTaskReminderNotification({
                      timeLabel: profile.reminderTime || '8:00 PM',
                      body: language === 'mr'
                        ? `⚠️ आजचे टास्क पूर्ण झाले नाही! दररोज संध्याकाळी ${profile.reminderTime || '8:00 PM'} वाजता रिमाइंडर येईल.`
                        : `⚠️ Today's task is incomplete! You will be reminded daily at ${profile.reminderTime || '8:00 PM'}.`,
                    });
                    if (res.success) {
                      showToast('🔔 Test notification sent to device!');
                    } else if (res.reason === 'denied') {
                      showToast('⚠️ Notifications blocked. Please allow browser notifications.');
                    } else {
                      showToast('🔔 Reminder simulated on screen!');
                    }
                  }}
                  className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 cursor-pointer active:scale-95 transition-all"
                >
                  <Bell size={13} />
                  <span>{language === 'mr' ? 'टेस्ट रिमाइंडर पाठवा' : 'Test Reminder Notification'}</span>
                </button>
              </div>
            </div>

            {/* Notification Messages Header */}
            <div className="pt-2 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-bold px-1">
              <span>{language === 'mr' ? 'संदेश व सूचना' : 'Messages & Alerts'}</span>
              <span>{notifications.length} {language === 'mr' ? 'एकूण' : 'Total'}</span>
            </div>

            {notifications.length === 0 ? (
              <div className="text-center py-12 space-y-2">
                <Bell size={40} className="mx-auto text-slate-300 dark:text-slate-700" />
                <p className="text-xs font-medium text-slate-500">No messages yet</p>
              </div>
            ) : (
              notifications.map(n => (
                <div
                  key={n.id}
                  onClick={() => onMarkNotificationRead(n.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-4 ${
                    n.read
                      ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                      : 'bg-sky-50/70 dark:bg-sky-950/40 border-sky-200 dark:border-sky-900 text-slate-900 dark:text-slate-200 shadow-sm'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm">{n.title}</span>
                      {!n.read && (
                        <span className="w-2 h-2 rounded-full bg-sky-600 animate-pulse" />
                      )}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{n.message}</p>
                    <span className="text-[10px] text-slate-400 block pt-1">{n.time}</span>
                  </div>

                  {!n.read && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onMarkNotificationRead(n.id);
                      }}
                      className="p-2 rounded-xl text-sky-600 hover:bg-sky-100 dark:hover:bg-sky-900 transition-colors shrink-0"
                      title="Mark as read"
                    >
                      <CheckCircle2 size={18} />
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </>
  );
};
