import React from 'react';
import { Home, Route, BarChart2, User } from 'lucide-react';
import { TabType, IconColorKey } from '../types';
import { translations } from '../translations';
import { getIconColorDef } from '../utils/theme';

interface Props {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  language: 'en' | 'mr' | 'hi';
  iconColor?: IconColorKey;
}

export const BottomNav: React.FC<Props> = ({ activeTab, setActiveTab, language, iconColor = 'sky' }) => {
  const t = translations[language];
  const iconDef = getIconColorDef(iconColor);

  const navItems: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: t.home, icon: <Home size={22} /> },
    { id: 'pathway', label: t.pathway, icon: <Route size={22} /> },
    { id: 'assess', label: t.assess, icon: <span className={`font-extrabold text-base tracking-tighter flex items-baseline ${iconDef.tailwindText} ${iconDef.tailwindDarkText}`}>R<span className="text-[10px] lowercase font-semibold">e</span></span> },
    { id: 'progress', label: t.progress, icon: <BarChart2 size={22} /> },
    { id: 'profile', label: t.profile, icon: <User size={22} /> },
  ];

  return (
    <nav aria-label="Bottom Navigation" className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-safe shadow-lg transition-colors">
      <div className="grid grid-cols-5 items-center h-16 max-w-lg mx-auto px-2">
        {navItems.map(item => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 transition-all ${
                isActive
                  ? `${iconDef.tailwindText} ${iconDef.tailwindDarkText} font-semibold scale-105`
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <div 
                className={`p-1 rounded-xl transition-colors ${
                  isActive ? `${iconDef.tailwindBg} ${iconDef.tailwindDarkBg}` : ''
                }`}
                style={isActive ? { color: iconDef.hex } : undefined}
              >
                {item.icon}
              </div>
              <span className="text-[11px] font-medium tracking-tight mt-0.5">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
