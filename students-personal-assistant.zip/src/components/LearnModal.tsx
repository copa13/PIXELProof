import React from 'react';
import { TaskItem } from '../types';
import { X, BookOpen, ExternalLink, CheckCircle2, Sparkles, Video, FileText, ArrowLeft } from 'lucide-react';

interface Props {
  task: TaskItem | null;
  onClose: () => void;
  language: 'en' | 'mr' | 'hi';
}

export const LearnModal: React.FC<Props> = ({ task, onClose, language }) => {
  if (!task) return null;

  const isMarathi = language === 'mr';
  const isHindi = language === 'hi';

  return (
    <div className="fixed inset-0 z-50 bg-white dark:bg-slate-950 flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-300">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400">
            <BookOpen size={24} />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-sky-600 dark:text-sky-400">
              {isMarathi ? 'अध्ययन मार्गदर्शक (Learning Screen)' : 'Learning Screen'}
            </span>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white">{task.title}</h2>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors flex items-center gap-1.5 text-xs font-bold"
        >
          <X size={20} />
          <span>Close</span>
        </button>
      </div>

      {/* Full Screen Content Area */}
      <div className="flex-1 overflow-y-auto max-w-3xl w-full mx-auto p-6 space-y-6">
        {/* What to learn today */}
        <div className="space-y-3 bg-slate-50 dark:bg-slate-900/80 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <h4 className="font-bold text-sm uppercase tracking-wider text-sky-600 dark:text-sky-400 flex items-center gap-2">
            <Sparkles size={18} /> {isMarathi ? 'आज काय शिकायचे आहे?' : "What to Learn Today"}
          </h4>
          <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
            {isMarathi 
              ? 'आज आपण प्रगत डेटा स्ट्रक्चर्स आणि अल्गोरिदम (Advanced Data Structures & Algorithms) मधील ग्राफ ट्रव्हर्सल आणि शॉर्टेस्ट पाथ अल्गोरिदम (Dijkstra & Bellman-Ford) सखोल अभ्यासणार आहोत.' 
              : task.description}
          </p>
        </div>

        {/* Text Documentation Sources */}
        <div className="space-y-3 bg-sky-50/50 dark:bg-sky-950/30 p-6 rounded-3xl border border-sky-100 dark:border-sky-900/50 shadow-sm">
          <h4 className="font-bold text-sm uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-2">
            <FileText size={18} /> {isMarathi ? 'टेक्स्ट माहिती व दस्तऐवज (Text Sources)' : "Text Documentation Sources"}
          </h4>
          <ul className="space-y-3 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
            <li className="flex items-start gap-3">
              <span className="w-2 h-2 rounded-full bg-indigo-600 mt-2 shrink-0" />
              <span>{isMarathi ? 'युनिव्हर्सिटी अभ्यासक्रम प्रकरण १४ (Chapter 14: Network Flows & Graph Theory)' : 'University Course Chapter 14: Graph Networks & Shortest Path Trees'}</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-600 mt-2 shrink-0" />
              <span>{isMarathi ? 'अधिकृत नोट्स: GeeksforGeeks & LeetCode Explore Cards' : 'Official Notes: GeeksforGeeks & LeetCode Explore Cards'}</span>
            </li>
          </ul>
        </div>

        {/* Video Tutorials */}
        <div className="space-y-3 bg-indigo-50/50 dark:bg-indigo-950/30 p-6 rounded-3xl border border-indigo-100 dark:border-indigo-900/50 shadow-sm">
          <h4 className="font-bold text-sm uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-2">
            <Video size={18} /> {isMarathi ? 'व्हिडिओ ट्यूटोरियल व लेक्चर्स (Video Tutorials)' : "Video Tutorials & Lectures"}
          </h4>
          <div className="space-y-3">
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-indigo-100 dark:border-indigo-900 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
                  <Video size={22} />
                </div>
                <div>
                  <p className="font-extrabold text-sm text-slate-900 dark:text-white">
                    {isMarathi ? 'ग्राफ अल्गोरिदम मास्टरक्लास (Lecture 1)' : 'Graph Algorithms Masterclass (Lecture 1)'}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">YouTube • 25 mins • High Definition</p>
                </div>
              </div>
              <button 
                onClick={() => alert(isMarathi ? 'व्हिडिओ प्ले होत आहे...' : 'Playing video lecture...')}
                className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 transition-colors shadow"
              >
                Watch Video
              </button>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-4 pb-10">
          <button
            onClick={onClose}
            className="px-8 py-3 rounded-2xl bg-sky-600 text-white font-bold text-sm shadow-lg shadow-sky-600/20 hover:bg-sky-700 transition-all flex items-center gap-2"
          >
            <CheckCircle2 size={18} /> {isMarathi ? 'शिकून पूर्ण झाले (Got It)' : 'Got It & Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
