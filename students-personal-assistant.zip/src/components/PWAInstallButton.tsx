import React, { useState } from 'react';
import { Download, Check, Share, PlusSquare, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface Props {
  language?: 'en' | 'mr' | 'hi';
  variant?: 'compact' | 'full';
}

export const PWAInstallButton: React.FC<Props> = ({ language = 'mr', variant = 'compact' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  // If already installed as PWA in standalone mode, show subtle installed badge or nothing
  if (isInstalled) {
    if (variant === 'full') {
      return (
        <div className="flex items-center gap-2 p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-semibold border border-emerald-200 dark:border-emerald-800">
          <Check size={16} />
          <span>{language === 'mr' ? 'ॲप इन्स्टॉल केले आहे' : 'App is Installed'}</span>
        </div>
      );
    }
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      await install();
    } else {
      setShowGuide(true);
    }
  };

  const buttonText = language === 'mr' ? 'ॲप इन्स्टॉल करा' : language === 'hi' ? 'ऐप इंस्टॉल करें' : 'Install App';

  return (
    <>
      {variant === 'compact' ? (
        <button
          onClick={handleInstallClick}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-bold text-xs shadow-md shadow-sky-600/20 transition-all active:scale-95 shrink-0"
          title={buttonText}
        >
          <Download size={14} />
          <span className="hidden sm:inline">{buttonText}</span>
          <span className="sm:hidden">Install</span>
        </button>
      ) : (
        <button
          onClick={handleInstallClick}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-sky-600/25 transition-all active:scale-98"
        >
          <Download size={16} />
          <span>{buttonText}</span>
        </button>
      )}

      {/* Guided Install Modal for devices where beforeinstallprompt hasn't fired or iOS */}
      {showGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800 relative animate-in zoom-in-95">
            <button
              onClick={() => setShowGuide(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full"
            >
              <X size={20} />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl overflow-hidden shadow-md border border-slate-200 dark:border-slate-800 bg-slate-900 shrink-0">
                <img src="/pwa-192x192.png" alt="SPA Logo" className="w-full h-full object-cover" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                  {language === 'mr' ? 'मोबाईल / PC वर इन्स्टॉल करा' : 'Install on Mobile & PC'}
                </h3>
                <p className="text-xs text-slate-500">SPA - Students Personal Assistant</p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
              {isIOS ? (
                <div className="space-y-2">
                  <p className="font-bold text-slate-900 dark:text-white">iPhone / iPad वर इन्स्टॉल कसे करावे:</p>
                  <ol className="list-decimal list-inside space-y-1">
                    <li>खालील किंवा सफारी बारमधील <Share size={12} className="inline mx-1" /> <strong>Share</strong> बटणावर टॅप करा.</li>
                    <li>खाली स्क्रोल करून <PlusSquare size={12} className="inline mx-1" /> <strong>Add to Home Screen</strong> निवडा.</li>
                    <li>उजवीकडे वर <strong>Add</strong> टॅप करा.</li>
                  </ol>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="font-bold text-slate-900 dark:text-white">Android फोन व PC (Chrome / Edge) वर:</p>
                  <ol className="list-decimal list-inside space-y-1.5">
                    <li>ब्राउझरच्या उजव्या बाजूला वर <strong>3 डॉट्स (⋮)</strong> वर क्लिक करा.</li>
                    <li>तिथे <strong>"Install app"</strong> किंवा <strong>"Add to Home screen"</strong> वर क्लिक करा.</li>
                    <li>किंवा ब्राउझरच्या ॲड्रेस बारमधील <strong>Install (📥)</strong> आयकॉनवर टॅप करा.</li>
                  </ol>
                </div>
              )}
            </div>

            <button
              onClick={() => setShowGuide(false)}
              className="w-full py-2.5 rounded-xl bg-sky-600 text-white font-bold text-xs shadow-md hover:bg-sky-700 transition"
            >
              {language === 'mr' ? 'समजले' : 'Got it'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};
